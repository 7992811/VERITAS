"""Episode attribution and bounded adaptive recommendations.

All labels are descriptive. They deliberately avoid claiming a causal mistake from
P&L alone. Positive risk reinforcement remains gated; negative evidence may reduce
risk because doing so cannot create extra exposure.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
from datetime import datetime
from decimal import Decimal
from typing import Iterable
import json
from veritas_v85.domain import D,ONE,ZERO,Direction,canonical_json,decimal,stable_id,utc,HORIZON_SECONDS
from veritas_v85.counterfactual import PathPoint,alternative_stop


@dataclass(frozen=True)
class Attribution:
    episode_id:str
    account_id:str
    context_key:str
    direction_return:Decimal
    net_return:Decimal
    mfe:Decimal
    mae:Decimal
    capture_ratio:Decimal | None
    entry_heat_before_first_favorable:Decimal
    stop_distance_fraction:Decimal
    exit_giveback:Decimal
    exit_reason:str
    label:str
    known_at:datetime


@dataclass(frozen=True)
class AdaptiveAdjustment:
    applied_size_multiplier:Decimal=ONE
    proposed_positive_multiplier:Decimal=ONE
    direction_prior:Decimal=ZERO
    management_tests:tuple[str,...]=()
    reason:str='OBSERVE_ONLY'
    n:int=0
    positive_authority:bool=False


def context_key(asset,horizon,setup,direction,regime)->str:
    return '|'.join(str(x or 'UNKNOWN') for x in (asset,horizon,setup,direction,regime))


def _clip(x,lo,hi): return max(lo,min(hi,x))


def attribute_episode(*,episode_id:str,account_id:str,direction:Direction,entry_price,exit_price,
                      entry_nav,initial_stop,outcome:dict,path_prices:Iterable,context:dict,known_at:datetime)->Attribution:
    entry=decimal(entry_price,positive=True);exitp=decimal(exit_price,positive=True);nav=decimal(entry_nav,positive=True)
    stop=decimal(initial_stop,positive=True);d=Direction(direction);known_at=utc(known_at)
    dret=d.sign*(exitp/entry-ONE); net=decimal(outcome.get('net_pnl'))/nav
    mfe=decimal(outcome.get('observed_mfe_fraction') or '0');mae=decimal(outcome.get('observed_mae_fraction') or '0')
    give=decimal(outcome.get('giveback_from_observed_peak') or '0',nonnegative=True)
    capture=(dret/mfe) if mfe>0 else None
    capture=_clip(capture,D('-2'),D('2')) if capture is not None else None
    stop_dist=abs(entry-stop)/entry
    returns=[]
    for price in path_prices:
        try:returns.append(d.sign*(decimal(price,positive=True)/entry-ONE))
        except ValueError:continue
    first_pos=next((i for i,r in enumerate(returns) if r>0),None)
    before=returns if first_pos is None else returns[:first_pos+1]
    heat=abs(min([ZERO]+before))
    if dret>0 and capture is not None and capture>=D('.60'):label='RIGHT_DIRECTION_HIGH_CAPTURE'
    elif dret>0 and capture is not None and capture<D('.35'):label='RIGHT_DIRECTION_LOW_CAPTURE'
    elif dret<=0 and mfe>=D('.004'):label='FAVORABLE_PATH_NOT_MONETIZED'
    elif dret<=0 and mfe<D('.004'):label='DIRECTION_OR_ENTRY_FAILED_ON_OBSERVED_PATH'
    else:label='MIXED_EXECUTION'
    ck=context_key(context.get('asset'),context.get('horizon'),context.get('setup'),d.value,context.get('regime'))
    return Attribution(episode_id,account_id,ck,dret,net,mfe,mae,capture,heat,stop_dist,give,
                       str(outcome.get('exit_reason') or 'UNKNOWN'),label,known_at)


def observed_stop_grid(*,episode_id:str,direction:Direction,entry_price,initial_stop,quantity,instrument,
                       opened_at,closed_at,known_at,path_points:list[PathPoint])->list[dict]:
    entry=decimal(entry_price,positive=True);stop=decimal(initial_stop,positive=True);d=Direction(direction)
    distance=abs(entry-stop)
    out=[]
    for mult in (D('.75'),D('1.00'),D('1.25')):
        alt=entry-distance*mult if d==Direction.LONG else entry+distance*mult
        try:r=alternative_stop(path_points,d,entry,alt,opened_at,closed_at,known_at,quantity,instrument)
        except ValueError:continue
        out.append({'scenario_id':stable_id('CF86_',episode_id,'STOP',str(mult)),'kind':'STOP_DISTANCE',
                    'multiplier':str(mult),'stop_price':str(alt),**{k:(str(v) if isinstance(v,Decimal) else v) for k,v in r.items()}})
    return out


def summarize_attributions(rows:list[Attribution])->dict:
    n=len(rows)
    if not n:return {'n':0,'reason':'NO_EPISODES'}
    wins=sum(x.net_return>0 for x in rows);dirwins=sum(x.direction_return>0 for x in rows)
    gains=sum((x.net_return for x in rows if x.net_return>0),ZERO)
    losses=-sum((x.net_return for x in rows if x.net_return<0),ZERO)
    caps=[x.capture_ratio for x in rows if x.capture_ratio is not None and x.capture_ratio.is_finite()]
    netmean=sum((x.net_return for x in rows),ZERO)/D(n)
    dir_rate=D(dirwins)/D(n);wr=D(wins)/D(n)
    capmean=sum(caps,ZERO)/D(len(caps)) if caps else None
    pf=(gains/losses) if losses>0 else None
    tests=[]
    if n>=8 and capmean is not None and capmean<D('.35'):tests.append('TEST_PARTIAL_TAKE_PROFIT_AND_TRAILING')
    if n>=8 and sum(x.label=='FAVORABLE_PATH_NOT_MONETIZED' for x in rows)/n>=.25:tests.append('TEST_EXIT_AND_REENTRY_LOGIC')
    if n>=8 and sum(x.entry_heat_before_first_favorable>x.stop_distance_fraction*D('.65') for x in rows)/n>=.25:tests.append('TEST_LATER_OR_STAGED_ENTRY')
    applied=ONE;proposed=ONE;reason='OBSERVE_ONLY';prior=ZERO
    if n>=8 and netmean<=0:
        applied=D('.50');reason='NEGATIVE_NET_ECONOMICS_REDUCE_ONLY'
    if n>=12 and dir_rate<D('.45'):
        applied=min(applied,D('.70'));reason='NEGATIVE_DIRECTION_EVIDENCE_REDUCE_ONLY'
    if n>=20 and netmean>0 and wr>=D('.65') and (pf is None or pf>=D('1.20')):
        proposed=D('1.10');reason='POSITIVE_CANDIDATE_REQUIRES_PERFORMANCE_GATE'
    if n>=12:
        prior=_clip((dir_rate-D('.50'))*D('.12'),D('-.03'),D('.03'))
    return {'n':n,'win_rate':str(wr),'direction_hit_rate':str(dir_rate),'weighted_net_mean':str(netmean),
            'profit_factor':str(pf) if pf is not None else None,'capture_ratio_mean':str(capmean) if capmean is not None else None,
            'applied_size_multiplier':str(applied),'proposed_positive_multiplier':str(proposed),'direction_prior':str(prior),
            'management_tests':tests,'reason':reason,'positive_authority':False}
