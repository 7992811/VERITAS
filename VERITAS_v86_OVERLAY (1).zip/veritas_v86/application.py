"""v86 application: audited v85 execution + eight mandates + adaptive research loop."""
from __future__ import annotations
from dataclasses import replace
from datetime import datetime
from pathlib import Path
from http.server import ThreadingHTTPServer
import copy,json,os,signal
from threading import Thread
from veritas_v85.application import Application as V85Application,handler,now
from veritas_v85.book import PaperBook,InputConflict
from veritas_v85.config import Settings,instruments
from veritas_v85.domain import D,stable_id,decimal,canonical_json,utc
from veritas_v85.risk import RiskLimits
from veritas_v85.snapshots import SnapshotStore
from veritas_v85.experience_store import ExperienceService,ExperienceView
from veritas_v85.validation import verify_release,verify_runtime_version
from .schema import ensure_schema
from .portfolios import PROFILES,ORDER,signal_allowed,risk_state
from .adaptive_store import AdaptiveService,AdaptiveView,CompositeExperienceView
from .opportunity import record_opportunities,mature_opportunities
from .performance import compare,persist_gate


class Application(V85Application):
    def __init__(self,*args,**kwargs):
        self.adaptive_memory={};self.adaptive_services={};self.last_gates={}
        super().__init__(*args,**kwargs)

    def _wire_account(self,name,*,funding_rate=D('0')):
        if name not in self.memory:
            s=SnapshotStore(ttl_seconds=1200,max_bytes=524288);self.memory[name]=s;self.services[name]=ExperienceService(self.ledger,s)
        a=SnapshotStore(ttl_seconds=1200,max_bytes=524288);self.adaptive_memory[name]=a
        self.adaptive_services[name]=AdaptiveService(self.ledger,a,self.specs,name)
        profile=PROFILES.get(name)
        base=ExperienceView(self.memory[name]) if profile and profile.adaptive else None
        adaptive=AdaptiveView(a,positive_authority=False) if profile and profile.adaptive else None
        view=CompositeExperienceView(base,adaptive) if profile and profile.adaptive else None
        self.books[name]=PaperBook(self.ledger,self.specs,experience_view=view,annual_funding_rate=funding_rate,
                                   short_funding_spread=D('0') if self.settings.testing else D('.02'))
        with self.ledger.read() as c:r=c.execute('SELECT initial_equity,realized_equity FROM v85_accounts WHERE account_id=?',(name,)).fetchone()
        self.risk_high_water[name]=max(decimal(r['initial_equity'],positive=True),decimal(r['realized_equity'],positive=True))

    def bootstrap(self):
        result=super().bootstrap();ensure_schema(self.ledger)
        # v85 wires the existing accounts; v86 replaces their views with the adaptive composite.
        base_rate=next(iter(self.books.values())).annual_funding_rate if self.books else D('0')
        if self.mode in ('fixture','paper'):
            creator=PaperBook(self.ledger,self.specs)
            for name in ORDER:
                with self.ledger.read() as c:exists=c.execute('SELECT 1 FROM v85_accounts WHERE account_id=?',(name,)).fetchone()
                if not exists:creator.create_account(name,D('1000000'),'86.0.0-dev1/'+name)
        with self.ledger.read() as c:accounts=[r['account_id'] for r in c.execute('SELECT account_id FROM v85_accounts ORDER BY account_id').fetchall()]
        for name in accounts:
            if name in PROFILES:self._wire_account(name,funding_rate=base_rate)
        result.update({'v86':True,'portfolio_mandates':[n for n in ORDER if n in self.books],
                       'relative_value_execution_enabled':PROFILES['RelativeValue'].execution_enabled})
        return result

    def account_risk(self,account,book,quotes,at):
        profile=PROFILES.get(account,PROFILES['Champion'])
        financial=getattr(self.ledger,'financial_transaction',self.ledger.transaction)
        with financial() as c:
            nav,gross,valid,a=book._valuation(c,account,quotes,at)
            old=c.execute('SELECT high_water FROM v85_risk WHERE account_id=?',(account,)).fetchone()
            high=decimal(old['high_water']) if old else max(decimal(a['initial_equity']),decimal(a['realized_equity']))
            if valid:high=max(high,nav)
            dd=max(D('0'),D('1')-nav/high) if high>0 else D('1')
            state=risk_state(profile,dd)
            c.execute('INSERT INTO v85_risk VALUES(?,?,?,?) ON CONFLICT(account_id) DO UPDATE SET high_water=excluded.high_water,state=excluded.state,at=excluded.at',
                      (account,str(high),state['state'],utc(at).isoformat()))
        return {**state,'nav':nav,'nav_verified':valid,'drawdown':dd}

    def _process_locked(self,signals,quotes,at,*,guard=False):
        context=copy.copy(quotes)
        bid=stable_id('B86_',sorted((a,q.event_id,q.problem(at,self.specs[a])) for a,q in context.items()))
        context={a:replace(q,event_id=stable_id('QCTX86_',bid,a,q.event_id)) for a,q in context.items()}
        output=[]
        kill=(self.critical_kill or bool(getattr(self.model,'KILL_SWITCH',False)) or os.getenv('VERITAS_V86_KILL_SWITCH','0')=='1')
        critical_fresh=self.settings.testing or (self.critical_known_at is not None and 0<=(at-self.critical_known_at).total_seconds()<=60)
        for account,book in sorted(self.books.items()):
            profile=PROFILES.get(account,PROFILES['Champion'])
            active={p.asset:p for p in book.positions(account)}
            risk=self.account_risk(account,book,context,at);hard_stop=kill or risk['hard_stop']
            assets=sorted(set(active)|set(signals),key=lambda a:(a not in active,a));actions=[]
            for a in assets:
                q=context.get(a);s=signals.get(a)
                if s and not signal_allowed(profile,s,self.latest_full_summary):s=None
                if s and not profile.execution_enabled:s=None
                if guard:s=None
                event=q.event_id if q else stable_id('NQ86_',a,'kill' if hard_stop else 'hold')
                revent=stable_id('RCTX86_',event,risk['state'],critical_fresh,hard_stop,account)
                if q is not None:q=replace(q,event_id=revent)
                event=revent
                limits=RiskLimits(risk['gross_cap'],profile.asset_cap,profile.stop_risk_nav,
                                  new_risk_allowed=not hard_stop and critical_fresh,desired_step=profile.desired_step,
                                  soft_multiplier=risk['multiplier'])
                try:
                    thesis=self.thesis_events.get(active[a].episode_id) if a in active else None
                    result=book.process(account,a,event,at,q,s,limits,quotes=context,portfolio_hard_stop=hard_stop,thesis_break=thesis)
                    actions.append({'asset':a,**result})
                except InputConflict as e:actions.append({'asset':a,'management_reason':'INPUT_CONFLICT','error':str(e)[:120]})
            output.append({'name':account,'mandate':profile.mandate,'actions':actions,'risk_profile':profile.json()})
        return output

    def commit_cycle(self,summary,bundles,cycle_id,clock_ok=True):
        out=super().commit_cycle(summary,bundles,cycle_id,clock_ok=clock_ok)
        if self.mode!='audit' and self.last_routes is not None:
            at=now()
            with self.state_lock:quotes=dict(self.quotes);rows=list(self.latest_full_summary)
            try:
                out['v86_new_opportunities']=record_opportunities(self.ledger,self.last_routes,out,quotes,rows,at)
                out['v86_matured_opportunities']=mature_opportunities(self.ledger,quotes,self.specs,at)
            except Exception as exc:out['v86_opportunity_error']=type(exc).__name__+': '+str(exc)[:160]
        return out

    def refresh_learning(self):
        base=super().refresh_learning();at=now();adaptive=[];gates=[]
        for account,service in self.adaptive_services.items():
            adaptive.append({'account':account,**service.refresh(at)})
        if 'Champion' in self.books:
            for account in ORDER:
                if account=='Champion' or account not in self.books:continue
                try:
                    g=compare(self.ledger,account,'Champion');gid=persist_gate(self.ledger,g,at);self.last_gates[account]=g
                    gates.append({'gate_id':gid,**g})
                except Exception as exc:gates.append({'challenger':account,'status':'ERROR','error':type(exc).__name__})
        return {'v85_experience':base,'v86_adaptive':adaptive,'performance_gates':gates}

    def portfolio_report(self):
        report=super().portfolio_report();report['version']='v86';report['portfolio_design']='8_MANDATES'
        report['performance_gates']=self.last_gates
        for p in report.get('portfolios',[]):
            profile=PROFILES.get(p.get('name'))
            if profile:p['mandate']=profile.json()
        return report


def run(model):
    # v86 keeps v85's audited release validation while this development candidate is isolated.
    settings=Settings.env();root=Path(__file__).resolve().parents[1]
    from veritas_v85.postgres import PostgresLedger
    if settings.sqlite_path:
        from veritas_v85.storage import SQLiteLedger;ledger=SQLiteLedger(settings.sqlite_path)
    else:ledger=PostgresLedger(os.environ.get('DATABASE_URL',''))
    fixture_bundles=None
    if settings.mode=='fixture':
        from tools.fixtures import bundles;fixture_bundles=bundles(model)
    app=Application(model,ledger,settings,fixture_bundles=fixture_bundles);app.bootstrap()
    server=ThreadingHTTPServer(('0.0.0.0',settings.port),handler(app));server.daemon_threads=True
    def shutdown(*args):app.stop.set();Thread(target=server.shutdown,daemon=True).start()
    signal.signal(signal.SIGTERM,shutdown);signal.signal(signal.SIGINT,shutdown)
    print(canonical_json({'event':'v86_ready','version':getattr(model,'VERSION','unknown'),'mode':settings.mode,
                          'portfolio_mandates':list(ORDER),'positive_auto_promotion':False}),flush=True)
    app.start_workers()
    try:server.serve_forever(poll_interval=.2)
    finally:server.server_close();app.close()
