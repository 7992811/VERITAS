"""Eight explicit research mandates for VERITAS v86.

The mandates deliberately share one audited execution core but keep decisions,
statistics and learning isolated by account. RelativeValue remains execution-
disabled until a two-leg spread engine is validated; it still accumulates
opportunity evidence in shadow mode.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from decimal import Decimal
from typing import Iterable
from veritas_v85.domain import D, Signal


@dataclass(frozen=True)
class PortfolioProfile:
    account_id: str
    label_ru: str
    mandate: str
    allowed_setups: tuple[str, ...] = ()
    adaptive: bool = True
    execution_enabled: bool = True
    max_gross: Decimal = D("2.0")
    asset_cap: Decimal = D("1.0")
    stop_risk_nav: Decimal = D("0.015")
    hard_drawdown: Decimal = D("0.10")
    desired_step: Decimal = D("0.05")
    target_return_annual: Decimal = D("0.30")
    floor_return_annual: Decimal = D("0.17")

    def json(self) -> dict:
        return {k:(str(v) if isinstance(v,Decimal) else v) for k,v in asdict(self).items()}


PROFILES: dict[str, PortfolioProfile] = {
    "Champion": PortfolioProfile("Champion","Контрольный","fixed_control",adaptive=False,
                                  max_gross=D("2.0"),stop_risk_nav=D("0.015"),hard_drawdown=D("0.10")),
    "Challenger": PortfolioProfile("Challenger","Адаптивный","validated_challenger",adaptive=True,
                                    max_gross=D("2.0"),stop_risk_nav=D("0.015"),hard_drawdown=D("0.10")),
    "Impulse": PortfolioProfile("Impulse","Импульсный","momentum_breakout",
                                 ("IMPULSE_GENESIS","IMPULSE_PIVOT_BREAK","TACTICAL_REVERSAL","RANGE_RETEST_BREAKOUT"),
                                 max_gross=D("2.0"),asset_cap=D("0.75"),stop_risk_nav=D("0.020"),hard_drawdown=D("0.12")),
    "Trend": PortfolioProfile("Trend","Позиционный тренд","trend_following",
                               ("TREND","IMPULSE_PIVOT_BREAK","IMPULSE_GENESIS"),
                               max_gross=D("2.0"),stop_risk_nav=D("0.015"),hard_drawdown=D("0.10")),
    "Range": PortfolioProfile("Range","Диапазон и возврат","range_mean_reversion",
                               ("RANGE_RETEST_BREAKOUT","RANGE","MEAN_REVERSION"),
                               max_gross=D("1.5"),asset_cap=D("0.60"),stop_risk_nav=D("0.0125"),hard_drawdown=D("0.10")),
    "Reversal": PortfolioProfile("Reversal","Подтверждённый разворот","confirmed_reversal",
                                  ("TACTICAL_REVERSAL","REVERSAL"),
                                  max_gross=D("1.5"),asset_cap=D("0.60"),stop_risk_nav=D("0.015"),hard_drawdown=D("0.10")),
    "Event": PortfolioProfile("Event","Событийный","event_driven",
                               ("EVENT","CATALYST","NEWS","FOMC","CPI","EARNINGS"),
                               max_gross=D("1.5"),asset_cap=D("0.50"),stop_risk_nav=D("0.020"),hard_drawdown=D("0.12")),
    "RelativeValue": PortfolioProfile("RelativeValue","Относительная стоимость","relative_value",
                                       ("RELATIVE_VALUE","PAIR","SPREAD"),adaptive=True,execution_enabled=False,
                                       max_gross=D("1.0"),asset_cap=D("0.50"),stop_risk_nav=D("0.010"),hard_drawdown=D("0.08")),
}

ORDER = tuple(PROFILES)


def _event_evidence(signal: Signal, rows: Iterable[dict] | None) -> bool:
    text=(signal.setup_family+" "+signal.regime).upper()
    if any(k in text for k in ("EVENT","CATALYST","NEWS","FOMC","CPI","EARN")):
        return True
    for row in rows or ():
        if row.get("asset")!=signal.asset or row.get("horizon")!=signal.horizon:
            continue
        es=row.get("event_shadow_score")
        if isinstance(es,dict):
            try:
                if float(es.get("score") or 0)>=0.55 and (es.get("events") or es.get("factors")):
                    return True
            except (TypeError,ValueError):
                pass
        for k in ("event_catalyst","catalyst","macro_event","earnings_event"):
            if row.get(k): return True
    return False


def _relative_value_evidence(signal: Signal, rows: Iterable[dict] | None) -> bool:
    text=(signal.setup_family+" "+signal.regime).upper()
    if any(k in text for k in ("RELATIVE_VALUE","PAIR","SPREAD")): return True
    for row in rows or ():
        if row.get("asset")!=signal.asset or row.get("horizon")!=signal.horizon: continue
        rv=row.get("relative_value") or row.get("spread_signal") or {}
        if isinstance(rv,dict) and rv.get("active") is True:return True
    return False


def signal_allowed(profile: PortfolioProfile, signal: Signal | None, rows: Iterable[dict] | None = None) -> bool:
    if signal is None: return False
    if profile.account_id in ("Champion","Challenger"): return True
    if profile.account_id=="Event": return _event_evidence(signal,rows)
    if profile.account_id=="RelativeValue": return _relative_value_evidence(signal,rows)
    fam=(signal.setup_family or "UNCLASSIFIED").upper()
    return any(token in fam for token in profile.allowed_setups)


def risk_state(profile: PortfolioProfile, drawdown: Decimal) -> dict:
    """Profile-specific drawdown governor. Hard limits are 8-12%, not the v85 22%."""
    d=max(D("0"),drawdown); hard=profile.hard_drawdown
    if d>=hard:
        return {"state":"HARD_STOP","gross_cap":D("0.25"),"multiplier":D("0"),"hard_stop":True}
    ratio=d/hard if hard>0 else D("1")
    if ratio>=D("0.85"):
        return {"state":"DEFENSE_85","gross_cap":min(profile.max_gross,D("0.50")),"multiplier":D("0.35"),"hard_stop":False}
    if ratio>=D("0.70"):
        return {"state":"DEFENSE_70","gross_cap":min(profile.max_gross,D("1.00")),"multiplier":D("0.55"),"hard_stop":False}
    if ratio>=D("0.50"):
        return {"state":"CAUTION_50","gross_cap":min(profile.max_gross,D("1.50")),"multiplier":D("0.75"),"hard_stop":False}
    return {"state":"NORMAL","gross_cap":profile.max_gross,"multiplier":D("1"),"hard_stop":False}
