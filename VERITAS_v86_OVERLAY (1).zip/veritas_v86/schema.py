"""Additive v86 schema; v85 tables remain the authoritative financial ledger."""
from __future__ import annotations
from veritas_v85.domain import canonical_json
from .portfolios import PROFILES

SCHEMA = '''
CREATE TABLE IF NOT EXISTS v86_portfolio_profiles(
 account_id TEXT PRIMARY KEY, mandate TEXT NOT NULL, payload TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS v86_episode_attribution(
 episode_id TEXT PRIMARY KEY, account_id TEXT NOT NULL, known_at TEXT NOT NULL, context_key TEXT NOT NULL, payload TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS v86_attr_context ON v86_episode_attribution(account_id,context_key,known_at);
CREATE TABLE IF NOT EXISTS v86_counterfactuals(
 episode_id TEXT NOT NULL, scenario_id TEXT NOT NULL, known_at TEXT NOT NULL, payload TEXT NOT NULL,
 PRIMARY KEY(episode_id,scenario_id));
CREATE TABLE IF NOT EXISTS v86_opportunities(
 opportunity_id TEXT PRIMARY KEY, asset TEXT NOT NULL, horizon TEXT NOT NULL, direction TEXT NOT NULL,
 setup TEXT NOT NULL, regime TEXT NOT NULL, known_at TEXT NOT NULL, mature_at TEXT NOT NULL,
 entry_price TEXT NOT NULL, payload TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS v86_opportunity_maturity ON v86_opportunities(mature_at,asset);
CREATE TABLE IF NOT EXISTS v86_performance_gates(
 gate_id TEXT PRIMARY KEY, known_at TEXT NOT NULL, payload TEXT NOT NULL);
'''


def ensure_schema(ledger) -> None:
    with ledger.transaction() as c:
        for stmt in [x.strip() for x in SCHEMA.split(';') if x.strip()]:
            c.execute(stmt)
        for account,p in PROFILES.items():
            c.execute('INSERT INTO v86_portfolio_profiles(account_id,mandate,payload) VALUES(?,?,?) ON CONFLICT(account_id) DO UPDATE SET mandate=excluded.mandate,payload=excluded.payload',
                      (account,p.mandate,canonical_json(p.json())))
