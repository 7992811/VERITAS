"""Durable v86 attribution, counterfactual and adaptive snapshots."""
from __future__ import annotations
from dataclasses import asdict
from datetime import datetime
from decimal import Decimal
import json
from veritas_v85.domain import D,Direction,canonical_json,decimal,position_from_dict,utc
from veritas_v85.learning import LearningAdjustment
from veritas_v85.snapshots import SnapshotStore
from veritas_v85.counterfactual import PathPoint
from .adaptive import Attribution,attribute_episode,observed_stop_grid,summarize_attributions,context_key


def attribution_from_json(payload:str)->Attribution:
    x=json.loads(payload)
    x['known_at']=utc(x['known_at'])
    for k in ('direction_return','net_return','mfe','mae','entry_heat_before_first_favorable','stop_distance_fraction','exit_giveback'):
        x[k]=decimal(x[k])
    if x.get('capture_ratio') is not None:x['capture_ratio']=decimal(x['capture_ratio'])
    return Attribution(**x)


class AdaptiveService:
    def __init__(self,ledger,snapshot:SnapshotStore,instruments,account_id:str):
        self.ledger=ledger;self.snapshot=snapshot;self.instruments=instruments;self.account_id=account_id

    def _process_new_closed(self,at:datetime)->int:
        at=utc(at);written=0
        with self.ledger.transaction() as c:
            episodes=c.execute("""SELECT e.* FROM v85_episodes e LEFT JOIN v86_episode_attribution a ON a.episode_id=e.episode_id
                                  WHERE e.account_id=? AND e.status='CLOSED' AND e.closed_at<=? AND a.episode_id IS NULL
                                  ORDER BY e.closed_at,e.episode_id LIMIT 250""",(self.account_id,at.isoformat())).fetchall()
            for ep in episodes:
                pay=json.loads(ep['payload'])
                pos_data=pay.get('position')
                outcome=pay.get('outcome')
                sig=pay.get('signal') or {}
                if not pos_data or not outcome:continue  # legacy/malformed episodes stay auditable but do not train v86
                try:pos=position_from_dict(pos_data)
                except Exception:continue
                orders=c.execute('SELECT * FROM v85_orders WHERE episode_id=? ORDER BY at,intent_id',(ep['episode_id'],)).fetchall()
                closing=next((o for o in reversed(orders) if o['side'] in ('SELL','COVER')),None)
                if closing is None:continue
                path=c.execute('SELECT event_id,at,price FROM v85_path WHERE episode_id=? ORDER BY at,event_id',(ep['episode_id'],)).fetchall()
                prices=[x['price'] for x in path]+[closing['price']]
                ctx={'asset':ep['asset'],'horizon':pos.horizon,'setup':sig.get('setup_family','UNCLASSIFIED'),'regime':sig.get('regime','UNKNOWN')}
                attr=attribute_episode(episode_id=ep['episode_id'],account_id=self.account_id,direction=pos.direction,
                      entry_price=pos.entry_price,exit_price=closing['price'],entry_nav=pay.get('entry_nav'),initial_stop=pos.initial_stop,
                      outcome=outcome,path_prices=prices,context=ctx,known_at=ep['closed_at'])
                c.execute('INSERT INTO v86_episode_attribution VALUES(?,?,?,?,?)',
                          (attr.episode_id,attr.account_id,attr.known_at.isoformat(),attr.context_key,canonical_json(asdict(attr))))
                points=[]
                for x in path:
                    points.append(PathPoint(str(x['event_id']),utc(x['at']),utc(x['at']),decimal(x['price'],positive=True)))
                # The actual closing quote is observable and appended to the replay path.
                points.append(PathPoint(str(closing['event_id']),utc(closing['at']),utc(closing['at']),decimal(closing['price'],positive=True)))
                for cf in observed_stop_grid(episode_id=ep['episode_id'],direction=pos.direction,entry_price=pos.entry_price,
                        initial_stop=pos.initial_stop,quantity=pos.quantity,instrument=self.instruments[pos.asset],
                        opened_at=pos.opened_at,closed_at=utc(ep['closed_at']),known_at=at,path_points=points):
                    c.execute('INSERT INTO v86_counterfactuals VALUES(?,?,?,?) ON CONFLICT(episode_id,scenario_id) DO NOTHING',
                              (ep['episode_id'],cf['scenario_id'],at.isoformat(),canonical_json(cf)))
                written+=1
        return written

    def refresh(self,at:datetime)->dict:
        at=utc(at)
        try:
            new=self._process_new_closed(at)
            with self.ledger.read() as c:
                rows=c.execute('SELECT payload FROM v86_episode_attribution WHERE account_id=? AND known_at<=? ORDER BY known_at,episode_id',
                               (self.account_id,at.isoformat())).fetchall()
            attrs=[attribution_from_json(r['payload']) for r in rows]
            groups={}
            for a in attrs:groups.setdefault(a.context_key,[]).append(a)
            items=[{'context_key':k,**summarize_attributions(v)} for k,v in sorted(groups.items())]
            overall=summarize_attributions(attrs)
            payload={'status':'OK','account_id':self.account_id,'known_as_of':at.isoformat(),'items':items,'overall':overall,
                     'new_attributions':new,'automatic_positive_promotion':False,
                     'learning_scope':'CLOSED_V86_EPISODES_ONLY; OBSERVED_PATH; NO_CAUSAL_CLAIM_FROM_PNL'}
            gen=self.snapshot.publish(payload,at)
            return {'status':'OK','generation':gen,'new_attributions':new,'contexts':len(items),'episodes':len(attrs)}
        except Exception as exc:
            self.snapshot.failure(type(exc).__name__+': '+str(exc))
            return {'status':'ERROR','error':type(exc).__name__+': '+str(exc)}


class AdaptiveView:
    """Decision read path: snapshot only, never scans the ledger."""
    def __init__(self,snapshot:SnapshotStore,*,positive_authority:bool=False):
        self.snapshot=snapshot;self.positive_authority=positive_authority

    def for_signal(self,signal,policy_version:str,at:datetime):
        at=utc(at);s=self.snapshot.read(at)
        if not s.may_influence_decisions or s.payload is None:
            return LearningAdjustment(D('1'),D('0'),'V86_MEMORY_STALE_OR_UNAVAILABLE')
        data=json.loads(s.payload)
        key=context_key(signal.asset,signal.horizon,signal.setup_family,signal.direction.value,signal.regime)
        item=next((x for x in data.get('items',()) if x.get('context_key')==key),None)
        if not item:return LearningAdjustment(D('1'),D('0'),'V86_NO_EXACT_CONTEXT')
        applied=decimal(item.get('applied_size_multiplier') or '1',nonnegative=True)
        prior=decimal(item.get('direction_prior') or '0')
        # Direction learner can only attenuate an upstream direction before a validated gate.
        if prior<=D('-.015'):applied=min(applied,D('.85'))
        proposed=decimal(item.get('proposed_positive_multiplier') or '1',nonnegative=True)
        if self.positive_authority and proposed>1:applied=max(applied,min(proposed,D('1.10')))
        else:applied=min(applied,D('1'))
        return LearningAdjustment(applied,prior,str(item.get('reason') or 'V86_ADAPTIVE'),automatic_promotion=False)


class CompositeExperienceView:
    def __init__(self,base=None,adaptive=None):self.base=base;self.adaptive=adaptive
    def for_signal(self,signal,policy_version,at):
        b=self.base.for_signal(signal,policy_version,at) if self.base else LearningAdjustment(D('1'),D('0'),'NO_V85_BASE')
        a=self.adaptive.for_signal(signal,policy_version,at) if self.adaptive else LearningAdjustment(D('1'),D('0'),'NO_V86_ADAPTIVE')
        mult=max(D('.25'),min(D('1.10'),b.size_multiplier*a.size_multiplier))
        # Before positive authority, composition can never create more exposure than the validated base requested.
        if not getattr(self.adaptive,'positive_authority',False):mult=min(mult,b.size_multiplier,D('1'))
        prior=max(D('-.04'),min(D('.04'),b.direction_prior+a.direction_prior))
        return LearningAdjustment(mult,prior,'COMPOSITE:'+b.reason+'+'+a.reason,
                                  b.validation_id or a.validation_id,automatic_promotion=False)
