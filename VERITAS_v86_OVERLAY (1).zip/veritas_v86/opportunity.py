"""Opportunity-capture ledger: prevents win-rate improvement by simply avoiding trades."""
from __future__ import annotations
from dataclasses import asdict
from datetime import timedelta
import json
from veritas_v85.domain import D,Direction,HORIZON_SECONDS,canonical_json,decimal,stable_id,utc
from .portfolios import PROFILES,signal_allowed

MOVE=D('.004')


def _acted_accounts(result:dict,asset:str)->set[str]:
    out=set()
    for p in result.get('portfolios') or ():
        for a in p.get('actions') or ():
            if a.get('asset')!=asset:continue
            if any(e.get('action')=='OPEN' for e in a.get('events') or ()):out.add(p.get('name'))
    return {x for x in out if x}


def record_opportunities(ledger,routes,result,quotes,rows,at)->int:
    at=utc(at);n=0
    acted_by_asset={a:_acted_accounts(result,a) for a in routes.signals}
    with ledger.transaction() as c:
        for asset,s in routes.signals.items():
            q=quotes.get(asset)
            if q is None:continue
            ids=sorted(e.information_id for e in s.confirmations if e.known_at<=at)
            anchor=ids[-1] if ids else s.decision_id
            oid=stable_id('OPP86_',s.idea_id,anchor,s.direction.value,s.horizon)
            old=c.execute('SELECT payload FROM v86_opportunities WHERE opportunity_id=?',(oid,)).fetchone()
            eligible=[name for name,p in PROFILES.items() if signal_allowed(p,s,rows)]
            acted=sorted(acted_by_asset.get(asset,set()))
            if old:
                payload=json.loads(old['payload']);payload['acted_accounts']=sorted(set(payload.get('acted_accounts',()))|set(acted))
                payload['eligible_accounts']=sorted(set(payload.get('eligible_accounts',()))|set(eligible))
                c.execute('UPDATE v86_opportunities SET payload=? WHERE opportunity_id=?',(canonical_json(payload),oid));continue
            mature=at+timedelta(seconds=HORIZON_SECONDS[s.horizon])
            payload={'status':'OPEN','idea_id':s.idea_id,'decision_id':s.decision_id,'eligible_accounts':eligible,
                     'acted_accounts':acted,'source_event_id':q.event_id,'maturity_price_method':'FIRST_VERIFIED_QUOTE_AT_OR_AFTER_HORIZON',
                     'meaningful_move_threshold':str(MOVE)}
            c.execute('INSERT INTO v86_opportunities VALUES(?,?,?,?,?,?,?,?,?,?)',
                      (oid,asset,s.horizon,s.direction.value,s.setup_family,s.regime,at.isoformat(),mature.isoformat(),str(q.price),canonical_json(payload)))
            n+=1
    return n


def mature_opportunities(ledger,quotes,specs,at)->int:
    at=utc(at);done=0
    with ledger.transaction() as c:
        rows=c.execute('SELECT * FROM v86_opportunities WHERE mature_at<=? ORDER BY mature_at',(at.isoformat(),)).fetchall()
        for r in rows:
            p=json.loads(r['payload'])
            if p.get('status')!='OPEN':continue
            q=quotes.get(r['asset'])
            if q is None or q.problem(at,specs[r['asset']]) is not None:continue
            entry=decimal(r['entry_price'],positive=True);d=Direction(r['direction']);move=d.sign*(q.price/entry-D('1'))
            p.update({'status':'MATURE','matured_at':at.isoformat(),'maturity_event_id':q.event_id,'maturity_price':str(q.price),
                      'directional_move':str(move),'meaningful_favorable':move>=MOVE,'meaningful_adverse':move<=-MOVE})
            c.execute('UPDATE v86_opportunities SET payload=? WHERE opportunity_id=?',(canonical_json(p),r['opportunity_id']));done+=1
    return done


def capture_metrics(ledger,account_id:str)->dict:
    with ledger.read() as c: rows=c.execute('SELECT payload FROM v86_opportunities').fetchall()
    matured=[]
    for r in rows:
        p=json.loads(r['payload'])
        if p.get('status')=='MATURE' and account_id in p.get('eligible_accounts',()):matured.append(p)
    favorable=[p for p in matured if p.get('meaningful_favorable') is True]
    adverse=[p for p in matured if p.get('meaningful_adverse') is True]
    captured=[p for p in favorable if account_id in p.get('acted_accounts',())]
    false=[p for p in adverse if account_id in p.get('acted_accounts',())]
    acted=[p for p in matured if account_id in p.get('acted_accounts',())]
    return {'matured_opportunities':len(matured),'meaningful_favorable':len(favorable),'captured_favorable':len(captured),
            'opportunity_capture_rate':(len(captured)/len(favorable) if favorable else None),
            'acted_matured':len(acted),'false_entry_rate':(len(false)/len(acted) if acted else None),
            'missed_meaningful':len(favorable)-len(captured)}
