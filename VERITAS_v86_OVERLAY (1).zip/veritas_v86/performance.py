"""Performance gate for v86 challengers. No promotion on insufficient evidence."""
from __future__ import annotations
import json
from veritas_v85.domain import D,decimal,canonical_json,stable_id,utc,ZERO
from .opportunity import capture_metrics


def account_metrics(ledger,account_id:str)->dict:
    with ledger.read() as c:
        a=c.execute('SELECT initial_equity FROM v85_accounts WHERE account_id=?',(account_id,)).fetchone()
        rows=c.execute("SELECT closed_at,net_pnl,payload FROM v85_episodes WHERE account_id=? AND status='CLOSED' ORDER BY closed_at,episode_id",(account_id,)).fetchall()
    initial=decimal(a['initial_equity'],positive=True) if a else D('1000000')
    vals=[]
    equity=initial;hwm=initial;maxdd=ZERO
    for r in rows:
        if r['net_pnl'] is None:continue
        pnl=decimal(r['net_pnl']);pay=json.loads(r['payload']);nav=decimal(pay.get('entry_nav') or initial,positive=True)
        ret=pnl/nav;vals.append(ret);equity+=pnl;hwm=max(hwm,equity);maxdd=max(maxdd,ONE-equity/hwm)
    n=len(vals);wins=sum(v>0 for v in vals);gain=sum((v for v in vals if v>0),ZERO);loss=-sum((v for v in vals if v<0),ZERO)
    opp=capture_metrics(ledger,account_id)
    return {'closed_trades':n,'win_rate':wins/n if n else None,'expectancy':float(sum(vals,ZERO)/D(n)) if n else None,
            'profit_factor':float(gain/loss) if loss>0 else None,'total_return':float((equity/initial)-D('1')),
            'max_drawdown':float(maxdd),**opp}


# local constant avoids importing ONE through a wildcard
ONE=D('1')


def compare(ledger,challenger:str,control:str='Champion')->dict:
    c=account_metrics(ledger,control);x=account_metrics(ledger,challenger)
    enough=c['closed_trades']>=30 and x['closed_trades']>=30 and (c['meaningful_favorable']>=20 and x['meaningful_favorable']>=20)
    checks={
      'win_rate_target_65': x['win_rate'] is not None and x['win_rate']>=.65,
      'win_rate_not_below_control': x['win_rate'] is not None and c['win_rate'] is not None and x['win_rate']>=c['win_rate'],
      'expectancy_positive': x['expectancy'] is not None and x['expectancy']>0,
      'profit_factor_adequate': x['profit_factor'] is not None and x['profit_factor']>=1.20,
      'drawdown_within_10pct': x['max_drawdown']<=.10,
      'capture_not_below_control': x['opportunity_capture_rate'] is not None and c['opportunity_capture_rate'] is not None and x['opportunity_capture_rate']>=c['opportunity_capture_rate'],
    }
    status='PASS' if enough and all(checks.values()) else ('INSUFFICIENT_EVIDENCE' if not enough else 'FAIL')
    return {'status':status,'control':control,'challenger':challenger,'control_metrics':c,'challenger_metrics':x,
            'checks':checks,'promotion_authority':status=='PASS'}


def persist_gate(ledger,result,at)->str:
    at=utc(at);gid=stable_id('GATE86_',result['control'],result['challenger'],at.date().isoformat(),result['challenger_metrics'].get('closed_trades'))
    with ledger.transaction() as c:
        c.execute('INSERT INTO v86_performance_gates VALUES(?,?,?) ON CONFLICT(gate_id) DO UPDATE SET known_at=excluded.known_at,payload=excluded.payload',
                  (gid,at.isoformat(),canonical_json(result)))
    return gid
