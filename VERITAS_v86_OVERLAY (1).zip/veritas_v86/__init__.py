"""VERITAS v86 adaptive-learning layer over the audited v85 execution core."""
VERSION = "86.0.0-dev1"
SCHEMA_VERSION = 1
