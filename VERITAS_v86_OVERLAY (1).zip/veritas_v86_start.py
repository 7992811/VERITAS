"""Development entry point for isolated VERITAS v86 acceptance only."""
import veritas_intelligence as model
from veritas_v86.application import run

model.VERSION='veritas-max-product-v86.0-dev1-adaptive'

if __name__=='__main__':
    run(model)
