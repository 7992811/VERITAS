from __future__ import annotations
import json,platform,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def run(cmd):
    return subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True)

def main():
    t=time.perf_counter()
    base=run([sys.executable,'tools/run_checks.py'])
    if base.returncode:
        sys.stdout.write(base.stdout);sys.stderr.write(base.stderr);raise SystemExit(base.returncode)
    v86=run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_v86_*.py','-v'])
    sys.stdout.write(v86.stdout);sys.stderr.write(v86.stderr)
    out={'scope':'V86_ADAPTIVE_OVER_V85_AUDITED_CORE','base_v85_suite_passed':base.returncode==0,
         'v86_suite_passed':v86.returncode==0,'duration_seconds':time.perf_counter()-t,
         'python':platform.python_version(),'production_integrated':False,'performance_improvement_demonstrated':False,
         'portfolio_count':8,'positive_auto_promotion':False}
    (ROOT/'reports/V86_LOCAL_TEST_RESULTS.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))
    raise SystemExit(v86.returncode)
if __name__=='__main__':main()
