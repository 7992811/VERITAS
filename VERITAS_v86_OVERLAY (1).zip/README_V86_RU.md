# VERITAS v86 Adaptive Learning — development candidate

v86 строится поверх прошедшего CI статического ядра v85 и не изменяет `main` или действующий production.

## Что добавлено

- 8 независимых модельных портфелей: Champion, Challenger, Impulse, Trend, Range, Reversal, Event, RelativeValue.
- Профиль риска отдельно для каждого мандата. Hard drawdown: 10% для базовых портфелей, 12% для Impulse/Event, 8% для RelativeValue.
- Ограничение риска одной идеи через расстояние до стопа: 1.0–2.0% NAV в зависимости от мандата при сохранении возможности крупного номинального размера при узком стопе.
- Episode Attribution: отдельно направление, net outcome, MFE/MAE, capture ratio, ранняя неблагоприятная траектория, giveback и причина выхода.
- Counterfactual replay на наблюдавшемся пути для 0.75x / 1.0x / 1.25x стоп-дистанции. Никакого выдуманного intrabar path.
- Direction Learner подключён в безопасном режиме: отрицательная история может уменьшить размер; положительная не создаёт позицию и не увеличивает риск без gate.
- Entry/Exit Learner формирует тестируемые гипотезы: staged entry, partial take-profit, trailing, exit/re-entry.
- Opportunity Capture Ledger: система считает не только win-rate, но и пропущенные качественные движения, чтобы нельзя было «улучшить» win-rate отказом от большинства сделок.
- Performance Gate: Challenger/специализированный портфель сравнивается с Champion по win-rate, expectancy, profit factor, drawdown и capture rate.
- Positive auto-promotion по умолчанию отключён. PASS gate создаёт разрешение для следующего контролируемого этапа, но сам по себе не меняет production.

## Важное ограничение Relative Value

RelativeValue создаётся как восьмой независимый мандат и накапливает shadow opportunities, но одиночное исполнение заблокировано. Реальные pair/spread сделки будут включены только после отдельного двухногого execution/risk engine, чтобы не выдавать directional single-leg за relative value.

## Текущий статус

Development/acceptance only. Локальная проверка включает полный набор v85 и новые тесты v86. Историческое превосходство v86 над v85 пока не заявляется: для этого нужен отдельный backtest / walk-forward / OOS performance run на одинаковом наборе рыночных событий.
