"""PostgreSQL acceptance for the additive v86 schema.

Intentionally restricted to the same ephemeral localhost database used by the
v85 acceptance workflow. It never falls back to production.
"""
from __future__ import annotations

import os
import unittest
from urllib.parse import urlparse

from veritas_v85.postgres import PostgresLedger
from veritas_v86.schema import ensure_schema
from veritas_v86.portfolios import PROFILES

DSN = os.environ.get("VERITAS_V85_TEST_DATABASE_URL", "")


def _guard_test_database() -> None:
    u = urlparse(DSN)
    if (
        u.hostname not in {"127.0.0.1", "localhost"}
        or (u.path or "") != "/veritas_v85_ci"
        or os.environ.get("VERITAS_V85_EPHEMERAL_DB") != "1"
    ):
        raise SystemExit(
            "REFUSED: requires localhost/veritas_v85_ci and explicit ephemeral-test flag. "
            "No production fallback."
        )


@unittest.skipUnless(DSN, "VERITAS_V85_TEST_DATABASE_URL not set")
class V86PostgresSchemaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        _guard_test_database()
        cls.ledger = PostgresLedger(DSN)
        ensure_schema(cls.ledger)

    @classmethod
    def tearDownClass(cls):
        cls.ledger.close()

    def test_v86_tables_exist(self):
        expected = {
            "v86_portfolio_profiles",
            "v86_episode_attribution",
            "v86_counterfactuals",
            "v86_opportunities",
            "v86_performance_gates",
        }
        with self.ledger.read() as tx:
            rows = tx.execute(
                """
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema='public' AND table_name IN (
                    'v86_portfolio_profiles',
                    'v86_episode_attribution',
                    'v86_counterfactuals',
                    'v86_opportunities',
                    'v86_performance_gates'
                )
                """
            ).fetchall()
        found = {r["table_name"] for r in rows}
        self.assertTrue(expected.issubset(found), (expected, found))

    def test_all_eight_portfolio_profiles_persist(self):
        with self.ledger.read() as tx:
            rows = tx.execute(
                "SELECT account_id, mandate, payload FROM v86_portfolio_profiles ORDER BY account_id"
            ).fetchall()
        self.assertEqual(len(PROFILES), 8)
        self.assertEqual({r["account_id"] for r in rows}, set(PROFILES))

    def test_profile_risk_limits_are_bounded(self):
        for p in PROFILES.values():
            self.assertLessEqual(p.hard_drawdown, 0.12)
            self.assertLessEqual(p.stop_risk_nav, 0.02)
            self.assertGreater(p.stop_risk_nav, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
