import json,tempfile,unittest
from pathlib import Path
from datetime import timedelta
from decimal import Decimal as D
from veritas_v85.storage import SQLiteLedger
from veritas_v85.book import PaperBook
from veritas_v85.risk import RiskLimits
from veritas_v85.snapshots import SnapshotStore
from veritas_v85.domain import Instrument
from common import T,quote,signal
from veritas_v86.schema import ensure_schema
from veritas_v86.adaptive_store import AdaptiveService,AdaptiveView
from veritas_v86.portfolios import PROFILES,risk_state,signal_allowed


class PortfolioDesignTests(unittest.TestCase):
    def test_exactly_eight_mandates(self):
        self.assertEqual(len(PROFILES),8)
        self.assertEqual(set(PROFILES),{'Champion','Challenger','Impulse','Trend','Range','Reversal','Event','RelativeValue'})
    def test_risk_hard_stop_is_not_22_percent(self):
        self.assertTrue(risk_state(PROFILES['Champion'],D('.10'))['hard_stop'])
        self.assertFalse(risk_state(PROFILES['Champion'],D('.099'))['hard_stop'])
    def test_relative_value_execution_disabled(self):
        self.assertFalse(PROFILES['RelativeValue'].execution_enabled)
    def test_trend_does_not_take_reversal(self):
        s=signal(setup_family='TACTICAL_REVERSAL')
        self.assertFalse(signal_allowed(PROFILES['Trend'],s,[]))
        self.assertTrue(signal_allowed(PROFILES['Reversal'],s,[]))


class AdaptiveLearningTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.l=SQLiteLedger(Path(self.tmp.name)/'x.sqlite');ensure_schema(self.l)
        self.spec={'BTC':Instrument('BTC','RUB','RUB')};self.b=PaperBook(self.l,self.spec)
        self.b.create_account('Challenger',D('1000000'),'p1');self.s=SnapshotStore(ttl_seconds=1200,max_bytes=524288)
        self.svc=AdaptiveService(self.l,self.s,self.spec,'Challenger')
    def tearDown(self):self.tmp.cleanup()
    def test_closed_episode_gets_attribution_and_counterfactuals(self):
        limits=RiskLimits(D('2'),D('1'),D('.02'))
        self.b.process('Challenger','BTC','o',T,quote(event='o'),signal(setup_family='TREND',regime='TREND'),limits)
        t2=T+timedelta(minutes=10)
        self.b.process('Challenger','BTC','m',t2,quote('102',t2,'m'),None,limits)
        t3=T+timedelta(minutes=20)
        self.b.process('Challenger','BTC','x',t3,quote('101.8',t3,'x'),None,limits,portfolio_hard_stop=True)
        r=self.svc.refresh(t3)
        self.assertEqual(r['new_attributions'],1)
        with self.l.read() as c:
            a=json.loads(c.execute('SELECT payload FROM v86_episode_attribution').fetchone()['payload'])
            cf=c.execute('SELECT count(*) n FROM v86_counterfactuals').fetchone()['n']
        self.assertEqual(a['label'],'RIGHT_DIRECTION_HIGH_CAPTURE');self.assertEqual(cf,3)
    def test_negative_snapshot_can_reduce_not_increase(self):
        # Direct snapshot avoids manufacturing eight trades in a unit test.
        key='BTC|1h|TREND|LONG|TREND'
        self.s.publish({'status':'OK','account_id':'Challenger','known_as_of':T.isoformat(),'items':[{
            'context_key':key,'applied_size_multiplier':'0.5','proposed_positive_multiplier':'1.1','direction_prior':'-0.02','reason':'NEGATIVE'}]},T)
        v=AdaptiveView(self.s,positive_authority=False).for_signal(signal(setup_family='TREND',regime='TREND'),'p1',T)
        self.assertLessEqual(v.size_multiplier,D('.5'))
        self.assertLess(v.direction_prior,D('0'))
