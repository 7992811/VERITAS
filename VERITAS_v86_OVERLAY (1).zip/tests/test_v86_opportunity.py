import tempfile,unittest,json
from pathlib import Path
from datetime import timedelta
from decimal import Decimal as D
from veritas_v85.storage import SQLiteLedger
from veritas_v85.routing import Route
from common import T,quote,signal,SPEC
from veritas_v86.schema import ensure_schema
from veritas_v86.opportunity import record_opportunities,mature_opportunities,capture_metrics

class OpportunityTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.l=SQLiteLedger(Path(self.tmp.name)/'x.sqlite');ensure_schema(self.l)
    def tearDown(self):self.tmp.cleanup()
    def test_capture_and_miss_are_measured(self):
        s=signal(setup_family='TREND',regime='TREND')
        routes=Route({'BTC':s},())
        result={'portfolios':[{'name':'Champion','actions':[{'asset':'BTC','events':[{'action':'OPEN'}]}]},
                              {'name':'Challenger','actions':[{'asset':'BTC','events':[]}]}]}
        record_opportunities(self.l,routes,result,{'BTC':quote(event='q0')},[{'asset':'BTC','horizon':'1h'}],T)
        at=T+timedelta(hours=1,seconds=1)
        mature_opportunities(self.l,{'BTC':quote('101',at,'q1')},{'BTC':SPEC},at)
        c=capture_metrics(self.l,'Champion');x=capture_metrics(self.l,'Challenger')
        self.assertEqual(c['opportunity_capture_rate'],1.0)
        self.assertEqual(x['opportunity_capture_rate'],0.0)
        self.assertEqual(x['missed_meaningful'],1)

class PerformanceGateTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.l=SQLiteLedger(Path(self.tmp.name)/'g.sqlite');ensure_schema(self.l)
        from veritas_v85.book import PaperBook
        PaperBook(self.l,{'BTC':SPEC}).create_account('Champion',D('1000000'),'pC')
        PaperBook(self.l,{'BTC':SPEC}).create_account('Challenger',D('1000000'),'pX')
    def tearDown(self):self.tmp.cleanup()
    def _seed(self,account,wins):
        from veritas_v85.domain import canonical_json
        with self.l.transaction() as c:
            for i in range(30):
                pnl=D('1000') if i<wins else D('-500')
                payload=canonical_json({'entry_nav':'1000000'})
                t=(T+timedelta(minutes=i)).isoformat()
                c.execute('INSERT INTO v85_episodes VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                          (f'{account}-{i}',account,'BTC',f'i{i}',account,t,t,'o','x','CLOSED',payload,str(pnl)))
            for i in range(20):
                oid=f'{account}-opp-{i}';p=canonical_json({'status':'MATURE','eligible_accounts':[account],
                    'acted_accounts':[account],'meaningful_favorable':True,'meaningful_adverse':False})
                c.execute('INSERT INTO v86_opportunities VALUES(?,?,?,?,?,?,?,?,?,?)',
                          (oid,'BTC','1h','LONG','TREND','TREND',T.isoformat(),(T+timedelta(hours=1)).isoformat(),'100',p))
    def test_gate_can_pass_only_with_evidence(self):
        from veritas_v86.performance import compare
        self._seed('Champion',20);self._seed('Challenger',21)
        g=compare(self.l,'Challenger')
        self.assertEqual(g['status'],'PASS');self.assertTrue(g['promotion_authority'])
