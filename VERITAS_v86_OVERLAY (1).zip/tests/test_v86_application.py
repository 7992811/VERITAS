import importlib.util,os,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from veritas_v85.storage import SQLiteLedger
from veritas_v85.config import Settings
from veritas_v85.domain import stable_id
from veritas_v86.application import Application
from veritas_v86.portfolios import ORDER
from tools.fixtures import bundles

ROOT=Path(__file__).resolve().parents[1]

def model_fixture(directory):
    name='vi_v86_'+stable_id('',str(directory))
    with patch.dict(os.environ,{'DATABASE_URL':'','VERITAS_KNOWLEDGE_AUTOMATION':'0'}):
        sp=importlib.util.spec_from_file_location(name,ROOT/'veritas_intelligence.py')
        m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m)
    m.DB_PATH=str(Path(directory)/'analysis.sqlite');m.emitted=[];m.emit=lambda event,**kw:m.emitted.append({'event':event,**kw})
    return m

class V86ApplicationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.m=model_fixture(self.tmp.name);self.l=SQLiteLedger(Path(self.tmp.name)/'paper.sqlite')
        self.app=Application(self.m,self.l,Settings(mode='fixture',testing=True),fixture_bundles=bundles(self.m));self.app.bootstrap()
    def tearDown(self):self.app.close();self.tmp.cleanup()
    def test_all_eight_accounts_exist(self):
        self.assertEqual(tuple(x for x in ORDER if x in self.app.books),ORDER)
    def test_relative_value_cannot_open_single_leg(self):
        self.assertFalse(self.app.portfolio_report()['portfolios'][[p['name'] for p in self.app.portfolio_report()['portfolios']].index('RelativeValue')]['mandate']['execution_enabled'])
