"""Produces a staging candidate only if actual reports and manifest agree.
It never deploys, changes billing, or writes the user's production database.
"""
import sys,json,hashlib,zipfile,argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from veritas_v85.validation import verify_release

def accepted():
    verify_release(ROOT)
    digest=hashlib.sha256((ROOT/'release_manifest.json').read_bytes()).hexdigest()
    for file in ('test_results.json','postgres_results.json'):
        r=json.loads((ROOT/'reports'/file).read_text())
        if not r.get('tests_run') or r.get('errors') or r.get('failures') or r.get('skipped'):
            raise RuntimeError('Acceptance failed: '+file)
        if r.get('release_manifest_sha256')!=digest:raise RuntimeError('Tests were run on a different assembled release: '+file)
    pg=json.loads((ROOT/'reports/postgres_results.json').read_text())
    if pg.get('real_postgres_tested') is not True:raise RuntimeError('Real PostgreSQL acceptance missing')
    http=json.loads((ROOT/'reports/http_smoke.json').read_text())
    if not http.get('success') or http.get('sigterm_exit_code')!=0 or http.get('release_manifest_sha256')!=digest:
        raise RuntimeError('HTTP process acceptance missing or stale')
    return digest

def main():
    p=argparse.ArgumentParser();p.add_argument('--acceptance',action='store_true');a=p.parse_args()
    if not a.acceptance:raise SystemExit('Use --acceptance; no unchecked deploy artifact is produced')
    digest=accepted();out=ROOT/'dist';out.mkdir(exist_ok=True)
    mark={'status':'CI_PASSED_STAGING_CANDIDATE','manifest_sha256':digest,
          'production_deployed':False,'production_cutover_rehearsed':False,
          'live_source_coverage_verified':False,'historical_win_rate_improvement_proven':False}
    (ROOT/'reports/staging_acceptance.json').write_text(json.dumps(mark,indent=2))
    path=out/'VERITAS_v85_STAGING.zip'
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for f in sorted(ROOT.rglob('*')):
            r=f.relative_to(ROOT)
            if not f.is_file() or any(x in r.parts for x in ('.git','__pycache__','dist','.pytest_cache')):continue
            if f.suffix in ('.pyc','.sqlite','.sqlite3','.db'):continue
            if f.name=='.env':continue
            z.write(f,str(r))
    print(path);print(hashlib.sha256(path.read_bytes()).hexdigest())
if __name__=='__main__':main()
