"""Build-time-only assembly. Runtime never downloads, execs or rewrites source.

A source ZIP of old main did not contain its cumulative v80 dependency. CI retrieves
that exact historical blob once, verifies its Git object id, and evaluates ONLY
literal patch tables (not its executable apply()/imports). The resulting source is
then compiled, integration-tested and hashed. --offline-base is TEST ONLY.
"""
from __future__ import annotations
import argparse, ast, hashlib, json, os, py_compile, sys, tempfile
from pathlib import Path
from urllib.request import Request,urlopen
ROOT=Path(__file__).resolve().parents[1]
VERSION='veritas-max-product-v85.0-rc2-static'
PIN='https://raw.githubusercontent.com/7992811/VERITAS/8d7fd5f3e2cccf262b677707bad57d6e1e5acbc2/sitecustomize.py'
BLOB='eb786ca95d7bfa957d0eb95b6a840473bd0a2faf'


def table(text,name):
    tree=ast.parse(text)
    nodes=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets)]
    if len(nodes)!=1: raise RuntimeError('Expected one literal table: '+name)
    rows=ast.literal_eval(nodes[0].value)
    if not all(isinstance(x,tuple) and len(x)==3 and all(isinstance(v,str) for v in x) for x in rows):
        raise RuntimeError('Nonliteral or malformed legacy patch table')
    return list(rows)


def apply_table(src,rows,log):
    for old,new,label in rows:
        if old in src: src=src.replace(old,new,1); log.append({'label':label,'status':'APPLIED'})
        elif new in src: log.append({'label':label,'status':'ALREADY_PRESENT'})
        else: raise RuntimeError('Missing legacy anchor: '+label)
    return src


def fn_replace(src,name,new):
    nodes=[n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name==name]
    if not nodes: raise RuntimeError('Missing function '+name)
    # Replace every old definition: no shadow legacy writer remains callable.
    lines=src.splitlines(keepends=True)
    for n in reversed(nodes): lines[n.lineno-1:n.end_lineno]=[new.rstrip()+'\n']
    return ''.join(lines)


def replace_unique(src,old,new,label):
    if src.count(old)!=1: raise RuntimeError(f'{label}: expected one anchor, got {src.count(old)}')
    return src.replace(old,new,1)


def static_integration(src):
    src=src.replace("tr_reasons=tr.get('reasons') or {}","tr_reasons=tr.get('reasons') if isinstance(tr.get('reasons'),dict) else {}")
    t=ast.parse(src); lines=src.splitlines(keepends=True)
    for n in reversed(t.body):
        if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='VERSION' for x in n.targets):
            lines[n.lineno-1:n.end_lineno]=[f'VERSION = {VERSION!r}\n']
    src=''.join(lines)
    # Old entry/exit writers are replaced with read-only projections of the v85 journal.
    for name,new in {
        'manage_trade_alerts':"def manage_trade_alerts(summary):\n    return []  # v85 PaperBook is the sole execution owner",
        'sync_shadow_trade_lifecycle':"def sync_shadow_trade_lifecycle(summary):\n    return {'status':'OWNED_BY_V85','events':0}",
        'maybe_schedule_heavy_learning':"def maybe_schedule_heavy_learning(reason='scheduled', force=False):\n    return False  # v85 runs a bounded maintenance lane, not overlapping legacy schedulers",
        'main':"def main():\n    import sys\n    from veritas_v85.application import run\n    run(sys.modules[__name__])",
    }.items(): src=fn_replace(src,name,new)
    # Attach truthful source metadata while source-specific local timestamps are available.
    names={'market','_ndx_market','_yahoo_research_futures_market','_moex_market','_cnyrubf_market'}
    t=ast.parse(src); lines=src.splitlines(keepends=True)
    returns=[]
    for n in t.body:
        if isinstance(n,ast.FunctionDef) and n.name in names:
            for r in ast.walk(n):
                if isinstance(r,ast.Return) and isinstance(r.value,ast.Dict):
                    keys=[k.value if isinstance(k,ast.Constant) else None for k in r.value.keys]
                    if 'price' in keys and 'asset' in keys: returns.append(r)
    for n in sorted(returns,key=lambda n:n.lineno,reverse=True):
        original=ast.get_source_segment(src,n.value)
        indent=' '*n.col_offset
        lines[n.lineno-1:n.end_lineno]=[indent+'return _v85_annotate_market('+original+', locals())\n']
    src=''.join(lines)
    src='from veritas_v85.providers import annotate_market as _v85_annotate_market\n'+src
    # Call the new owner with raw quote provenance, not only postprocessed candidates.
    t=ast.parse(src); n=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='cycle')
    cycle=ast.get_source_segment(src,n)
    old="""    if VP is not None and pg_enabled():
        try:
            portfolio_autopilot=VP.step_all(
                summary=summary, pg_connect=pg_connect, model_version=VERSION,
                observed_at=now(), commission_rate=0.0005,
                emit=lambda event, **kw: emit(event, **kw))
        except Exception as ex:
            portfolio_autopilot={'status':'ERROR','error':f'{type(ex).__name__}: {ex}'}
            emit('portfolio_autopilot_error',error=portfolio_autopilot['error'])"""
    new="""    # Single v85 execution owner; flush durable decisions before any paper order.
    if _V85_APP is not None:
        portfolio_autopilot=_V85_APP.commit_cycle(summary,market_bundles,cycle_id,clock_ok=clock_info.get('ok') is True)
    else:
        portfolio_autopilot={'status':'NOT_CONFIGURED','reason':'V85_APP_REQUIRED'}"""
    cycle=replace_unique(cycle,old,new,'single-owner integration')
    cycle=replace_unique(cycle,'    phase_t0=time.time(); outcomes = evaluate_outcomes();',
                        '    phase_t0=time.time(); outcomes = 0;','outcomes off execution path')
    # Keep every instrument/horizon visible when a source fails, without inventing a price.
    old="    storage = pg_storage_status()\n    expected = len(ASSETS)*len(HORIZONS)"
    new="""    present={(x.get('asset'),x.get('horizon')) for x in summary}
    for _symbol,(_asset,_cb) in ASSETS.items():
        for _h in HORIZONS:
            if (_asset,_h) not in present:
                _err=next((x.get('error') for x in errors if x.get('asset')==_asset),'SOURCE_OR_MODEL_UNAVAILABLE')
                summary.append({'asset':_asset,'horizon':_h,'decision':'NO_TRADE','research_decision':'NO_TRADE',
                                'price':None,'source_gate_pass':False,'market_open':False,'blocked_reason':_err,
                                'trade_plan':{'eligible':False,'reason':_err}})
    storage = pg_storage_status()
    expected = len(ASSETS)*len(HORIZONS)"""
    cycle=replace_unique(cycle,old,new,'blocked cells')
    cycle=replace_unique(cycle,'    if pg_enabled():\n        save_product_snapshot()',
                        '    if _V85_APP is not None:\n        _V85_APP.publish_cycle(state)','small snapshot publication')
    src=fn_replace(src,'cycle',cycle)
    # Compatible global set once by the entry point. No monkey-patch source file writes.
    index=src.index('SERVICE_STARTED_AT =')
    src=src[:index]+'_V85_APP = None\n'+src[index:]
    compile(src,'veritas_intelligence.py','exec')
    return src


def build(*,offline_base=False,pinned_path=None):
    lock=json.loads((ROOT/'source_lock.json').read_text())
    inputs={}
    for name in ('veritas_intelligence.py','veritas_portfolio.py','veritas_v70.py'):
        data=(ROOT/'vendor/legacy_input'/name.replace('.py','.source.txt')).read_bytes()
        if hashlib.sha256(data).hexdigest()!=lock['files'][name]['sha256']: raise RuntimeError('Input changed: '+name)
        inputs[name]=data.decode('utf-8')
    logs=[]
    if not offline_base:
        cache=Path(pinned_path) if pinned_path else ROOT/'vendor/legacy_input/pinned_v80.source.txt'
        if cache.exists(): payload=cache.read_bytes()
        else:
            payload=urlopen(Request(PIN,headers={'User-Agent':'VERITAS-v85-build'}),timeout=30).read(2_000_001)
        if len(payload)>2_000_000: raise RuntimeError('Oversized historical dependency')
        actual=hashlib.sha1(b'blob '+str(len(payload)).encode()+b'\0'+payload).hexdigest()
        if actual!=BLOB: raise RuntimeError('Historical dependency hash mismatch')
        text=payload.decode('utf-8'); ip=table(text,'PATCHES'); pp=table(text,'PORTFOLIO_PATCHES')
        moved=[x for x in pp if x[2].startswith('v78.1')]
        if len(moved)!=4: raise RuntimeError('Unexpected v78.1 table structure')
        pp=[x for x in pp if x not in moved]
        k=next(i for i,x in enumerate(ip) if x[2].startswith('v79.0'))
        ip[k:k]=moved
        if len(ip)!=50 or len(pp)!=24:raise RuntimeError("Unexpected cumulative patch counts")
        inputs['veritas_intelligence.py']=apply_table(inputs['veritas_intelligence.py'],ip,logs)
        inputs['veritas_portfolio.py']=apply_table(inputs['veritas_portfolio.py'],pp,logs)
        if 'veritas-max-product-v80.0-unified-execution-core' not in inputs['veritas_intelligence.py']: raise RuntimeError('v80 not established')
        # Cache for the fully assembled artifact: future rebuilds are offline.
        cache=ROOT/'vendor/legacy_input/pinned_v80.source.txt'; cache.write_bytes(payload)
    static=static_integration(inputs['veritas_intelligence.py'])
    v70=inputs['veritas_v70.py']
    # The historical companion rewrote the host VERSION as an import side effect.
    # Preserve its math and approved env defaults, remove only that obsolete promotion.
    v70_lines=v70.splitlines(keepends=True)
    promotions=[n for n in ast.parse(v70).body if isinstance(n,ast.For)
                and isinstance(n.target,ast.Name) and n.target.id=='_modname']
    if len(promotions)!=1:raise RuntimeError('Unexpected legacy host-version promotion structure')
    for n in reversed(promotions):
        v70_lines[n.lineno-1:n.end_lineno]=['# Host release identity is owned by v85, never changed by this companion.\n']
    v70=''.join(v70_lines)
    # Archived exact v80 output is retained for deterministic replay, not executed.
    outputs={'veritas_intelligence.py':static,'veritas_v70.py':v70,
             'archive/source/veritas_portfolio_v80.source.txt':inputs['veritas_portfolio.py']}
    # Compile every generated executable in memory BEFORE replacing any output file.
    for name,text in outputs.items():
        if name.endswith('.py'): compile(text,name,'exec')
    for name,text in outputs.items(): (ROOT/name).write_text(text,encoding='utf-8')
    basis='OFFLINE_BASE_TEST_ONLY' if offline_base else 'PINNED_V80_STATIC'
    (ROOT/'reports/build_results.json').write_text(json.dumps({'basis':basis,'version':VERSION,'patches':logs,
        'runtime_source_download':False,'runtime_self_mutation':False,'v84_unsafe_overrides_activated':False,
        'source_archive_sha256':lock['archive_sha256'],'full_legacy_v80_hydrated':not offline_base},indent=2),encoding='utf-8')
    write_manifest(basis)
    return basis


def write_manifest(basis):
    paths=[ROOT/'veritas_intelligence.py',ROOT/'veritas_v70.py',ROOT/'veritas_portfolio.py',ROOT/'sitecustomize.py']
    for folder in ('veritas_v85','migrations','web'): paths+=list((ROOT/folder).rglob('*'))
    paths+=list(ROOT.glob('veritas_knowledge_seed*.json'))
    paths += [ROOT/'requirements-intelligence.txt']
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))
            if p.is_file() and '__pycache__' not in p.parts}
    (ROOT/'release_manifest.json').write_text(json.dumps({'version':VERSION,'schema':2,'basis':basis,
       'paper_execution_requires_quiesced_legacy':True,'historical_win_rate_improvement_proven':False,
       'files':hashes},indent=2),encoding='utf-8')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--offline-base',action='store_true');p.add_argument('--pinned-v80')
    a=p.parse_args()
    print(build(offline_base=a.offline_base,pinned_path=a.pinned_v80))
