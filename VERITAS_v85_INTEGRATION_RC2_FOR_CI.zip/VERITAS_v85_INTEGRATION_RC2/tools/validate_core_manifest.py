from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from veritas_v85.validation import verify_release
if __name__=='__main__':print(json.dumps(verify_release(ROOT),indent=2))
