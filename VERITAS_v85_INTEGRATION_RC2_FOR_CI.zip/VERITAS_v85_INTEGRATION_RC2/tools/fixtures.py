"""Deterministic synthetic source fixtures. Never imported by the live provider path."""
from __future__ import annotations
from datetime import datetime,timezone,timedelta
import math

def bundles(model,at=None):
    at=at or datetime.now(timezone.utc); out={}
    hour=int(at.timestamp())//3600*3600
    for symbol,(asset,cb) in model.ASSETS.items():
        base={'BTC':60000,'ETH':3000,'NDX':20000,'BRENT':80,'GOLD':2500,'MOEX':3000,'CNYRUBF':12}[asset]
        rows=[]
        for i in range(260):
            c=base*(1+.00025*i+.001*math.sin(i*.31))
            ts=hour-(259-i)*3600
            rows.append({'ts':ts,'open':c*.9998,'close':c,'high':c*1.002,'low':c*.998,
                         'volume':1000+100*math.cos(i*.2),'completed_at':ts+3600})
        closes=[r['close'] for r in rows];stamp=at.isoformat()
        q=[model._source_row('fixture-primary',asset,'primary live',stamp,0,'OK','TEST ONLY','fixture-primary'),
           model._source_row('fixture-secondary',asset,'independent live check',stamp,0,'OK','TEST ONLY','fixture-secondary')]
        raw={'asset':asset,'price':closes[-1],'secondary_price':closes[-1],'coinbase_price':closes[-1],
             'source_divergence':0,'closes':closes,'highs':[r['high'] for r in rows],'lows':[r['low'] for r in rows],
             'vols':[r['volume'] for r in rows],'taker_buy':[r['volume']*.5 for r in rows],
             'returns':[closes[i]/closes[i-1]-1 for i in range(1,len(closes))],
             'observed_at':stamp,'binance_close_time_ms':int(at.timestamp()*1000),'market_open':True,'source_gate_pass':True,
             'source_quality':q,'hourly_bars':rows,'intraday_bars':rows[-80:],
             'v85_quote':{'primary_source':'fixture-primary','secondary_source':'fixture-secondary',
               'primary_time':stamp,'secondary_time':stamp,'source_verified':True,'max_age_seconds':120,
               'event_id':'FIXTURE-'+asset+'-'+stamp}}
        out[asset]={'symbol':symbol,'asset':asset,'cb_product':cb,'raw':raw,
                    'deriv':{'ok':False,'context_only':True,'error':'TEST_FIXTURE'},'elapsed_seconds':0,'error':None}
    return out
