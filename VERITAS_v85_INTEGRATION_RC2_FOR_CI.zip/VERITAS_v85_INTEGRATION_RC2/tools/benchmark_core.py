"""Local microbenchmarks only. Does NOT measure Render, real market fetches or legacy 35-cell cycle."""
from __future__ import annotations
import sys,json,time,statistics,threading,urllib.request
from pathlib import Path
from datetime import datetime,timezone,timedelta
from decimal import Decimal as D
from http.server import ThreadingHTTPServer
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from common import quote,signal,position,SPEC,LIMITS,T
from veritas_v85.risk import admit
from veritas_v85.execution import manage
from veritas_v85.snapshots import SnapshotStore
from veritas_v85.release import Readiness
from veritas_v85.http_snapshot import handler_factory


def stats(values):
    ordered=sorted(values)
    return {'n':len(ordered),'p50_ms':statistics.median(ordered)*1000,
            'p95_ms':ordered[int(.95*(len(ordered)-1))]*1000,'max_ms':max(ordered)*1000}

def main():
    q,s,p=quote(),signal(),position()
    batches=[]
    for _ in range(300):
        start=time.perf_counter()
        for i in range(35):
            manage(p,s,q,SPEC,T)
            admit(s,q,SPEC,D(1000000),LIMITS,T)
        batches.append(time.perf_counter()-start)
    snapshots=SnapshotStore();snapshots.publish({'status':'OK','items':[{'asset':str(i),'action':'HOLD'} for i in range(35)]},T)
    reads=[]
    for _ in range(3000):
        start=time.perf_counter();snapshots.read(T);reads.append(time.perf_counter()-start)
    server=ThreadingHTTPServer(('127.0.0.1',0),handler_factory(snapshots,Readiness(True,True,T),lambda:T))
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    requests=[]
    try:
        url='http://127.0.0.1:'+str(server.server_address[1])+'/snapshot'
        for _ in range(150):
            start=time.perf_counter()
            with urllib.request.urlopen(url,timeout=5) as r:
                assert r.status==200;r.read()
            requests.append(time.perf_counter()-start)
    finally:
        server.shutdown();server.server_close();thread.join()
    output={'scope':'LOCAL_SYNTHETIC_MICROBENCHMARK_NOT_FULL_PRODUCT',
            'market_sources_fetched':False,'production_db_measured':False,
            'full_render_cycle_measured':False,
            '35_pure_manage_plus_admit_calls':stats(batches),
            'in_memory_snapshot_read':stats(reads),
            'loopback_http_snapshot':stats(requests)}
    (ROOT/'reports'/'benchmark.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
    print(json.dumps(output,indent=2))
if __name__=='__main__':main()
