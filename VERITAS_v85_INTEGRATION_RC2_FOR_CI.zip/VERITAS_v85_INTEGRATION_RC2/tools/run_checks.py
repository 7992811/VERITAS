"""Run real tests and write machine-derived results, not a checklist of asserted booleans."""
from __future__ import annotations
import sys,time,json,unittest,hashlib,platform,io,contextlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'tests'))

class RecordedResult(unittest.TextTestResult):
    def __init__(self,*a,**kw):super().__init__(*a,**kw);self.cases=[];self.started={}
    def startTest(self,test):self.started[test.id()]=time.perf_counter();super().startTest(test)
    def record(self,test,outcome):
        self.cases.append({'name':test.id(),'outcome':outcome,
                           'seconds':time.perf_counter()-self.started.get(test.id(),time.perf_counter())})
    def addSuccess(self,test):self.record(test,'PASS');super().addSuccess(test)
    def addFailure(self,test,err):self.record(test,'FAIL');super().addFailure(test,err)
    def addError(self,test,err):self.record(test,'ERROR');super().addError(test,err)
    def addSkip(self,test,reason):self.record(test,'SKIP');super().addSkip(test,reason)

def main()->int:
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'))
    out=io.StringIO();t=time.perf_counter()
    runner=unittest.TextTestRunner(stream=out,verbosity=2,resultclass=RecordedResult)
    result=runner.run(suite)
    report={'scope':'V85_CORE_AND_FULL_SUPPLIED_BASE_INTEGRATION_LOCAL_SQLITE',
            'production_integrated':False,'production_postgres_tested':False,
            'market_backtest_performed':False,'win_rate_improvement_demonstrated':False,
            'release_manifest_sha256':hashlib.sha256((ROOT/'release_manifest.json').read_bytes()).hexdigest(),
            'analytical_basis':json.loads((ROOT/'release_manifest.json').read_text())['basis'],
            'python':platform.python_version(),'platform':platform.platform(),
            'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
            'skipped':len(result.skipped),'duration_seconds':time.perf_counter()-t,
            'seeded_risk_trials_within_one_test':2000,'cases':result.cases,
            'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                             for p in sorted((ROOT/'veritas_v85').glob('*.py'))}}
    (ROOT/'reports').mkdir(exist_ok=True)
    (ROOT/'reports'/'test_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'reports'/'test_run.log').write_text(out.getvalue(),encoding='utf-8')
    print(out.getvalue())
    print(json.dumps({k:v for k,v in report.items() if k not in ('cases','source_sha256')},indent=2))
    return 0 if result.wasSuccessful() else 1

if __name__=='__main__':raise SystemExit(main())
