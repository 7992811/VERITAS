from pathlib import Path
import json,os,subprocess,sys,socket,time,urllib.request,urllib.error,hashlib,tempfile,statistics
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='v85-http-') as temp:
    temp=Path(temp)
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    env=os.environ.copy();env.update({'VERITAS_V85_TESTING':'1','VERITAS_V85_MODE':'fixture','VERITAS_V85_TEST_SQLITE':str(temp/'paper.sqlite3'),'VERITAS_LEDGER_PATH':str(temp/'analytic.sqlite3'),'DATABASE_URL':'','PORT':str(port),'VERITAS_KNOWLEDGE_AUTOMATION':'0','VERITAS_V85_INTERVAL_SECONDS':'10','VERITAS_V85_GUARD_SECONDS':'5'})
    tracked={p:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.py')}
    log=open(temp/'server.log','w')
    process=subprocess.Popen([sys.executable,'veritas_intelligence.py'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    started=time.perf_counter();base=f'http://127.0.0.1:{port}'
    def read(path,method='GET'):
        req=urllib.request.Request(base+path,method=method)
        try:
            with urllib.request.urlopen(req,timeout=2) as r:return r.status,r.read(),dict(r.headers)
        except urllib.error.HTTPError as e:return e.code,e.read(),dict(e.headers)
    manifest=json.loads((root/'release_manifest.json').read_text())
    report={'scope':'LOCAL_FULL_PROCESS_FIXTURE_SQLITE_NOT_RENDER_POSTGRES','production_validated':False,'release_manifest_sha256':hashlib.sha256((root/'release_manifest.json').read_bytes()).hexdigest(),'basis':manifest['basis']}
    try:
        while time.perf_counter()-started<15:
            if process.poll() is not None:raise RuntimeError('Server exited '+str(process.returncode))
            try:
                ready=read('/readyz')
                if ready[0]==200:break
            except OSError:pass
            time.sleep(.05)
        else:raise RuntimeError('Readiness timeout')
        report['ready_seconds']=time.perf_counter()-started
        report['readiness']=json.loads(ready[1])
        assert report['readiness']['version']==manifest['version'],'IMPORTED_RUNTIME_VERSION_MISMATCH'
        while time.perf_counter()-started<20:
            snap=read('/api/v85/snapshot');data=json.loads(snap[1])
            # Print keys on first success for the machine evidence shape.
            if data.get('signals') or data.get('cells') or data.get('summary'):break
            time.sleep(.05)
        report['first_snapshot_seconds']=time.perf_counter()-started
        report['snapshot_keys']=list(data)
        report['computed_cells']=data.get('computed_cells')
        report['visible_cells']=data.get('visible_cells')
        report['snapshot_version']=data.get('version')
        assert data.get('computed_cells')==35 and data.get('visible_cells')==35
        assert data.get('version')==manifest['version']
        samples=[]
        for _ in range(50):
            t=time.perf_counter();r=read('/api/v85/snapshot');samples.append(time.perf_counter()-t)
            assert r[0]==200
        report['snapshot_latency_seconds']={'requests':len(samples),'p50':statistics.median(samples),'p95':sorted(samples)[int(.95*len(samples))-1],'max':max(samples),'scope':'LOOPBACK_PRECOMPUTED_FIXTURE_NOT_RENDER'}
        report['unknown_status']=read('/missing')[0]
        report['post_status']=read('/api/v85/snapshot','POST')[0]
        report['html_status']=read('/app')[0]
        report['analytical_read_status']=read('/api/v85/analysis?asset=BTC')[0]
        report['source_hashes_unchanged']=all(hashlib.sha256(p.read_bytes()).hexdigest()==v for p,v in tracked.items())
        assert report['unknown_status']==404 and report['post_status']==405 and report['source_hashes_unchanged']
        report['success']=True
    except Exception as e:
        report['success']=False;report['error']=repr(e)
    finally:
        process.terminate()
        try:process.wait(timeout=10)
        except subprocess.TimeoutExpired:process.kill();process.wait();report['forced_kill']=True
        log.close();report['sigterm_exit_code']=process.returncode
        (root/'reports/http_smoke.log').write_text((temp/'server.log').read_text())
    (root/'reports/http_smoke.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps({k:v for k,v in report.items() if k!='snapshot'},ensure_ascii=False,indent=2))
    if not report['success'] or process.returncode!=0:
        print((temp/'server.log').read_text()[-6000:]);raise SystemExit(1)
