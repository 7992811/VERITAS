"""Read-only validation of a saved GitHub source ZIP. Never executes or extracts its code."""
from __future__ import annotations
import argparse,hashlib,json,stat,zipfile
from pathlib import Path,PurePosixPath


def inspect(archive:Path,expected:dict[str,str],max_total_bytes:int=25000000)->dict:
    seen=set();files={};total=0
    with zipfile.ZipFile(archive) as z:
        members=[i for i in z.infolist() if not i.is_dir()]
        names=[PurePosixPath(i.filename) for i in members]
        if not members:raise ValueError('Empty archive')
        for i,p in zip(members,names):
            if p.is_absolute() or '..' in p.parts or '\\' in i.filename or ':' in i.filename:
                raise ValueError('Unsafe archive member')
            if stat.S_ISLNK(i.external_attr >> 16):raise ValueError('Symlinks not allowed')
            total+=i.file_size
            if total>max_total_bytes or i.file_size>5000000:raise ValueError('Archive size limit')
        roots={p.parts[0] for p in names}
        strip_root=len(roots)==1 and all(len(p.parts)>1 for p in names)
        for i,p in zip(members,names):
            rel=str(PurePosixPath(*p.parts[1:])) if strip_root else str(p)
            if rel.casefold() in seen:raise ValueError('Duplicate/case-colliding archive member')
            seen.add(rel.casefold())
            data=z.read(i)
            blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            files[rel]={'bytes':len(data),'git_blob_sha1':blob,'sha256':hashlib.sha256(data).hexdigest()}
    missing=sorted(set(expected)-set(files))
    changed=sorted(p for p,h in expected.items() if p in files and files[p]['git_blob_sha1']!=h)
    extra=sorted(set(files)-set(expected))
    return {'status':'MATCH' if not missing and not changed and not extra else 'REVIEW_REQUIRED',
            'members':len(files),'bytes':total,'missing':missing,'changed':changed,'extra':extra,
            'files':files,'executed_code':False,'extracted_files':False}


def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument('archive',type=Path)
    ap.add_argument('--expected',type=Path,default=Path(__file__).resolve().parents[1]/'source_lock.json')
    args=ap.parse_args()
    expected=json.loads(args.expected.read_text(encoding='utf-8'))['files']
    expected={k:(v['git_blob_sha1'] if isinstance(v,dict) else v) for k,v in expected.items()}
    result=inspect(args.archive,expected)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['status']=='MATCH' else 2

if __name__=='__main__':raise SystemExit(main())
