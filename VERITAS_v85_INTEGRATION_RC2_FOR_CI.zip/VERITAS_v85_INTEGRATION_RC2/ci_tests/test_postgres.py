"""Real PostgreSQL acceptance. Intentionally refuses non-local/non-test databases.
Run ONLY against the ephemeral CI service. Never points to the user's Render DB.
"""
import os,sys,unittest,tempfile,json,time,copy
from pathlib import Path
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta,datetime,timezone
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
DSN=os.environ.get('VERITAS_V85_TEST_DATABASE_URL','')
p=urlparse(DSN)
if p.hostname not in ('localhost','127.0.0.1') or p.path!='/veritas_v85_ci' or os.getenv('VERITAS_V85_EPHEMERAL_DB')!='1':
    raise SystemExit('REFUSED: requires localhost/veritas_v85_ci and explicit ephemeral-test flag. No production fallback.')
import psycopg
from veritas_v85.postgres import PostgresLedger
from veritas_v85.book import PaperBook
from veritas_v85.config import Settings
from veritas_v85.application import Application
from veritas_v85.migration import prepare_legacy,apply_prepared
from veritas_v85.learning import Context,Lesson
from veritas_v85.experience_store import ExperienceService,insert_lesson
from veritas_v85.snapshots import SnapshotStore
from common import *
from test_integrated_application import legacy_fixture,model_fixture
from tools.fixtures import bundles
from tools.run_checks import RecordedResult
import io,hashlib

class PostgreSQLAcceptance(unittest.TestCase):
    def setUp(self):
        # Destructive ONLY inside the validated, local, newly-created CI database.
        with psycopg.connect(DSN,autocommit=True) as c:
            c.execute('DROP SCHEMA public CASCADE');c.execute('CREATE SCHEMA public')
        self.l=PostgresLedger(DSN);self.b=PaperBook(self.l,{'BTC':SPEC});self.tmp=tempfile.TemporaryDirectory()
        self.b.create_account('A',D('1000000'),'v85-test')
    def tearDown(self):self.l.close();self.tmp.cleanup()
    def test_single_writer_lease(self):
        other=PostgresLedger(DSN,migrate=False)
        try:
            self.assertTrue(self.l.acquire_writer());self.assertFalse(other.acquire_writer())
            self.l.release_writer();self.assertTrue(other.acquire_writer())
        finally:other.close()
    def test_expired_writer_cannot_commit_after_takeover(self):
        other=PostgresLedger(DSN,migrate=False)
        try:
            self.l.require_writer_lease=True;self.assertTrue(self.l.acquire_writer())
            with self.l.raw_connection() as c:c.execute("UPDATE v85_writer_lease SET expires_at=clock_timestamp()-interval '1 second'")
            self.assertTrue(other.acquire_writer())
            with self.assertRaises(RuntimeError):self.b.process('A','BTC','m1',T,quote(),signal(),LIMITS)
            self.assertFalse(self.b.orders('A'))
        finally:other.close()
    def test_schema_reentrant(self):self.l.migrate();self.l.migrate()
    def test_open_replay_restart(self):
        a=self.b.process('A','BTC','m1',T,quote(),signal(),LIMITS)
        b=PaperBook(self.l,{'BTC':SPEC}).process('A','BTC','m1',T,quote(),signal(),LIMITS)
        self.assertTrue(b['replayed']);self.assertEqual(len(self.b.orders('A')),1)
    def test_concurrent_exact_replays_one_order(self):
        def work(i):return self.b.process('A','BTC','m1',T,quote(),signal(),LIMITS)
        with ThreadPoolExecutor(max_workers=4) as pool:r=list(pool.map(work,range(8)))
        self.assertEqual(len(self.b.orders('A')),1);self.assertEqual(sum(not x['replayed'] for x in r),1)
    def test_stop_closes_and_records_lesson_atomically(self):
        self.b.process('A','BTC','m1',T,quote(),signal(),LIMITS);at=T+timedelta(seconds=1)
        r=self.b.process('A','BTC','s',at,quote('94',at,'s'),None,LIMITS)
        self.assertFalse(self.b.positions('A'));self.assertEqual(len(self.b.orders('A')),2)
        with self.l.read() as c:self.assertEqual(len(c.execute('SELECT * FROM v85_lessons').fetchall()),1)
    def test_forced_rollback_includes_orders_and_lessons(self):
        self.b.process('A','BTC','m1',T,quote(),signal(),LIMITS);at=T+timedelta(seconds=1)
        self.b.fault_hook=lambda phase:(_ for _ in ()).throw(RuntimeError('FAULT')) if phase=='after_lesson_write' else None
        with self.assertRaises(RuntimeError):self.b.process('A','BTC','s',at,quote('94',at,'s'),None,LIMITS)
        self.assertTrue(self.b.positions('A'));self.assertEqual(len(self.b.orders('A')),1)
        with self.l.read() as c:self.assertFalse(c.execute('SELECT * FROM v85_lessons').fetchall())
    def test_plus_point_one_and_repeated_missing_signal_holds(self):
        self.b.process('A','BTC','m1',T,quote(),signal(),LIMITS)
        for i in range(1,5):self.b.process('A','BTC','m'+str(i+1),T+timedelta(seconds=i),quote('100.1',T+timedelta(seconds=i),'m'+str(i+1)),None,LIMITS)
        self.assertEqual(len(self.b.orders('A')),1)
    def test_read_only_transactions_reject_writes(self):
        with self.assertRaises(Exception):
            with self.l.read() as c:c.execute("UPDATE v85_accounts SET realized_equity='0'")
    def test_lessons_incremental_causal(self):
        e=ExperienceService(self.l,SnapshotStore());ctx=Context('BTC','1h','s','LONG','r')
        e.save(Lesson('e1','i1','p',ctx,T,T,T,1,D('-.1')));self.assertEqual(len(e.lessons(T)),1)
        e.save(Lesson('e2','i2','p',ctx,T,T,T+timedelta(days=1),1,D('.1')))
        self.assertEqual(len(e.lessons(T)),1);self.assertEqual(len(e.lessons(T+timedelta(days=1))),2)
    def test_migration_no_orders_no_fee_no_source_write(self):
        # Clear only target synthetic account created by this test's setup.
        with self.l.transaction() as c:c.execute('DELETE FROM v85_accounts')
        p=prepare_legacy(*legacy_fixture(),T);apply_prepared(self.l,p,legacy_quiesced=True,dry_run=False)
        self.assertEqual(self.b.positions('Champion')[0].quantity,D('100'));self.assertFalse(self.b.orders('Champion'))
        self.assertEqual(apply_prepared(self.l,p,legacy_quiesced=True,dry_run=False)['action'],'ALREADY_IMPORTED')
    def test_full_static_model_35_cells_with_postgres(self):
        m=model_fixture(self.tmp.name);m.DATABASE_URL=DSN
        app=Application(m,self.l,Settings(mode='fixture',testing=True),fixture_bundles=bundles(m))
        app.bootstrap();app.analyze_once()
        self.assertEqual(m.last_cycle['decisions_written'],35);self.assertFalse(m.last_cycle['errors'])
        with self.l.read() as c:
            self.assertTrue(c.execute('SELECT * FROM v85_observations').fetchall())
            n=c.execute("SELECT count(*) AS n FROM ledger_events WHERE event_type='decision'").fetchone()['n']
            self.assertEqual(n,35)
        # Fresh schema must not create legacy paper orders through an unbound second owner.
        with self.l.raw_connection() as c:
            rel=c.execute("SELECT to_regclass('public.paper_orders') AS rel").fetchone()['rel']
            if rel:self.assertEqual(c.execute('SELECT count(*) AS n FROM paper_orders').fetchone()['n'],0)
        app.refresh_learning()
        app.ready=False

if __name__=='__main__':
    stream=io.StringIO();t=time.perf_counter();suite=unittest.defaultTestLoader.loadTestsFromTestCase(PostgreSQLAcceptance)
    result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=RecordedResult).run(suite)
    report={'scope':'REAL_POSTGRESQL_EPHEMERAL_CI','tests_run':result.testsRun,'errors':len(result.errors),
      'failures':len(result.failures),'skipped':len(result.skipped),'seconds':time.perf_counter()-t,'cases':result.cases,
      'real_postgres_tested':True,'production_database_touched':False,
      'release_manifest_sha256':hashlib.sha256((ROOT/'release_manifest.json').read_bytes()).hexdigest()}
    (ROOT/'reports/postgres_results.json').write_text(json.dumps(report,indent=2));(ROOT/'reports/postgres_test_run.log').write_text(stream.getvalue())
    print(stream.getvalue());print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
