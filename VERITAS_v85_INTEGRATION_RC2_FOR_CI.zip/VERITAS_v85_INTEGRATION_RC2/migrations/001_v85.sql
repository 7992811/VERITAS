
CREATE TABLE IF NOT EXISTS v85_schema (version INTEGER PRIMARY KEY);
INSERT INTO v85_schema VALUES(1) ON CONFLICT DO NOTHING;
INSERT INTO v85_schema VALUES(2) ON CONFLICT DO NOTHING;
CREATE TABLE IF NOT EXISTS v85_accounts (
 account_id TEXT PRIMARY KEY, initial_equity TEXT NOT NULL,
 realized_equity TEXT NOT NULL, policy_version TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS v85_positions (
 account_id TEXT NOT NULL, asset TEXT NOT NULL, episode_id TEXT NOT NULL UNIQUE,
 payload TEXT NOT NULL, entry_fee TEXT NOT NULL,
 last_price TEXT NOT NULL, last_fx TEXT NOT NULL,
 PRIMARY KEY(account_id,asset), FOREIGN KEY(account_id) REFERENCES v85_accounts(account_id));
CREATE TABLE IF NOT EXISTS v85_episodes (
 episode_id TEXT PRIMARY KEY, account_id TEXT NOT NULL, asset TEXT NOT NULL,
 idea_id TEXT NOT NULL, policy_version TEXT NOT NULL, opened_at TEXT NOT NULL,
 closed_at TEXT, opening_event TEXT NOT NULL, closing_event TEXT,
 status TEXT NOT NULL, payload TEXT NOT NULL, net_pnl TEXT,
 FOREIGN KEY(account_id) REFERENCES v85_accounts(account_id));
CREATE INDEX IF NOT EXISTS v85_episode_last ON v85_episodes(account_id,asset,closed_at DESC);
CREATE TABLE IF NOT EXISTS v85_orders (
 intent_id TEXT PRIMARY KEY, episode_id TEXT NOT NULL, account_id TEXT NOT NULL,
 event_id TEXT NOT NULL, side TEXT NOT NULL, quantity TEXT NOT NULL,
 price TEXT NOT NULL, fee TEXT NOT NULL, reason TEXT NOT NULL, at TEXT NOT NULL,
 FOREIGN KEY(episode_id) REFERENCES v85_episodes(episode_id));
CREATE TABLE IF NOT EXISTS v85_receipts (
 account_id TEXT NOT NULL, event_key TEXT NOT NULL, input_hash TEXT NOT NULL,
 result TEXT NOT NULL, PRIMARY KEY(account_id,event_key));
CREATE TABLE IF NOT EXISTS v85_pending_exits (
 episode_id TEXT PRIMARY KEY, reason TEXT NOT NULL, requested_at TEXT NOT NULL,
 FOREIGN KEY(episode_id) REFERENCES v85_episodes(episode_id));
CREATE TABLE IF NOT EXISTS v85_clocks (
 account_id TEXT NOT NULL,asset TEXT NOT NULL,last_at TEXT NOT NULL,
 PRIMARY KEY(account_id,asset),FOREIGN KEY(account_id) REFERENCES v85_accounts(account_id));
CREATE TABLE IF NOT EXISTS v85_lessons (
 episode_id TEXT NOT NULL, revision INTEGER NOT NULL, known_at TEXT NOT NULL,
 payload TEXT NOT NULL, PRIMARY KEY(episode_id,revision));

CREATE TABLE IF NOT EXISTS v85_cutovers (
 cutover_id TEXT PRIMARY KEY, known_at TEXT NOT NULL, payload TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS v85_snapshots (
 kind TEXT PRIMARY KEY, published_at TEXT NOT NULL, payload TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS v85_observations (
 observation_id TEXT PRIMARY KEY, known_at TEXT NOT NULL, payload TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS v85_observations_time ON v85_observations(known_at);
CREATE INDEX IF NOT EXISTS v85_lessons_known ON v85_lessons(known_at,episode_id,revision);
CREATE INDEX IF NOT EXISTS v85_orders_account_at ON v85_orders(account_id,at);

CREATE TABLE IF NOT EXISTS v85_confirmations (
 asset TEXT NOT NULL, information_id TEXT NOT NULL, horizon TEXT NOT NULL,
 direction TEXT NOT NULL, completed_at TEXT NOT NULL, known_at TEXT NOT NULL, payload TEXT NOT NULL,
 PRIMARY KEY(asset,information_id,horizon));
CREATE INDEX IF NOT EXISTS v85_confirmations_lookup ON v85_confirmations(asset,horizon,completed_at DESC);
CREATE TABLE IF NOT EXISTS v85_risk (
 account_id TEXT PRIMARY KEY, high_water TEXT NOT NULL, state TEXT NOT NULL, at TEXT NOT NULL,
 FOREIGN KEY(account_id) REFERENCES v85_accounts(account_id));

CREATE TABLE IF NOT EXISTS v85_path (
 episode_id TEXT NOT NULL, event_id TEXT NOT NULL, at TEXT NOT NULL, price TEXT NOT NULL,
 PRIMARY KEY(episode_id,event_id),FOREIGN KEY(episode_id) REFERENCES v85_episodes(episode_id));
CREATE INDEX IF NOT EXISTS v85_path_episode_at ON v85_path(episode_id,at);

CREATE TABLE IF NOT EXISTS v85_lesson_changes (
 seq BIGSERIAL PRIMARY KEY, episode_id TEXT NOT NULL, revision INTEGER NOT NULL,
 UNIQUE(episode_id,revision));
INSERT INTO v85_lesson_changes(episode_id,revision)
 SELECT episode_id,revision FROM v85_lessons WHERE TRUE ORDER BY known_at,episode_id,revision
 ON CONFLICT(episode_id,revision) DO NOTHING;

CREATE TABLE IF NOT EXISTS v85_writer_lease (
 singleton INTEGER PRIMARY KEY CHECK(singleton=1), owner_id TEXT NOT NULL, expires_at TIMESTAMPTZ NOT NULL);
