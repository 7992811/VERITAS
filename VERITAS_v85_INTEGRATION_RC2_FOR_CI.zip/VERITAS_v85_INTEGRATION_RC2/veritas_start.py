"""Compatibility entry point; no source patching."""
from veritas_intelligence import main
if __name__ == "__main__":
    main()
