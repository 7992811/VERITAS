"""A single transactional owner of synthetic paper episodes.
No separate shadow selection: both projections read the same committed intent/order ledger.
No broker integration and no automatic connection to legacy production tables.
"""
from __future__ import annotations
from dataclasses import asdict, replace
from datetime import datetime
from decimal import Decimal
from typing import Callable, Mapping, Any
import json
from .domain import (D, ZERO, ONE, Instrument, Quote, Signal, Position, Direction, ThesisBreak,
                     decimal, utc, stable_id, canonical_json, position_dict, position_from_dict)
from .risk import RiskLimits, admit
from .execution import Action, manage
from .storage import SQLiteLedger
from .learning import Lesson, Context
from .experience_store import insert_lesson
from .funding import accrued


class InputConflict(RuntimeError):
    pass


class PaperBook:
    def __init__(self, ledger: SQLiteLedger, instruments: Mapping[str, Instrument],
                 *, fault_hook: Callable[[str], None] | None = None, experience_view=None, annual_funding_rate=D('0'), short_funding_spread=D('0')):
        self.ledger = ledger
        self.instruments = dict(instruments)
        self.fault_hook = fault_hook or (lambda phase: None)
        self.experience_view = experience_view
        self.annual_funding_rate=decimal(annual_funding_rate,nonnegative=True)
        self.short_funding_spread=decimal(short_funding_spread,nonnegative=True)

    def create_account(self, account_id: str, initial_equity, policy_version: str) -> None:
        equity = decimal(initial_equity, positive=True)
        if not account_id or not policy_version:
            raise ValueError("Account identity/policy required")
        with self.ledger.transaction() as c:
            old = c.execute("SELECT * FROM v85_accounts WHERE account_id=?", (account_id,)).fetchone()
            if old:
                if D(old["initial_equity"]) != equity or old["policy_version"] != policy_version:
                    raise InputConflict("Existing account cannot be silently reset or promoted")
                return
            c.execute("INSERT INTO v85_accounts VALUES(?,?,?,?)",
                      (account_id, str(equity), str(equity), policy_version))

    def _positions(self, c, account_id: str) -> list[Position]:
        rows = c.execute("SELECT payload FROM v85_positions WHERE account_id=? ORDER BY asset", (account_id,)).fetchall()
        return [position_from_dict(json.loads(r["payload"])) for r in rows]

    def _valuation(self, c, account_id: str, quotes: Mapping[str, Quote], at: datetime):
        account = c.execute("SELECT * FROM v85_accounts WHERE account_id=?", (account_id,)).fetchone()
        if account is None:
            raise ValueError("Unknown account")
        equity = D(account["realized_equity"])
        notional = ZERO
        valid = True
        for p in self._positions(c, account_id):
            spec = self.instruments[p.asset]
            q = quotes.get(p.asset)
            episode=c.execute('SELECT payload FROM v85_episodes WHERE episode_id=?',(p.episode_id,)).fetchone()
            if episode:equity-=accrued(p,json.loads(episode['payload']),at)
            if q is None or q.problem(at, spec):
                valid = False
                row = c.execute("SELECT last_price,last_fx FROM v85_positions WHERE account_id=? AND asset=?",
                                (account_id, p.asset)).fetchone()
                mark, fx = D(row["last_price"]), D(row["last_fx"])
            else:
                mark, fx = q.price, q.fx_to_nav
                c.execute("UPDATE v85_positions SET last_price=?,last_fx=? WHERE account_id=? AND asset=?",
                          (str(mark), str(fx), account_id, p.asset))
            equity += p.direction.sign * p.quantity * spec.multiplier * (mark-p.entry_price) * fx
            notional += p.quantity * spec.multiplier * mark * fx
        return equity, (notional/equity if equity > 0 else D("Infinity")), valid, account

    def _close(self, c, p: Position, quote: Quote, at: datetime, reason: str, intent_id: str) -> dict:
        spec = self.instruments[p.asset]
        # Zero/dust thresholds are deliberately absent. Always close the whole positive quantity.
        nominal = p.quantity*spec.multiplier*quote.price*quote.fx_to_nav
        fee = nominal*spec.commission_rate
        gross = p.direction.sign*p.quantity*spec.multiplier*(quote.price-p.entry_price)*quote.fx_to_nav
        account = c.execute("SELECT realized_equity FROM v85_accounts WHERE account_id=?", (p.account_id,)).fetchone()
        old = c.execute("SELECT entry_fee FROM v85_positions WHERE account_id=? AND asset=?", (p.account_id,p.asset)).fetchone()
        entry_fee = D(old["entry_fee"])
        ep_for_cost=c.execute('SELECT payload FROM v85_episodes WHERE episode_id=?',(p.episode_id,)).fetchone()
        fund=accrued(p,json.loads(ep_for_cost['payload']),at)
        c.execute("UPDATE v85_accounts SET realized_equity=? WHERE account_id=?",
                  (str(D(account["realized_equity"])+gross-fee-fund), p.account_id))
        c.execute("INSERT INTO v85_orders VALUES(?,?,?,?,?,?,?,?,?,?)",
                  (intent_id,p.episode_id,p.account_id,quote.event_id,"SELL" if p.direction==Direction.LONG else "COVER",
                   str(p.quantity),str(quote.price),str(fee),reason,at.isoformat()))
        self.fault_hook("after_close_order")
        episode=c.execute("SELECT payload,opening_event FROM v85_episodes WHERE episode_id=?",(p.episode_id,)).fetchone()
        original=json.loads(episode["payload"])
        # Previously realized partial-leg P&L is already in account equity; include it
        # only in the episode report, never credit the account twice on migration.
        carry=decimal(original.get("legacy_realized_gross","0"))
        episode_net=gross-fee-entry_fee-fund+carry
        c.execute("UPDATE v85_episodes SET closed_at=?,closing_event=?,status='CLOSED',net_pnl=? WHERE episode_id=?",
                  (at.isoformat(),quote.event_id,str(episode_net),p.episode_id))
        points=c.execute('SELECT price FROM v85_path WHERE episode_id=? ORDER BY at,event_id',(p.episode_id,)).fetchall()
        returns=[p.direction.sign*(decimal(x['price'])/p.entry_price-ONE) for x in points]
        returns.append(p.direction.sign*(quote.price/p.entry_price-ONE))
        mfe=max([ZERO]+returns);mae=min([ZERO]+returns)
        outcome={'net_pnl':str(episode_net),'gross_close_leg':str(gross),'funding_close_leg':str(fund),
                 'observed_mfe_fraction':str(mfe),'observed_mae_fraction':str(mae),
                 'giveback_from_observed_peak':str(max(ZERO,mfe-returns[-1])),
                 'held_seconds':max(0,(at-p.opened_at).total_seconds()),'exit_reason':reason,
                 'path_points':len(points),'path_scope':'VALIDATED_OBSERVED_QUOTES_NOT_COMPLETE_MARKET_PATH',
                 'causal_error':'NOT_INFERRED_FROM_PNL_ALONE'}
        original['outcome']=outcome
        c.execute('UPDATE v85_episodes SET payload=? WHERE episode_id=?',(canonical_json(original),p.episode_id))
        signal_context=original["signal"]
        entry_nav=decimal(original["entry_nav"],positive=True)
        # One realized net lesson per completed episode. No inference about whether the stop was causally wrong.
        lesson=Lesson(p.episode_id,stable_id("CL_",p.asset,p.idea_id,episode["opening_event"]),
                      original.get("learning_policy_version",p.policy_version),Context(p.asset,p.horizon,signal_context.get("setup_family","UNCLASSIFIED"),
                                               p.direction.value,signal_context.get("regime","UNKNOWN")),
                      at,at,at,1,episode_net/entry_nav)
        insert_lesson(c,lesson)
        self.fault_hook("after_lesson_write")
        c.execute("DELETE FROM v85_pending_exits WHERE episode_id=?", (p.episode_id,))
        c.execute("DELETE FROM v85_positions WHERE episode_id=?", (p.episode_id,))
        return {"action":"CLOSE","episode_id":p.episode_id,"quantity":str(p.quantity),
                "reason":reason,"price":str(quote.price),"gross":str(gross),"exit_fee":str(fee),
                "funding":str(fund),"net_episode":str(episode_net),"intent_id":intent_id}

    def _new_admission(self, c, account_id: str, signal: Signal, quote: Quote,
                       quotes: Mapping[str, Quote], at: datetime, limits: RiskLimits) -> tuple[Any,Decimal,Any]:
        nav,gross,valid,account = self._valuation(c,account_id,quotes,at)
        if not valid:
            return "NAV_UNVERIFIED",nav,account
        if nav <= 0:
            return "NAV_NONPOSITIVE",nav,account
        # remaining_gross in the public input is the book gross cap, not an unverified caller balance.
        remaining = max(ZERO, limits.remaining_gross-gross)
        revised = replace(limits, remaining_gross=remaining)
        return admit(signal,quote,self.instruments[signal.asset],nav,revised,at),nav,account

    def _open(self,c,account_id: str,signal: Signal,quote: Quote,nav: Decimal,admission,account,at: datetime) -> dict:
        episode_id = stable_id("EP_",account_id,signal.idea_id,quote.event_id,account["policy_version"])
        intent_id = stable_id("INT_",episode_id,"OPEN",signal.decision_id,quote.event_id)
        pos = Position(account_id,episode_id,signal.idea_id,signal.asset,signal.direction,
                       signal.horizon,admission.quantity,quote.price,signal.stop_price,at,account["policy_version"])
        fee = admission.nominal*self.instruments[signal.asset].commission_rate
        payload = {"position":position_dict(pos),"signal":asdict(signal),"entry_nav":str(nav),
                   "entry_fx":str(quote.fx_to_nav),"instrument_multiplier":str(self.instruments[signal.asset].multiplier),"entry_fee":str(fee),"scope":"SYNTHETIC_PAPER",
                   "funding_annual_rate":str(self.annual_funding_rate+(self.short_funding_spread if signal.direction==Direction.SHORT else ZERO)),
                   "funding_start_at":at.isoformat(),"funding_model":"FIXED_RATE_AT_ENTRY_NORMALIZED_NOTIONAL"}
        c.execute("INSERT INTO v85_episodes VALUES(?,?,?,?,?,?,NULL,?,NULL,'OPEN',?,NULL)",
                  (episode_id,account_id,signal.asset,signal.idea_id,account["policy_version"],at.isoformat(),
                   quote.event_id,canonical_json(payload)))
        c.execute("INSERT INTO v85_positions VALUES(?,?,?,?,?,?,?)",
                  (account_id,signal.asset,episode_id,canonical_json(position_dict(pos)),str(fee),str(quote.price),str(quote.fx_to_nav)))
        c.execute("INSERT INTO v85_orders VALUES(?,?,?,?,?,?,?,?,?,?)",
                  (intent_id,episode_id,account_id,quote.event_id,"BUY" if signal.direction==Direction.LONG else "SHORT",
                   str(admission.quantity),str(quote.price),str(fee),admission.reason,at.isoformat()))
        c.execute("UPDATE v85_accounts SET realized_equity=? WHERE account_id=?",
                  (str(D(account["realized_equity"])-fee),account_id))
        c.execute('INSERT INTO v85_path VALUES(?,?,?,?) ON CONFLICT(episode_id,event_id) DO NOTHING',
                  (episode_id,quote.event_id,at.isoformat(),str(quote.price)))
        self.fault_hook("after_open_order")
        return {"action":"OPEN","episode_id":episode_id,"quantity":str(admission.quantity),
                "direction":signal.direction.value,"fraction":str(admission.fraction),
                "fee":str(fee),"reason":admission.reason,"intent_id":intent_id}

    def process(self, account_id: str, asset: str, event_id: str, at: datetime,
                quote: Quote | None, signal: Signal | None, limits: RiskLimits, *,
                quotes: Mapping[str,Quote] | None = None, portfolio_hard_stop: bool = False,
                thesis_break: ThesisBreak | None = None) -> dict:
        at = utc(at)
        if asset not in self.instruments or not event_id:
            raise ValueError("Unknown asset or missing event identity")
        if quote is not None and (quote.asset != asset or quote.event_id != event_id):
            raise ValueError("Event/quote mismatch")
        if signal is not None and signal.asset != asset:
            raise ValueError("Signal/asset mismatch")
        context = dict(quotes or {})
        if quote is not None:
            context[asset] = quote
        economic_input = {"asset":asset,"event":event_id,"quote":asdict(quote) if quote else None,
                          "signal":asdict(signal) if signal else None,"risk":asdict(limits),
                          "portfolio_hard_stop":portfolio_hard_stop,
                          "thesis_break":asdict(thesis_break) if thesis_break else None,
                          "other_quotes":{a:asdict(q) for a,q in context.items() if a!=asset}}
        input_hash = stable_id("INPUT_",economic_input)
        # Risk/thesis events are independent obligations even on the same unchanged market quote.
        event_key = stable_id("EV_",asset,event_id,
                              signal.decision_id if signal else "NO_SIGNAL",
                              portfolio_hard_stop,thesis_break.event_id if thesis_break else None)
        financial=getattr(self.ledger,'financial_transaction',self.ledger.transaction)
        with financial() as c:
            receipt = c.execute("SELECT * FROM v85_receipts WHERE account_id=? AND event_key=?",(account_id,event_key)).fetchone()
            if receipt:
                if receipt["input_hash"] != input_hash:
                    raise InputConflict("Same immutable event key has different economic inputs")
                return {**json.loads(receipt["result"]),"replayed":True}
            account = c.execute("SELECT * FROM v85_accounts WHERE account_id=?",(account_id,)).fetchone()
            if account is None:
                raise ValueError("Unknown account")
            previous_clock=c.execute("SELECT last_at FROM v85_clocks WHERE account_id=? AND asset=?",(account_id,asset)).fetchone()
            if previous_clock and at<utc(previous_clock["last_at"]):
                raise InputConflict("OUT_OF_ORDER_EVENT: cannot trade a past market state")
            existing = next((p for p in self._positions(c,account_id) if p.asset==asset),None)
            events=[]
            experience_effect={"size_multiplier":"1","reason":"OBSERVE_ONLY","direction_prior_not_applied":True}
            if signal is not None and self.experience_view is not None:
                try:
                    learned=self.experience_view.for_signal(signal,account["policy_version"],at)
                    proposed=replace(signal,desired_fraction=signal.desired_fraction*learned.size_multiplier)
                    experience_effect={"size_multiplier":str(learned.size_multiplier),"reason":learned.reason,
                                       "validation_id":learned.validation_id,"direction_prior_not_applied":True}
                    # Direction remains owned by the upstream signal model. The paper book only sizes.
                    signal=proposed
                except Exception as exc:
                    # Non-critical optional learning must never prevent a structural stop/mandatory exit.
                    experience_effect={"size_multiplier":"1","reason":"LEARNING_UNAVAILABLE",
                                       "error_type":type(exc).__name__,"direction_prior_not_applied":True}
            new_allowed = existing is None
            action_reason = "NO_SIGNAL"
            if existing:
                if quote is not None and quote.problem(at,self.instruments[asset]) is None:
                    c.execute('INSERT INTO v85_path VALUES(?,?,?,?) ON CONFLICT(episode_id,event_id) DO NOTHING',
                              (existing.episode_id,quote.event_id,at.isoformat(),str(quote.price)))
                pending = c.execute("SELECT reason FROM v85_pending_exits WHERE episode_id=?",(existing.episode_id,)).fetchone()
                intent = manage(existing,signal,quote,self.instruments[asset],at,
                                portfolio_hard_stop=portfolio_hard_stop,thesis_break=thesis_break,
                                pending_exit_reason=pending["reason"] if pending else None)
                action_reason = intent.reason
                if intent.action == Action.EXIT_PENDING_QUOTE:
                    c.execute("INSERT INTO v85_pending_exits VALUES(?,?,?) ON CONFLICT(episode_id) DO NOTHING",
                              (existing.episode_id,intent.reason,at.isoformat()))
                elif intent.action in (Action.EXIT,Action.CLOSE_THEN_REASSESS):
                    assert quote is not None
                    events.append(self._close(c,existing,quote,at,intent.reason,intent.intent_id))
                    new_allowed = intent.action == Action.CLOSE_THEN_REASSESS and not portfolio_hard_stop
                # HOLD never reassigns the owning horizon, stop or episode to the latest candidate.
            if new_allowed and signal and quote and not portfolio_hard_stop:
                # Tombstone prevents a poll from becoming a fresh episode after a stop/exit.
                previous = c.execute("SELECT * FROM v85_episodes WHERE account_id=? AND asset=? AND status='CLOSED' ORDER BY closed_at DESC,episode_id DESC LIMIT 1",
                                     (account_id,asset)).fetchone()
                blocked = None
                if previous and previous["idea_id"] == signal.idea_id:
                    matching = [e for e in signal.confirmations if e.closed is True and e.direction==signal.direction
                                and e.information_id==signal.reentry_information_id
                                and e.completed_at>utc(previous["closed_at"]) and e.known_at<=at]
                    if signal.reentry_of_episode != previous["episode_id"] or not matching:
                        blocked = "REENTRY_REQUIRES_NEW_VALIDATED_INFORMATION"
                if not blocked:
                    admission,nav,account = self._new_admission(c,account_id,signal,quote,context,at,limits)
                    if isinstance(admission,str):
                        blocked=admission
                    elif admission.allowed:
                        events.append(self._open(c,account_id,signal,quote,nav,admission,account,at))
                    else:
                        blocked=admission.reason
                if blocked:
                    action_reason=blocked
            nav,gross,nav_verified,_ = self._valuation(c,account_id,context,at)
            if events and action_reason == "NO_SIGNAL":
                action_reason = events[-1]["reason"]
            result={"event_key":event_key,"events":events,"management_reason":action_reason,
                    "nav":str(nav),"gross":str(gross),"nav_verified":nav_verified,
                    "experience_effect":experience_effect,
                    "replayed":False,"scope":"SYNTHETIC_PAPER"}
            self.fault_hook("before_receipt")
            c.execute("INSERT INTO v85_receipts VALUES(?,?,?,?)",(account_id,event_key,input_hash,canonical_json(result)))
            c.execute("INSERT INTO v85_clocks VALUES(?,?,?) ON CONFLICT(account_id,asset) DO UPDATE SET last_at=excluded.last_at",
                      (account_id,asset,at.isoformat()))
            return result

    def positions(self,account_id: str) -> list[Position]:
        with self.ledger.read() as c:
            return self._positions(c,account_id)

    def orders(self,account_id: str) -> list[dict]:
        with self.ledger.read() as c:
            return [dict(r) for r in c.execute("SELECT * FROM v85_orders WHERE account_id=? ORDER BY at,intent_id",(account_id,)).fetchall()]
