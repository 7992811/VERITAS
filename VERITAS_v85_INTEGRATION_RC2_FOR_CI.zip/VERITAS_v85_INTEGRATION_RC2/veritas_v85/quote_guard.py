"""Bounded independent quote lane for existing synthetic-paper positions.
Only BTC/ETH and NDX have dual-direct price adapters in this release.
Other assets remain visible for research, but require a verified quote adapter
before they can be newly admitted or a pending paper exit can be priced.
"""
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor,as_completed
import httpx
from .domain import D,Quote,stable_id,utc

GUARD_SUPPORTED_ASSETS=frozenset(('BTC','ETH','NDX'))

def require_cutover_guard_coverage(prepared):
    held={x['position']['asset'] for x in prepared.get('snapshot',{}).get('positions',[])}
    missing=sorted(held-GUARD_SUPPORTED_ASSETS)
    if missing:
        raise RuntimeError('CUTOVER_BLOCKED_MISSING_INDEPENDENT_GUARD_ADAPTER: '+','.join(missing))
    return {'status':'SUPPORTED_ADAPTERS','held_assets':sorted(held),'live_quote_validity_checked_per_order':True}

def collect_crypto(asset):
    pair=asset+'USDT'; product=asset+'-USD'
    with httpx.Client(timeout=httpx.Timeout(3.0,connect=2.0),limits=httpx.Limits(max_connections=4)) as client:
        urls={
            'primary':('https://api.binance.com/api/v3/ticker/price',{'symbol':pair}),
            'clock':('https://api.binance.com/api/v3/time',{}),
            'secondary':('https://api.exchange.coinbase.com/products/'+product+'/ticker',{}),
        }
        def get(item):
            url,params=item;r=client.get(url,params=params);r.raise_for_status();return r.json()
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures={k:pool.submit(get,v) for k,v in urls.items()}
            values={k:f.result() for k,f in futures.items()}
    p=D(str(values['primary']['price']));q=D(str(values['secondary']['price']))
    if p<=0 or q<=0 or abs(p-q)/((p+q)/2)>D('.005'):raise ValueError('PRICE_VERIFICATION_FAIL')
    # Binance ticker supplies no trade timestamp: server-clock/receipt observation,
    # explicitly NOT a last-trade timestamp. Coinbase carries its trade time.
    pt=datetime.fromtimestamp(values['clock']['serverTime']/1000,timezone.utc)
    st=utc(values['secondary']['time'])
    return Quote(asset,p,stable_id('QGUARD_',asset,str(p),str(q),pt,st),pt,st,
                 'Binance direct observed ticker','Coinbase direct ticker',True,True,120,quote_currency='RUB')

def collect_ndx(model):
    rows,_=model._yahoo_series('%5ENDX','1d','1m',False)
    direct=model._nasdaq_ndx_quote()
    if not rows or not direct.get('exchange_timestamp_utc'):raise ValueError('NDX_PROVIDER_TIMESTAMP_REQUIRED')
    p=D(str(rows[-1]['close']));q=D(str(direct['price']))
    if p<=0 or q<=0 or abs(p-q)/((p+q)/2)>D(str(model.NDX_MAX_SOURCE_DIVERGENCE)):raise ValueError('NDX_DIVERGENCE')
    pt=datetime.fromtimestamp(rows[-1]['ts'],timezone.utc);st=utc(direct['exchange_timestamp_utc'])
    return Quote('NDX',p,stable_id('QGUARD_','NDX',str(p),str(q),pt,st),pt,st,
                 'Yahoo Nasdaq GIDS','Nasdaq direct timestamped',True,model._us_rth_now(),
                 min(300,int(model.NDX_MAX_PRIMARY_AGE_SECONDS)),quote_currency='RUB')

def refresh_and_guard(app):
    if app.mode=='audit':return []
    if app.settings.testing:return app.guard_once()
    assets={p.asset for a,b in app.books.items() for p in b.positions(a)}
    updates={}
    for a in sorted(assets):
        try:
            if a in ('BTC','ETH'):updates[a]=collect_crypto(a)
            # NDX historical/context collection is not used here: only direct quotes.
            elif a=='NDX':updates[a]=collect_ndx(app.model)
        except Exception as exc:
            app.last_error='quote_guard '+a+': '+type(exc).__name__
    return app.guard_once(updates)
