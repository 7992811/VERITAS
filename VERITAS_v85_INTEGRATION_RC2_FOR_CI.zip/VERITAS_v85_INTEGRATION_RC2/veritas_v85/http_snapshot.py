"""Isolated snapshot HTTP handler used in local tests, not a replacement dashboard."""
from __future__ import annotations
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from datetime import datetime,timezone
from hashlib import sha256
from .domain import canonical_json
from .snapshots import SnapshotStore
from .release import Readiness


def handler_factory(snapshots:SnapshotStore,readiness:Readiness,clock=None):
    clock=clock or (lambda:datetime.now(timezone.utc))
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_GET(self):
            status=200
            if self.path=='/healthz':
                body=b'{"alive":true,"scope":"ISOLATED_CORE"}'
            elif self.path=='/readyz':
                r=readiness.check(clock());status=200 if r['ready'] else 503
                body=canonical_json(r).encode()
            elif self.path=='/snapshot':
                s=snapshots.read(clock())
                if s.payload is None:
                    status=503;body=canonical_json({'status':s.status,'generation':s.generation}).encode()
                else:
                    # Content is already serialized, bounded and immutable. No SQL on this path.
                    body=s.payload
                self.send_response(status)
                self.send_header('Content-Type','application/json; charset=utf-8')
                self.send_header('X-Snapshot-Status',s.status)
                self.send_header('X-Snapshot-Age',str(s.age_seconds))
                self.send_header('Cache-Control','no-store')
                self.send_header('Content-Length',str(len(body)))
                self.end_headers();self.wfile.write(body);return
            else:
                status=404;body=b'{"error":"not found"}'
            self.send_response(status)
            self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Cache-Control','no-store')
            self.send_header('Content-Length',str(len(body)))
            self.end_headers();self.wfile.write(body)
    return Handler
