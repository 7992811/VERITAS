"""One pure management decision per open episode. No automatic profit-at-0.1% rule."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from .domain import (Position, Quote, Signal, Instrument, ThesisBreak, Direction,
                     HORIZON_SECONDS, utc, stable_id)


class Action(str, Enum):
    HOLD = "HOLD"
    HOLD_DATA_RISK = "HOLD_DATA_RISK"
    EXIT = "EXIT"
    EXIT_PENDING_QUOTE = "EXIT_PENDING_QUOTE"
    CLOSE_THEN_REASSESS = "CLOSE_THEN_REASSESS"


@dataclass(frozen=True)
class Intent:
    intent_id: str
    episode_id: str
    expected_revision: int
    action: Action
    reason: str
    market_event_id: str
    proposed_opposite_idea: str | None = None


def flip_confirmed(position: Position, signal: Signal, at: datetime,
                   *, minimum_information_events: int = 2) -> bool:
    at = utc(at)
    if signal.asset != position.asset or signal.direction == position.direction or signal.problem(at):
        return False
    qualified = {}
    required_horizon = HORIZON_SECONDS[position.horizon]
    for e in signal.confirmations:
        if (e.closed is True and e.direction == signal.direction
                and e.known_at <= at and e.completed_at > position.opened_at
                and HORIZON_SECONDS[e.horizon] >= required_horizon):
            qualified[e.information_id] = e
    # Multiple derived timeframes on the same information do not make new confirmations.
    return len(qualified) >= minimum_information_events


def manage(position: Position, signal: Signal | None, quote: Quote | None,
           instrument: Instrument, at: datetime, *,
           portfolio_hard_stop: bool = False, thesis_break: ThesisBreak | None = None,
           pending_exit_reason: str | None = None) -> Intent:
    at = utc(at)
    if position.asset != instrument.asset:
        raise ValueError("Position/instrument mismatch")
    quote_issue = "QUOTE_MISSING" if quote is None else quote.problem(at, instrument, for_entry=False)
    event_id = quote.event_id if quote else (thesis_break.event_id if thesis_break else "NO_QUOTE")
    # Pending requests are durable obligations. A later soft signal cannot cancel them.
    reason = pending_exit_reason
    if portfolio_hard_stop:
        reason = "PORTFOLIO_HARD_STOP"
    elif thesis_break and thesis_break.episode_id == position.episode_id and thesis_break.known_at <= at:
        reason = "THESIS_BROKEN:" + thesis_break.reason
    if reason:
        action = Action.EXIT_PENDING_QUOTE if quote_issue else Action.EXIT
    elif quote_issue:
        action, reason = Action.HOLD_DATA_RISK, quote_issue
    else:
        assert quote is not None
        hit = (quote.price <= position.stop_price if position.direction == Direction.LONG
               else quote.price >= position.stop_price)
        if hit:
            action, reason = Action.EXIT, "STRUCTURAL_STOP"
        elif signal and flip_confirmed(position, signal, at):
            action, reason = Action.CLOSE_THEN_REASSESS, "CONFIRMED_NEW_THESIS"
        else:
            action, reason = Action.HOLD, "THESIS_INTACT"
    # No minimum quantity/fraction here: an obligatory exit is valid even for dust.
    identity = stable_id("INT_", position.episode_id, position.revision,
                         action.value, reason, event_id, position.policy_version)
    proposed = signal.idea_id if signal and action == Action.CLOSE_THEN_REASSESS else None
    return Intent(identity, position.episode_id, position.revision,
                  action, reason, event_id, proposed)
