"""Causal, revision-aware and cluster-deduplicated experience.
Hierarchical matches select one weight for an episode; they never add samples.
Estimates are not advertised as calibrated probabilities. No automatic promotion.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from math import exp, log, isfinite, sqrt
from typing import Iterable
from .domain import D, ONE, ZERO, decimal, utc


@dataclass(frozen=True)
class Context:
    asset: str
    horizon: str
    setup: str
    direction: str
    regime: str


@dataclass(frozen=True)
class Lesson:
    episode_id: str
    information_cluster: str
    policy_version: str
    context: Context
    closed_at: datetime
    matured_at: datetime
    known_at: datetime
    revision: int
    net_return: Decimal | None
    status: str = "MATURE"
    observation_weight: float = 1.0
    causal_error: str | None = None

    def __post_init__(self) -> None:
        for name in ("closed_at", "matured_at", "known_at"):
            object.__setattr__(self, name, utc(getattr(self, name)))
        if not self.episode_id or not self.information_cluster or not self.policy_version:
            raise ValueError("Lesson episode, independent information cluster and policy required")
        if self.revision < 1 or self.status not in ("PENDING", "MATURE", "RETRACTED"):
            raise ValueError("Invalid lesson revision/status")
        if not self.closed_at <= self.matured_at <= self.known_at:
            raise ValueError("Lesson violates causal outcome time")
        if not isfinite(self.observation_weight) or not 0 < self.observation_weight <= 1:
            raise ValueError("Weight must be finite in (0,1]")
        if self.net_return is not None:
            object.__setattr__(self, "net_return", decimal(self.net_return))
        if self.status == "MATURE" and self.net_return is None:
            raise ValueError("Mature lesson needs a realized net outcome")


@dataclass(frozen=True)
class Experience:
    independent_n: int
    effective_n: float
    exact_n: int
    weighted_net_mean: float | None
    win_rate_estimate: float | None
    profit_factor: float | None
    episode_ids: tuple[str, ...]
    information_clusters: tuple[str, ...]
    known_through: datetime | None
    observations_are_calibrated: bool = False


def _similarity(target: Context, observed: Context) -> tuple[float, bool]:
    # Require the same direction and horizon; cross-horizon transfer is not implicit.
    if target.horizon != observed.horizon or target.direction != observed.direction:
        return 0.0, False
    if target == observed:
        return 1.0, True
    if target.asset == observed.asset and target.setup == observed.setup:
        return 0.45, False
    if target.setup == observed.setup and target.regime == observed.regime:
        return 0.25, False
    if target.setup == observed.setup:
        return 0.12, False
    return 0.0, False


def summarize(lessons: Iterable[Lesson], context: Context, policy_version: str,
              as_of: datetime, *, half_life_days: float = 90.0) -> Experience:
    as_of = utc(as_of)
    if not isfinite(half_life_days) or half_life_days <= 0:
        raise ValueError("Invalid half-life")
    latest: dict[str, Lesson] = {}
    for lesson in lessons:
        if lesson.policy_version != policy_version or lesson.known_at > as_of:
            continue
        old = latest.get(lesson.episode_id)
        if old and old.revision == lesson.revision and old != lesson:
            raise ValueError("Conflicting lesson content for the same immutable revision")
        if old is None or (lesson.revision, lesson.known_at) > (old.revision, old.known_at):
            latest[lesson.episode_id] = lesson
    # Retraction removes the outcome. Do not resurrect an older mature revision.
    clusters: dict[str, tuple[Lesson, float, bool]] = {}
    for lesson in latest.values():
        if lesson.status != "MATURE" or lesson.net_return is None or lesson.matured_at > as_of:
            continue
        similarity, exact = _similarity(context, lesson.context)
        if similarity <= 0:
            continue
        age_days = max(0.0, (as_of - lesson.closed_at).total_seconds() / 86400)
        weight = lesson.observation_weight * similarity * exp(-log(2) * age_days / half_life_days)
        old = clusters.get(lesson.information_cluster)
        # Deterministic selection by information available and relevance, never by P&L.
        rank = (exact, similarity, lesson.known_at, lesson.episode_id)
        if old is None:
            clusters[lesson.information_cluster] = (lesson, weight, exact)
        else:
            prev, _, prev_exact = old
            prev_sim, _ = _similarity(context, prev.context)
            if rank > (prev_exact, prev_sim, prev.known_at, prev.episode_id):
                clusters[lesson.information_cluster] = (lesson, weight, exact)
    rows = [clusters[k] for k in sorted(clusters)]
    sw = sum(w for _, w, _ in rows)
    sw2 = sum(w*w for _, w, _ in rows)
    n = len(rows)
    neff = min(float(n), sw, sw*sw/sw2) if sw2 > 0 else 0.0
    wins = sum(w for l, w, _ in rows if l.net_return > 0)
    gain = sum(float(l.net_return)*w for l, w, _ in rows if l.net_return > 0)
    loss = -sum(float(l.net_return)*w for l, w, _ in rows if l.net_return < 0)
    net = sum(float(l.net_return)*w for l, w, _ in rows)/sw if sw > 0 else None
    # Beta(5,5) is explicit regularization, not a confidence or OOS certificate.
    posterior = (wins+5)/(sw+10) if sw > 0 else None
    pf = gain/loss if loss > 0 else None
    return Experience(n, neff, sum(1 for _, _, exact in rows if exact), net, posterior, pf,
                      tuple(l.episode_id for l, _, _ in rows),
                      tuple(l.information_cluster for l, _, _ in rows),
                      max((l.known_at for l, _, _ in rows), default=None))


@dataclass(frozen=True)
class Validation:
    validation_id: str
    policy_version: str
    context: Context
    train_end: datetime
    evaluation_start: datetime
    evaluation_end: datetime
    known_at: datetime
    approved_at: datetime | None
    evaluation_net_mean: Decimal
    expectancy_noninferior: bool
    drawdown_noninferior: bool
    open_mark_to_market_included: bool
    independent_test_clusters: int
    dataset_hash: str

    def __post_init__(self) -> None:
        for name in ("train_end", "evaluation_start", "evaluation_end", "known_at"):
            object.__setattr__(self, name, utc(getattr(self, name)))
        if self.approved_at is not None:
            object.__setattr__(self, "approved_at", utc(self.approved_at))
        object.__setattr__(self, "evaluation_net_mean", decimal(self.evaluation_net_mean))
        if not (self.train_end < self.evaluation_start <= self.evaluation_end <= self.known_at):
            raise ValueError("Validation windows overlap or use unavailable future information")
        if self.approved_at is not None and self.approved_at < self.known_at:
            raise ValueError("Validation approved before results were available")
        if not self.validation_id or not self.dataset_hash or self.independent_test_clusters < 0:
            raise ValueError("Validation provenance required")

    def permits(self, context: Context, policy: str, at: datetime,
                approved_ids: frozenset[str]) -> bool:
        at = utc(at)
        return bool(self.validation_id in approved_ids and self.approved_at is not None
                    and self.approved_at <= at and self.known_at <= at
                    and self.context == context and self.policy_version == policy
                    and self.evaluation_net_mean > 0
                    and self.expectancy_noninferior and self.drawdown_noninferior
                    and self.open_mark_to_market_included and self.independent_test_clusters >= 20)


@dataclass(frozen=True)
class LearningAdjustment:
    size_multiplier: Decimal
    direction_prior: Decimal
    reason: str
    validation_id: str | None = None
    automatic_promotion: bool = False


def adjustment(experience: Experience, context: Context, policy_version: str, at: datetime,
               *, validation: Validation | None = None,
               approved_ids: frozenset[str] = frozenset(), snapshot_fresh: bool = True) -> LearningAdjustment:
    if not snapshot_fresh:
        return LearningAdjustment(ONE, ZERO, "MEMORY_STALE_OR_UNAVAILABLE")
    if experience.independent_n < 8 or experience.effective_n < 8:
        return LearningAdjustment(ONE, ZERO, "OBSERVE_ONLY")
    if experience.weighted_net_mean is None or experience.weighted_net_mean <= 0:
        # Negative net economics never reinforce risk, even with a high win rate.
        return LearningAdjustment(D("0.5"), ZERO, "NEGATIVE_NET_ECONOMICS_PROBE_ONLY")
    valid = validation and validation.permits(context, policy_version, at, approved_ids)
    if not valid:
        return LearningAdjustment(ONE, ZERO, "POSITIVE_MEMORY_REQUIRES_OOS_APPROVAL")
    if experience.exact_n < 20 or experience.effective_n < 20:
        return LearningAdjustment(ONE, ZERO, "EXACT_EVIDENCE_NOT_MATURE")
    p = experience.win_rate_estimate
    if p is None:
        return LearningAdjustment(ONE, ZERO, "NO_ESTIMATE")
    mult = D("1.10") if p >= 0.64 else ONE
    prior = ZERO
    if experience.independent_n >= 40 and experience.effective_n >= 20 and experience.exact_n >= 20:
        prior = max(D("-0.025"), min(D("0.025"), D(str(p-0.5))*D("0.12")))
    return LearningAdjustment(mult, prior, "VALIDATED_BOUNDED_ADJUSTMENT", validation.validation_id)
