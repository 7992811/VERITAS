"""Signal-first sizing within explicit caller-supplied risk limits. No broker defaults."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, ROUND_FLOOR
from .domain import D, ZERO, ONE, Instrument, Quote, Signal, Direction, decimal


@dataclass(frozen=True)
class RiskLimits:
    remaining_gross: Decimal
    asset_cap: Decimal
    stop_risk_nav: Decimal
    new_risk_allowed: bool = True
    desired_step: Decimal = D("0.05")
    soft_multiplier: Decimal = ONE

    def __post_init__(self) -> None:
        for name in ("remaining_gross", "asset_cap", "stop_risk_nav", "soft_multiplier"):
            object.__setattr__(self, name, decimal(getattr(self, name), nonnegative=True))
        object.__setattr__(self, "desired_step", decimal(self.desired_step, positive=True))
        if self.soft_multiplier > 1:
            raise ValueError("Upsizing requires a separately validated desired target, not a soft-risk multiplier")


@dataclass(frozen=True)
class Admission:
    allowed: bool
    fraction: Decimal = ZERO
    quantity: Decimal = ZERO
    stop_risk_fraction: Decimal = ZERO
    reason: str = "BLOCKED"
    nominal: Decimal = ZERO


def floor_step(value: Decimal, step: Decimal) -> Decimal:
    return (value / step).to_integral_value(rounding=ROUND_FLOOR) * step


def admit(signal: Signal, quote: Quote, instrument: Instrument, nav: Decimal,
          limits: RiskLimits, at: datetime) -> Admission:
    issue = signal.problem(at) or quote.problem(at, instrument)
    if issue:
        return Admission(False, reason=issue)
    if signal.asset != instrument.asset:
        return Admission(False, reason="SIGNAL_INSTRUMENT_MISMATCH")
    if limits.new_risk_allowed is not True:
        return Admission(False, reason="HARD_RISK_STOP")
    nav = decimal(nav, positive=True)
    long = signal.direction == Direction.LONG
    if not (signal.stop_price < quote.price if long else signal.stop_price > quote.price):
        return Admission(False, reason="STOP_DIRECTION_MISMATCH")
    distance = abs(quote.price - signal.stop_price) / quote.price
    # Entry fee plus estimated exit fee at the stop. Gaps can exceed this planned risk.
    costs = instrument.commission_rate * (ONE + signal.stop_price / quote.price)
    planned_loss_per_notional = distance + costs
    cap = min(limits.remaining_gross, limits.asset_cap,
              limits.stop_risk_nav / planned_loss_per_notional)
    if cap < limits.desired_step:
        return Admission(False, reason="RISK_BUDGET_BELOW_ONE_STEP")
    if limits.soft_multiplier == 0:
        # An explicit zero risk multiplier is not permission to restore a probe.
        return Admission(False, reason="ZERO_RISK_MULTIPLIER")
    requested = max(limits.desired_step, signal.desired_fraction * limits.soft_multiplier)
    fraction = floor_step(min(requested, cap), limits.desired_step)
    unit_nominal = quote.price * instrument.multiplier * quote.fx_to_nav
    quantity = floor_step(fraction * nav / unit_nominal, instrument.quantity_step)
    if quantity <= 0:
        return Admission(False, reason="BELOW_INSTRUMENT_LOT")
    actual_nominal = quantity * unit_nominal
    actual_fraction = actual_nominal / nav
    stop_risk = actual_fraction * planned_loss_per_notional
    # Assert post-rounding limits; never round the hard cap upward.
    if actual_fraction > cap or stop_risk > limits.stop_risk_nav:
        return Admission(False, reason="POST_ROUNDING_RISK_VIOLATION")
    return Admission(True, actual_fraction, quantity, stop_risk,
                     "SIGNAL_FIRST_RISK_VALIDATED", actual_nominal)
