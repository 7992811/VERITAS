"""One deterministic signal book per asset. Missing candidates do not manage positions."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timedelta
from math import isfinite
from typing import Any
from .domain import D, Signal, Confirmation, Quote, Instrument, utc, decimal, stable_id, canonical_json, HORIZON_SECONDS

HORIZONS=('1h','4h','1d','3d','7d')
ASSETS=('BTC','ETH','NDX','BRENT','GOLD','MOEX','CNYRUBF')


def fnum(x,default=0.0):
    try:
        if isinstance(x,bool): return default
        y=float(x)
        return y if isfinite(y) else default
    except (ValueError,TypeError): return default


def hard_reason(row:dict)->str|None:
    p=row.get('trade_plan') or {}
    if row.get('source_gate_pass') is not True: return 'SOURCE_GATE'
    if row.get('market_open') is not True: return 'MARKET_CLOSED'
    if row.get('kill_switch') is True: return 'KILL_SWITCH'
    if row.get('clock_gate_pass') is False or row.get('v70_gate_class')=='DATA_VETO':return 'SOURCE_TIME_GATE'
    ti=p.get('trade_integrity') or {}
    ec=p.get('execution_consistency') or {}
    arb=p.get('rule_arbitration') or {}
    if ti.get('hard_invalidation') is True: return 'THESIS_HARD_VETO'
    if ec.get('status')=='VETO' or (arb.get('hard_veto') or {}).get('decision')=='VETO': return 'HARD_VETO'
    if (p.get('reentry_intelligence') or {}).get('allowed') is False: return 'REENTRY_GOVERNANCE'
    if row.get('v70_gate_class')=='THESIS_VETO': return 'THESIS_HARD_VETO'
    return None


def family(row):
    p=row.get('trade_plan') or {}
    for field,label in [('impulse_genesis','IMPULSE_GENESIS'),('impulse_pivot_break','IMPULSE_PIVOT_BREAK'),
                        ('tactical_reversal','TACTICAL_REVERSAL'),('range_retest_breakout','RANGE_RETEST_BREAKOUT')]:
        x=row.get(field) or {}
        if x.get('active') is True and x.get('direction')==row.get('research_decision'): return label
    return str(p.get('setup') or 'TREND')


@dataclass(frozen=True)
class Route:
    signals: dict[str,Signal]
    trace: tuple[dict,...]


def route(summary:list[dict],at:datetime,*,lifetime_seconds:float=120)->Route:
    at=utc(at); cells={}; conflicts=set(); traces=[]
    for raw in summary:
        r=dict(raw); a=str(r.get('asset') or ''); h=str(r.get('horizon') or '')
        if a not in ASSETS or h not in HORIZONS: continue
        k=(a,h)
        if k in cells and canonical_json(cells[k])!=canonical_json(r): conflicts.add(k)
        else: cells[k]=r
    by={}
    for (a,h),r in sorted(cells.items()):
        d=str(r.get('research_decision') or 'NO_TRADE')
        reason='CONFLICTING_DUPLICATE_CELL' if (a,h) in conflicts else hard_reason(r)
        if reason:
            traces.append({'asset':a,'horizon':h,'status':'BLOCKED','reason':reason}); continue
        if d not in ('LONG','SHORT'): continue
        p=r.get('trade_plan') or {}; price=fnum(r.get('price')); stop=fnum(p.get('stop_price'))
        if price<=0 or stop<=0 or not (stop<price if d=='LONG' else stop>price):
            traces.append({'asset':a,'horizon':h,'status':'BLOCKED','reason':'STRUCTURAL_STOP_INVALID'}); continue
        conf=max(0,min(1,fnum(r.get('confidence'))))
        hs=r.get('horizon_structure') or {}
        score=max(0,min(1,fnum(hs.get('score')))) if hs.get('direction')==d else 0.0
        inst=r.get('institutional_signal') or {}; ev=inst.get('evidence_independence') or {}
        independent=min(5,max(0,fnum(ev.get('independent_count'))))
        rank=conf+0.10*score+0.03*independent
        by.setdefault(a,[]).append((r,rank))
    signals={}
    for a,items in sorted(by.items()):
        support={d:sum(w for r,w in items if r['research_decision']==d) for d in ['LONG','SHORT']}
        if abs(support['LONG']-support['SHORT'])<1e-12:
            traces.append({'asset':a,'status':'NEUTRAL','reason':'DIRECTION_TIE'}); continue
        d=max(support,key=support.get)
        ranked=sorted(((r,w) for r,w in items if r['research_decision']==d),key=lambda rw:(-rw[1],HORIZONS.index(rw[0]['horizon'])))
        r,w=ranked[0]; p=r['trade_plan']; h=r['horizon']; fam=family(r)
        desired=max(D('.05'),min(D('1'),decimal(p.get('initial_position_fraction') or '.10',nonnegative=True)))
        if p.get('eligible') is False or (p.get('trade_integrity') or {}).get('entry_permission')=='WAIT_ENTRY': desired=D('.05')
        # Heuristic confidence is not calibration. Larger initial risk requires explicit evidence.
        if r.get('calibrated_probability') is None: desired=min(desired,D('.20'))
        idea=stable_id('IDEA85_',a,d,h,fam) # never use current price as the episode identity
        confirmations=[]
        for rr,_ in ranked:
            for item in rr.get('closed_confirmations') or ():
                try:
                    e=Confirmation(**item)
                    if e.known_at<=at and e.direction.value==d: confirmations.append(e)
                except (ValueError,TypeError): continue
        unique={e.information_id:e for e in sorted(confirmations,key=lambda e:(HORIZON_SECONDS[e.horizon],e.known_at))}
        did=str(r.get('decision_id') or stable_id('D85_',a,d,h,at,r.get('score'),p.get('stop_price')))
        signals[a]=Signal(a,d,idea,did,h,decimal(p['stop_price'],positive=True),desired,at,
                          at+timedelta(seconds=lifetime_seconds),fam,str(r.get('regime') or 'UNKNOWN'),
                          confirmations=tuple(unique.values()),validated_add=False)
        traces.append({'asset':a,'direction':d,'horizon':h,'idea_id':idea,'status':'CANDIDATE',
                       'support':support,'unique_horizons':[x['horizon'] for x,_ in ranked],
                       'desired_fraction':str(desired),'score_is_probability':False})
    return Route(signals,tuple(traces))


def quote_from_raw(raw:dict,spec:Instrument,*,event_id:str|None=None)->Quote:
    meta=raw.get('v85_quote') or {}
    if not meta: raise ValueError('EXPLICIT_QUOTE_PROVENANCE_REQUIRED')
    # Conversion is deliberately the legacy normalized synthetic model, not FX accounting.
    # Both direct price sources must still be valid for the SAME reference asset.
    return Quote(spec.asset,decimal(raw.get('price'),positive=True),event_id or str(meta['event_id']),
                 utc(meta['primary_time']),utc(meta['secondary_time']) if meta.get('secondary_time') else None,
                 str(meta['primary_source']),meta.get('secondary_source'),meta.get('source_verified') is True,
                 raw.get('market_open') is True,float(meta['max_age_seconds']),quote_currency=spec.quote_currency)
