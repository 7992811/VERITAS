"""Small immutable snapshots. Read path has no database or network dependency."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from threading import RLock
from typing import Any
import json
from .domain import canonical_json, utc


@dataclass(frozen=True)
class Snapshot:
    status: str
    generation: int
    payload: bytes | None
    age_seconds: float | None
    last_error: str | None
    may_influence_decisions: bool


class SnapshotStore:
    def __init__(self, ttl_seconds: float = 900, max_bytes: int = 262144):
        if ttl_seconds <= 0 or max_bytes <= 0:
            raise ValueError("Positive snapshot bounds required")
        self.ttl_seconds = ttl_seconds
        self.max_bytes = max_bytes
        self._lock = RLock()
        self._payload: bytes | None = None
        self._published: datetime | None = None
        self._generation = 0
        self._error: str | None = None

    def publish(self, value: dict[str, Any], at: datetime) -> int:
        at = utc(at)
        if value.get("status") != "OK":
            raise ValueError("Only complete validated snapshots can be published")
        # Encoding and copying occur outside the short critical section.
        payload = canonical_json(value).encode("utf-8")
        if len(payload) > self.max_bytes:
            raise ValueError("Snapshot too large for fast path")
        with self._lock:
            if self._published is not None and at < self._published:
                raise ValueError("Snapshot publication time regression")
            self._payload, self._published = payload, at
            self._generation += 1
            self._error = None
            return self._generation

    def failure(self, error: str) -> None:
        with self._lock:
            self._error = str(error)[:500]

    def read(self, at: datetime) -> Snapshot:
        at = utc(at)
        with self._lock:
            payload, published, generation, error = self._payload, self._published, self._generation, self._error
        if payload is None or published is None:
            return Snapshot("BACKGROUND_PENDING", generation, None, None, error, False)
        age = (at-published).total_seconds()
        fresh = 0 <= age <= self.ttl_seconds
        status = "STALE" if not fresh else "DEGRADED" if error else "OK"
        return Snapshot(status, generation, payload, age, error, fresh)

    def restore(self, payload: bytes, original_published_at: datetime) -> int:
        # A restored snapshot retains its original timestamp. Restart cannot refresh stale experience.
        if len(payload) > self.max_bytes:
            raise ValueError("Snapshot too large")
        return self.publish(json.loads(payload), original_published_at)
