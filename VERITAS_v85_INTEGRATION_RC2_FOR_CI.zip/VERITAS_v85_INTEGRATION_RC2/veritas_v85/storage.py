"""Transactional on-disk SQLite test/replay ledger.
This adapter is NOT a replacement for production PostgreSQL. No /tmp default is provided.
"""
from __future__ import annotations
from contextlib import contextmanager
from pathlib import Path
import sqlite3
from typing import Iterator

SCHEMA = '\nCREATE TABLE IF NOT EXISTS v85_schema (version INTEGER PRIMARY KEY);\nINSERT OR IGNORE INTO v85_schema VALUES(1);\nINSERT OR IGNORE INTO v85_schema VALUES(2);\nCREATE TABLE IF NOT EXISTS v85_accounts (\n account_id TEXT PRIMARY KEY, initial_equity TEXT NOT NULL,\n realized_equity TEXT NOT NULL, policy_version TEXT NOT NULL);\nCREATE TABLE IF NOT EXISTS v85_positions (\n account_id TEXT NOT NULL, asset TEXT NOT NULL, episode_id TEXT NOT NULL UNIQUE,\n payload TEXT NOT NULL, entry_fee TEXT NOT NULL,\n last_price TEXT NOT NULL, last_fx TEXT NOT NULL,\n PRIMARY KEY(account_id,asset), FOREIGN KEY(account_id) REFERENCES v85_accounts(account_id));\nCREATE TABLE IF NOT EXISTS v85_episodes (\n episode_id TEXT PRIMARY KEY, account_id TEXT NOT NULL, asset TEXT NOT NULL,\n idea_id TEXT NOT NULL, policy_version TEXT NOT NULL, opened_at TEXT NOT NULL,\n closed_at TEXT, opening_event TEXT NOT NULL, closing_event TEXT,\n status TEXT NOT NULL, payload TEXT NOT NULL, net_pnl TEXT,\n FOREIGN KEY(account_id) REFERENCES v85_accounts(account_id));\nCREATE INDEX IF NOT EXISTS v85_episode_last ON v85_episodes(account_id,asset,closed_at DESC);\nCREATE TABLE IF NOT EXISTS v85_orders (\n intent_id TEXT PRIMARY KEY, episode_id TEXT NOT NULL, account_id TEXT NOT NULL,\n event_id TEXT NOT NULL, side TEXT NOT NULL, quantity TEXT NOT NULL,\n price TEXT NOT NULL, fee TEXT NOT NULL, reason TEXT NOT NULL, at TEXT NOT NULL,\n FOREIGN KEY(episode_id) REFERENCES v85_episodes(episode_id));\nCREATE TABLE IF NOT EXISTS v85_receipts (\n account_id TEXT NOT NULL, event_key TEXT NOT NULL, input_hash TEXT NOT NULL,\n result TEXT NOT NULL, PRIMARY KEY(account_id,event_key));\nCREATE TABLE IF NOT EXISTS v85_pending_exits (\n episode_id TEXT PRIMARY KEY, reason TEXT NOT NULL, requested_at TEXT NOT NULL,\n FOREIGN KEY(episode_id) REFERENCES v85_episodes(episode_id));\nCREATE TABLE IF NOT EXISTS v85_clocks (\n account_id TEXT NOT NULL,asset TEXT NOT NULL,last_at TEXT NOT NULL,\n PRIMARY KEY(account_id,asset),FOREIGN KEY(account_id) REFERENCES v85_accounts(account_id));\nCREATE TABLE IF NOT EXISTS v85_lessons (\n episode_id TEXT NOT NULL, revision INTEGER NOT NULL, known_at TEXT NOT NULL,\n payload TEXT NOT NULL, PRIMARY KEY(episode_id,revision));\n\nCREATE TABLE IF NOT EXISTS v85_cutovers (\n cutover_id TEXT PRIMARY KEY, known_at TEXT NOT NULL, payload TEXT NOT NULL);\nCREATE TABLE IF NOT EXISTS v85_snapshots (\n kind TEXT PRIMARY KEY, published_at TEXT NOT NULL, payload TEXT NOT NULL);\nCREATE TABLE IF NOT EXISTS v85_observations (\n observation_id TEXT PRIMARY KEY, known_at TEXT NOT NULL, payload TEXT NOT NULL);\nCREATE INDEX IF NOT EXISTS v85_observations_time ON v85_observations(known_at);\nCREATE INDEX IF NOT EXISTS v85_lessons_known ON v85_lessons(known_at,episode_id,revision);\nCREATE INDEX IF NOT EXISTS v85_orders_account_at ON v85_orders(account_id,at);\n\nCREATE TABLE IF NOT EXISTS v85_confirmations (\n asset TEXT NOT NULL, information_id TEXT NOT NULL, horizon TEXT NOT NULL,\n direction TEXT NOT NULL, completed_at TEXT NOT NULL, known_at TEXT NOT NULL, payload TEXT NOT NULL,\n PRIMARY KEY(asset,information_id,horizon));\nCREATE INDEX IF NOT EXISTS v85_confirmations_lookup ON v85_confirmations(asset,horizon,completed_at DESC);\nCREATE TABLE IF NOT EXISTS v85_risk (\n account_id TEXT PRIMARY KEY, high_water TEXT NOT NULL, state TEXT NOT NULL, at TEXT NOT NULL,\n FOREIGN KEY(account_id) REFERENCES v85_accounts(account_id));\n\nCREATE TABLE IF NOT EXISTS v85_path (\n episode_id TEXT NOT NULL, event_id TEXT NOT NULL, at TEXT NOT NULL, price TEXT NOT NULL,\n PRIMARY KEY(episode_id,event_id),FOREIGN KEY(episode_id) REFERENCES v85_episodes(episode_id));\nCREATE INDEX IF NOT EXISTS v85_path_episode_at ON v85_path(episode_id,at);\n\nCREATE TABLE IF NOT EXISTS v85_lesson_changes (\n seq INTEGER PRIMARY KEY AUTOINCREMENT, episode_id TEXT NOT NULL, revision INTEGER NOT NULL,\n UNIQUE(episode_id,revision));\nINSERT INTO v85_lesson_changes(episode_id,revision)\n SELECT episode_id,revision FROM v85_lessons WHERE TRUE ORDER BY known_at,episode_id,revision\n ON CONFLICT(episode_id,revision) DO NOTHING;\n'


class SQLiteLedger:
    def __init__(self, path: str | Path):
        self.path = Path(path).resolve()
        if str(path) == ":memory:":
            raise ValueError("Use an explicit on-disk test/replay path")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        c = self.connect()
        try:
            c.execute("PRAGMA journal_mode=WAL")
            c.executescript(SCHEMA)
        finally:
            c.close()

    def connect(self) -> sqlite3.Connection:
        c = sqlite3.connect(str(self.path), timeout=5, isolation_level=None)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON")
        c.execute("PRAGMA busy_timeout=5000")
        return c

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        c = self.connect()
        try:
            c.execute("BEGIN IMMEDIATE")
            yield c
            c.commit()
        except BaseException:
            c.rollback()
            raise
        finally:
            c.close()

    @contextmanager
    def read(self) -> Iterator[sqlite3.Connection]:
        c = self.connect()
        try:
            yield c
        finally:
            c.close()
