"""Fixed-rate synthetic carry assumption, versioned at entry/cutover.
Not an asserted current RUONIA fixing, broker financing quote, or exchange funding.
Rates include an explicit optional short spread. Costs accrue while positions remain open.
"""
from .domain import D,decimal,utc

def accrued(position,payload,at):
    start=utc(payload.get('funding_start_at',position.opened_at))
    end=utc(at)
    seconds=max(D('0'),D(str((end-start).total_seconds())))
    annual=decimal(payload.get('funding_annual_rate','0'),nonnegative=True)
    if annual>D('2'):raise ValueError('Unreasonable funding rate')
    return (position.quantity*position.entry_price*decimal(payload.get('entry_fx','1'),positive=True)*
            decimal(payload.get('instrument_multiplier','1'),positive=True)*annual*seconds/D('31557600'))
