"""Immutable types and strict numeric/time validation for the research ledger."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from enum import Enum
from hashlib import sha256
import json
from typing import Any, Mapping

D = Decimal
ZERO = D("0")
ONE = D("1")


def decimal(value: Any, *, nonnegative: bool = False, positive: bool = False) -> Decimal:
    if isinstance(value, bool) or value is None:
        raise ValueError("Missing or boolean financial input")
    try:
        result = value if isinstance(value, D) else D(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise ValueError("Invalid financial input") from exc
    if not result.is_finite():
        raise ValueError("Non-finite financial input")
    if positive and result <= 0:
        raise ValueError("Financial input must be positive")
    if nonnegative and result < 0:
        raise ValueError("Financial input must be nonnegative")
    return result


def utc(value: datetime | str) -> datetime:
    if isinstance(value, str):
        value = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if not isinstance(value, datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("Timezone-aware datetime required")
    return value.astimezone(timezone.utc)


def json_default(value: Any) -> Any:
    if isinstance(value, D):
        return str(value)
    if isinstance(value, datetime):
        return utc(value).isoformat()
    if isinstance(value, Enum):
        return value.value
    raise TypeError(type(value).__name__)


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"),
                      default=json_default, allow_nan=False)


def stable_id(prefix: str, *parts: Any) -> str:
    return prefix + sha256(canonical_json(parts).encode("utf-8")).hexdigest()[:32]


class Direction(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"

    @property
    def sign(self) -> Decimal:
        return ONE if self == Direction.LONG else -ONE


HORIZON_SECONDS = {"1h": 3600, "4h": 14400, "1d": 86400, "3d": 259200, "7d": 604800}


@dataclass(frozen=True)
class Instrument:
    asset: str
    quote_currency: str
    nav_currency: str
    multiplier: Decimal = ONE
    quantity_step: Decimal = D("0.00000001")
    commission_rate: Decimal = D("0.0005")
    execution_kind: str = "SYNTHETIC_PAPER"

    def __post_init__(self) -> None:
        if not self.asset or not self.quote_currency or not self.nav_currency:
            raise ValueError("Instrument identity/currencies required")
        if self.execution_kind != "SYNTHETIC_PAPER":
            raise ValueError("This candidate has no live broker adapter")
        for name in ("multiplier", "quantity_step"):
            object.__setattr__(self, name, decimal(getattr(self, name), positive=True))
        object.__setattr__(self, "commission_rate", decimal(self.commission_rate, nonnegative=True))
        if self.commission_rate >= 1:
            raise ValueError("Implausible commission")


@dataclass(frozen=True)
class Quote:
    asset: str
    price: Decimal
    event_id: str
    primary_time: datetime
    secondary_time: datetime | None
    primary_source: str
    secondary_source: str | None
    source_verified: bool
    market_open: bool
    max_age_seconds: float
    fx_to_nav: Decimal = ONE
    fx_time: datetime | None = None
    fx_verified: bool = False
    quote_currency: str = "RUB"

    def __post_init__(self) -> None:
        object.__setattr__(self, "price", decimal(self.price, positive=True))
        object.__setattr__(self, "fx_to_nav", decimal(self.fx_to_nav, positive=True))
        object.__setattr__(self, "primary_time", utc(self.primary_time))
        if self.secondary_time is not None:
            object.__setattr__(self, "secondary_time", utc(self.secondary_time))
        if self.fx_time is not None:
            object.__setattr__(self, "fx_time", utc(self.fx_time))
        if not self.asset or not self.event_id or not self.primary_source:
            raise ValueError("Quote identity required")
        age = decimal(self.max_age_seconds, positive=True)
        object.__setattr__(self, "max_age_seconds", float(age))

    def problem(self, at: datetime, instrument: Instrument, *, for_entry: bool = True) -> str | None:
        at = utc(at)
        if self.asset != instrument.asset or self.quote_currency != instrument.quote_currency:
            return "QUOTE_INSTRUMENT_MISMATCH"
        if self.source_verified is not True:
            return "SOURCE_NOT_VERIFIED"
        if not self.secondary_source or self.secondary_source == self.primary_source or self.secondary_time is None:
            return "INDEPENDENT_VERIFICATION_MISSING"
        for name, ts in (("PRIMARY", self.primary_time), ("SECONDARY", self.secondary_time)):
            age = (at - ts).total_seconds()
            if age < 0:
                return name + "_FROM_FUTURE"
            if age > self.max_age_seconds:
                return name + "_STALE"
        if self.market_open is not True:
            return "MARKET_CLOSED"
        if instrument.quote_currency == instrument.nav_currency:
            if self.fx_to_nav != ONE:
                return "SAME_CURRENCY_FX_NOT_ONE"
        else:
            if self.fx_verified is not True or self.fx_time is None:
                return "FX_UNVERIFIED"
            if not 0 <= (at-self.fx_time).total_seconds() <= self.max_age_seconds:
                return "FX_STALE_OR_FUTURE"
        return None


@dataclass(frozen=True)
class Confirmation:
    event_id: str
    information_id: str
    direction: Direction
    horizon: str
    completed_at: datetime
    known_at: datetime
    closed: bool = True

    def __post_init__(self) -> None:
        object.__setattr__(self, "direction", Direction(self.direction))
        object.__setattr__(self, "completed_at", utc(self.completed_at))
        object.__setattr__(self, "known_at", utc(self.known_at))
        if self.horizon not in HORIZON_SECONDS or not self.event_id or not self.information_id:
            raise ValueError("Invalid confirmation identity/horizon")
        if self.known_at < self.completed_at:
            raise ValueError("Confirmation known before completion")


@dataclass(frozen=True)
class Signal:
    asset: str
    direction: Direction
    idea_id: str
    decision_id: str
    horizon: str
    stop_price: Decimal
    desired_fraction: Decimal
    known_at: datetime
    expires_at: datetime
    setup_family: str = "UNCLASSIFIED"
    regime: str = "UNKNOWN"
    hard_veto: bool = False
    confirmations: tuple[Confirmation, ...] = ()
    validated_add: bool = False
    reentry_of_episode: str | None = None
    reentry_information_id: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "direction", Direction(self.direction))
        for name in ("known_at", "expires_at"):
            object.__setattr__(self, name, utc(getattr(self, name)))
        object.__setattr__(self, "stop_price", decimal(self.stop_price, positive=True))
        object.__setattr__(self, "desired_fraction", decimal(self.desired_fraction, nonnegative=True))
        object.__setattr__(self, "confirmations", tuple(self.confirmations))
        if not all((self.asset, self.idea_id, self.decision_id)) or self.horizon not in HORIZON_SECONDS:
            raise ValueError("Signal identity/horizon required")
        if self.expires_at < self.known_at:
            raise ValueError("Signal expires before it is known")

    def problem(self, at: datetime) -> str | None:
        at = utc(at)
        if not self.known_at <= at <= self.expires_at:
            return "SIGNAL_NOT_CAUSALLY_AVAILABLE"
        return "HARD_VETO" if self.hard_veto is True else None


@dataclass(frozen=True)
class Position:
    account_id: str
    episode_id: str
    idea_id: str
    asset: str
    direction: Direction
    horizon: str
    quantity: Decimal
    entry_price: Decimal
    stop_price: Decimal
    opened_at: datetime
    policy_version: str
    initial_stop: Decimal | None = None
    revision: int = 0

    def __post_init__(self) -> None:
        object.__setattr__(self, "direction", Direction(self.direction))
        object.__setattr__(self, "opened_at", utc(self.opened_at))
        for name in ("quantity", "entry_price", "stop_price"):
            object.__setattr__(self, name, decimal(getattr(self, name), positive=True))
        object.__setattr__(self, "initial_stop", decimal(self.stop_price if self.initial_stop is None else self.initial_stop, positive=True))
        if not all((self.account_id, self.episode_id, self.idea_id, self.asset, self.policy_version)):
            raise ValueError("Position identity required")
        if self.horizon not in HORIZON_SECONDS or self.revision < 0:
            raise ValueError("Position horizon/revision invalid")


@dataclass(frozen=True)
class ThesisBreak:
    episode_id: str
    known_at: datetime
    event_id: str
    reason: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "known_at", utc(self.known_at))
        if not self.episode_id or not self.event_id or not self.reason:
            raise ValueError("Thesis break must name a specific episode and event")


def position_dict(position: Position) -> dict[str, Any]:
    from dataclasses import asdict
    return json.loads(canonical_json(asdict(position)))


def position_from_dict(value: Mapping[str, Any]) -> Position:
    return Position(**dict(value))
