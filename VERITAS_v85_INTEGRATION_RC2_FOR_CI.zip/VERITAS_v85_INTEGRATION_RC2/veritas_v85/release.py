"""Static integrity and readiness checks. No download, source rewrite or runtime patching."""
from __future__ import annotations
from pathlib import Path,PurePosixPath
from hashlib import sha256
from datetime import datetime
from dataclasses import dataclass
import ast,json
from .domain import utc
from . import VERSION,SCHEMA_VERSION


def verify_manifest(root: str|Path, manifest: dict) -> dict:
    root=Path(root).resolve()
    if manifest.get('version')!=VERSION or manifest.get('schema_version')!=SCHEMA_VERSION:
        raise ValueError('Release version/schema mismatch')
    if (root/'sitecustomize.py').exists():
        tree=ast.parse((root/'sitecustomize.py').read_text())
        if any(isinstance(n,(ast.Call,ast.Import,ast.ImportFrom)) for n in ast.walk(tree)):
            raise ValueError('Self-patching legacy startup is not permitted in the candidate core')
    files=manifest.get('files')
    if not isinstance(files,dict) or not files:
        raise ValueError('Missing static file manifest')
    required={'veritas_v85/domain.py','veritas_v85/book.py','veritas_v85/learning.py','veritas_v85/release.py'}
    if not required.issubset(files):
        raise ValueError('Incomplete code manifest')
    for rel,expected in files.items():
        path=PurePosixPath(rel)
        if path.is_absolute() or '..' in path.parts or '\\' in rel:
            raise ValueError('Unsafe manifest path')
        actual=(root/str(path)).resolve()
        if not actual.is_relative_to(root) or not actual.is_file():
            raise ValueError('Missing or escaping release member')
        data=actual.read_bytes()
        if sha256(data).hexdigest()!=expected:
            raise ValueError('Release checksum mismatch: '+rel)
        if actual.suffix=='.py':
            ast.parse(data.decode('utf-8'),filename=rel)
    return {'integrity':'OK','version':VERSION,'schema_version':SCHEMA_VERSION,
            'files_verified':len(files),'production_approved':manifest.get('production_approved') is True}


@dataclass
class Readiness:
    integrity_ok: bool=False
    schema_ok: bool=False
    heartbeat: datetime|None=None
    max_heartbeat_age: float=120.0

    def check(self,at:datetime)->dict:
        at=utc(at)
        age=None if self.heartbeat is None else (at-utc(self.heartbeat)).total_seconds()
        healthy=bool(self.integrity_ok and self.schema_ok and age is not None and 0<=age<=self.max_heartbeat_age)
        return {'ready':healthy,'version':VERSION,'schema_version':SCHEMA_VERSION,
                'heartbeat_age_seconds':age,'scope':'ISOLATED_CORE',
                'production_integrated':False}
