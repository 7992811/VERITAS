"""Non-overlapping deadline scheduler. No catch-up backlog and no implicit post-work sleep."""
from __future__ import annotations
from dataclasses import dataclass
from math import floor, isfinite
from threading import Lock


@dataclass(frozen=True)
class Tick:
    start: bool
    skipped_deadlines: int
    next_deadline: float


class DeadlineScheduler:
    def __init__(self, interval: float, now: float):
        if not isfinite(interval) or not isfinite(now) or interval <= 0:
            raise ValueError("Finite positive interval and clock required")
        self.interval = interval
        self.next_deadline = now
        self.running = False
        self._lock = Lock()

    def try_start(self, now: float) -> Tick:
        if not isfinite(now):
            raise ValueError("Finite monotonic clock required")
        with self._lock:
            if self.running or now < self.next_deadline:
                return Tick(False, 0, self.next_deadline)
            skipped = max(0, floor((now-self.next_deadline)/self.interval))
            self.next_deadline += (skipped+1)*self.interval
            self.running = True
            return Tick(True, skipped, self.next_deadline)

    def finish(self) -> None:
        with self._lock:
            if not self.running:
                raise RuntimeError("No active cycle")
            self.running = False
