"""Explicit research execution contract; not a brokerage instrument master."""
from __future__ import annotations
import os, math
from dataclasses import dataclass
from pathlib import Path
from .domain import D,Instrument
from .routing import ASSETS


@dataclass(frozen=True)
class Settings:
    mode:str='audit'
    interval:float=60.0
    guard_interval:float=15.0
    learning_interval:float=300.0
    port:int=10000
    legacy_quiesced:bool=False
    testing:bool=False
    sqlite_path:str|None=None

    def __post_init__(self):
        if self.mode not in ('audit','paper','fixture'): raise ValueError('Invalid mode')
        for v in (self.interval,self.guard_interval,self.learning_interval):
            if not math.isfinite(v) or v<=0: raise ValueError('Invalid interval')
        if not 0<=self.port<=65535: raise ValueError('Invalid port')
        if self.mode=='fixture' and not self.testing: raise ValueError('Fixture mode is test-only')
        if self.sqlite_path and not self.testing: raise ValueError('SQLite mode is test-only')

    @classmethod
    def env(cls):
        testing=os.getenv('VERITAS_V85_TESTING','0')=='1'
        mode=os.getenv('VERITAS_V85_MODE','audit')
        if mode not in ('audit','paper','fixture'): raise ValueError('Invalid V85 mode')
        if mode=='fixture' and not testing: raise ValueError('Fixture mode cannot be used as production')
        path=os.getenv('VERITAS_V85_TEST_SQLITE')
        if path and not testing: raise ValueError('SQLite execution is test-only; production requires Postgres')
        result=cls(mode,max(10,float(os.getenv('VERITAS_V85_INTERVAL_SECONDS','60'))),
                   max(5,float(os.getenv('VERITAS_V85_GUARD_SECONDS','15'))),
                   max(60,float(os.getenv('VERITAS_V85_LEARNING_SECONDS','300'))),
                   int(os.getenv('PORT','10000')),os.getenv('VERITAS_V85_LEGACY_QUIESCED','0')=='1',testing,path)
        if mode=='paper' and not result.legacy_quiesced: raise ValueError('Confirm the legacy writer was stopped before cutover')
        return result


def instruments():
    # Precisely matches legacy normalized-P&L convention: nominal_in_RUB/reference_level.
    # The displayed reference price may be USD or index points; quantity here is synthetic,
    # NOT market shares/contracts. No real FX cash exposure or lot claim is made.
    return {a:Instrument(a,'RUB','RUB',commission_rate=D('.0005')) for a in ASSETS}
