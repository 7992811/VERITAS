"""Source metadata normalization; no invention of independent verification or timestamps."""
from __future__ import annotations
from datetime import datetime,timezone
from .domain import stable_id,utc
from .routing import fnum


def annotate_market(raw:dict,local_vars:dict)->dict:
    out=dict(raw); a=out.get('asset'); quality=out.get('source_quality') or []
    prices=[q for q in quality if q.get('status')=='OK' and 'proxy' not in str(q.get('role','')).lower()
            and 'context' not in str(q.get('role','')).lower()]
    primary=next((q for q in prices if 'primary' in str(q.get('role','')).lower()),None)
    secondary=next((q for q in prices if ('verification' in str(q.get('role','')).lower() or 'independent' in str(q.get('role','')).lower())
                    and primary and q.get('provider')!=primary.get('provider')),None)
    if primary:
        pt=primary.get('observed_at'); st=secondary.get('observed_at') if secondary else None
        # Nasdaq missing provider timestamp is not repaired using collection time.
        if a=='NDX':
            nas=local_vars.get('nas') or {}
            st=nas.get('exchange_timestamp_utc')
        verified=bool(primary and secondary and pt and st and out.get('source_gate_pass') is True
                      and fnum(out.get('secondary_price'))>0)
        maximum=120 if a in ('BTC','ETH') else 300
        meta={'primary_source':primary.get('provider') or primary['source'],
              'secondary_source':(secondary.get('provider') or secondary['source']) if secondary else None,
              'primary_time':pt,'secondary_time':st,'source_verified':verified,'max_age_seconds':maximum,
              'reference_asset':a,'reference_currency':'RUB' if a in ('MOEX','CNYRUBF') else 'USD',
              'accounting':'NORMALIZED_REFERENCE_LEVEL_RUB_NOT_SPOT_OR_FUTURES_LOTS'}
        meta['event_id']=stable_id('Q85_',a,pt,st,out.get('price'),out.get('secondary_price'))
        out['v85_quote']=meta
    bars=None
    for key in ['k','ndx1h','bars1h','hist']:
        x=local_vars.get(key)
        if isinstance(x,list) and x:
            if isinstance(x[0],dict) and 'ts' in x[0]:
                bars=[{**r,'completed_at':float(r['ts'])+3600} for r in x]
            elif isinstance(x[0],(list,tuple)) and len(x[0])>=7:
                bars=[{'ts':int(r[0])/1000,'close':float(r[4]),'open':float(r[1]),'high':float(r[2]),'low':float(r[3]),
                       'volume':float(r[5]),'completed_at':(int(r[6])+1)/1000} for r in x]
            if bars: break
    if bars: out['hourly_bars']=bars
    return out


def closed_structure_confirmations(model,raw:dict,horizon:str,known_at:datetime)->list[dict]:
    """One currently known closed-bar structural confirmation, not a historical backfill.
    Several derived horizons on the same underlying last bar share information_id.
    """
    known_at=utc(known_at)
    bars=[x for x in raw.get('hourly_bars') or () if fnum(x.get('completed_at'))<=known_at.timestamp()]
    if len(bars)<32: return []
    last=bars[-1]; completed=datetime.fromtimestamp(float(last['completed_at']),timezone.utc)
    # A many-hours-old end of session is not new confirming information.
    if (known_at-completed).total_seconds()>4200: return []
    x=dict(raw); x.update({'price':float(last['close']),'closes':[float(b['close']) for b in bars],
                          'highs':[float(b['high']) for b in bars],'lows':[float(b['low']) for b in bars],
                          'vols':[float(b.get('volume') or 0) for b in bars]})
    hs=model.horizon_structure_features(x,horizon)
    d=hs.get('direction')
    if d not in ('LONG','SHORT') or fnum(hs.get('score'))<.60: return []
    info=stable_id('BAR85_',raw.get('asset'),last['ts'])
    return [{'event_id':stable_id('CONF85_',info,horizon,d),'information_id':info,'direction':d,'horizon':horizon,
             'completed_at':completed.isoformat(),'known_at':known_at.isoformat(),'closed':True}]
