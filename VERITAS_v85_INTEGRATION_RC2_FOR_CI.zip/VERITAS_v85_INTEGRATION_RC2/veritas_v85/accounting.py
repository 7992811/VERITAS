"""Linear synthetic paper accounting, explicit per-side fees and FX conversion.
Not accounting for a real security, margin account or physical FX inventory.
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from .domain import Direction, Instrument, D, ZERO, ONE, decimal


@dataclass(frozen=True)
class RoundTrip:
    gross_pnl: Decimal
    entry_fee: Decimal
    exit_fee: Decimal
    funding: Decimal
    other_costs: Decimal
    net_pnl: Decimal
    nominal_return: Decimal
    nav_return: Decimal


def round_trip(direction: Direction, quantity, entry, exit_price, instrument: Instrument,
               *, entry_fx=ONE, exit_fx=ONE, funding=ZERO, other_costs=ZERO,
               entry_nav=D("1000000")) -> RoundTrip:
    quantity, entry, exit_price, entry_fx, exit_fx, entry_nav = (
        decimal(v, positive=True) for v in (quantity, entry, exit_price, entry_fx, exit_fx, entry_nav))
    funding, other_costs = (decimal(v, nonnegative=True) for v in (funding, other_costs))
    sign = Direction(direction).sign
    gross = sign * quantity * instrument.multiplier * (exit_price-entry) * exit_fx
    entry_nominal = quantity * instrument.multiplier * entry * entry_fx
    exit_nominal = quantity * instrument.multiplier * exit_price * exit_fx
    entry_fee = entry_nominal * instrument.commission_rate
    exit_fee = exit_nominal * instrument.commission_rate
    net = gross-entry_fee-exit_fee-funding-other_costs
    return RoundTrip(gross, entry_fee, exit_fee, funding, other_costs,
                     net, net / entry_nominal, net / entry_nav)
