"""Durable lesson revisions for the isolated test/replay ledger, plus snapshot publication.
Production PostgreSQL wiring remains an explicit integration gate.
"""
from __future__ import annotations
from dataclasses import asdict
from datetime import datetime
import json
from .domain import canonical_json, utc
from .learning import Lesson, Context, summarize
from .storage import SQLiteLedger
from .snapshots import SnapshotStore


def lesson_from_json(payload: str) -> Lesson:
    values=json.loads(payload)
    values['context']=Context(**values['context'])
    return Lesson(**values)


def insert_lesson(c, lesson: Lesson) -> bool:
    encoded=canonical_json(asdict(lesson))
    old=c.execute('SELECT payload FROM v85_lessons WHERE episode_id=? AND revision=?',
                  (lesson.episode_id,lesson.revision)).fetchone()
    if old:
        if old['payload']!=encoded:
            raise ValueError('Immutable lesson revision conflict')
        return False
    previous=c.execute('SELECT payload FROM v85_lessons WHERE episode_id=? ORDER BY revision DESC LIMIT 1',
                       (lesson.episode_id,)).fetchone()
    if previous:
        p=lesson_from_json(previous['payload'])
        if lesson.revision<=p.revision or lesson.known_at<p.known_at:
            raise ValueError('Lesson revision/time must advance')
        if (lesson.information_cluster,lesson.policy_version,lesson.context)!=(p.information_cluster,p.policy_version,p.context):
            raise ValueError('Lesson revision cannot change original context or evidence cluster')
    c.execute('INSERT INTO v85_lessons VALUES(?,?,?,?)',
              (lesson.episode_id,lesson.revision,lesson.known_at.isoformat(),encoded))
    c.execute('INSERT INTO v85_lesson_changes(episode_id,revision) VALUES(?,?) ON CONFLICT(episode_id,revision) DO NOTHING',(lesson.episode_id,lesson.revision))
    return True


class ExperienceService:
    def __init__(self,ledger:SQLiteLedger,snapshots:SnapshotStore):
        self.ledger=ledger
        self.snapshots=snapshots
        self._cursor=None;self._lesson_rows={};self._as_of=None

    def save(self,lesson:Lesson)->bool:
        with self.ledger.transaction() as c:
            written=insert_lesson(c,lesson)
        return written

    def lessons(self,as_of:datetime)->list[Lesson]:
        at=utc(as_of)
        # Database append sequence, not market time, is the cursor. Late-known/imported
        # revisions cannot fall behind a timestamp watermark. Causal filtering remains
        # applied at the requested as_of time (including in historical replay).
        with self.ledger.read() as c:
            rows=c.execute('SELECT x.seq,l.payload FROM v85_lesson_changes x JOIN v85_lessons l ON l.episode_id=x.episode_id AND l.revision=x.revision WHERE x.seq>? ORDER BY x.seq LIMIT 501',(self._cursor or 0,)).fetchall()
        for row in rows[:500]:
            lesson=lesson_from_json(row['payload']);self._lesson_rows[(lesson.episode_id,lesson.revision)]=lesson
            self._cursor=int(row['seq'])
        self._as_of=at
        if len(rows)>500:raise RuntimeError('LEARNING_BACKLOG_MORE_PAGES; previous complete snapshot retained')
        return [l for l in self._lesson_rows.values() if l.known_at<=at]

    def refresh(self,as_of:datetime,contexts:list[Context],policy_version:str)->dict:
        """Call in the worker/replay path, never from browser or trade-admission reads."""
        at=utc(as_of)
        try:
            lessons=self.lessons(at)
            items=[]
            for context in dict.fromkeys(contexts):
                e=summarize(lessons,context,policy_version,at)
                items.append({'context':asdict(context),'experience':asdict(e)})
            output={'status':'OK','policy_version':policy_version,'items':items,
                    'known_as_of':at.isoformat(),'automatic_promotion':False}
            generation=self.snapshots.publish(output,at)
            return {'status':'OK','generation':generation,'contexts':len(items),'revision_rows':len(lessons)}
        except Exception as exc:
            self.snapshots.failure(type(exc).__name__+': '+str(exc))
            return {'status':'ERROR','error':type(exc).__name__+': '+str(exc)}


class ExperienceView:
    """Read-only trading view: no database calls. Optional human-approved validation registry."""
    def __init__(self,snapshots:SnapshotStore,*,validations=None,approved_ids=frozenset()):
        self.snapshots=snapshots
        self.validations=dict(validations or {})
        self.approved_ids=frozenset(approved_ids)

    def for_signal(self,signal,policy_version:str,at:datetime):
        from .learning import Experience,LearningAdjustment,adjustment
        from .domain import ONE,ZERO
        at=utc(at)
        snapshot=self.snapshots.read(at)
        if not snapshot.may_influence_decisions or snapshot.payload is None:
            return LearningAdjustment(ONE,ZERO,'MEMORY_STALE_OR_UNAVAILABLE')
        data=json.loads(snapshot.payload)
        if data.get('policy_version')!=policy_version or utc(data['known_as_of'])>at:
            return LearningAdjustment(ONE,ZERO,'MEMORY_POLICY_OR_TIME_MISMATCH')
        context=Context(signal.asset,signal.horizon,signal.setup_family,signal.direction.value,signal.regime)
        match=next((x for x in data.get('items',[]) if Context(**x['context'])==context),None)
        if match is None:
            return LearningAdjustment(ONE,ZERO,'NO_COMPARABLE_EPISODES')
        values=dict(match['experience'])
        values['episode_ids']=tuple(values['episode_ids'])
        values['information_clusters']=tuple(values['information_clusters'])
        if values['known_through'] is not None:values['known_through']=utc(values['known_through'])
        experience=Experience(**values)
        if experience.known_through is not None and experience.known_through>at:
            return LearningAdjustment(ONE,ZERO,'MEMORY_FROM_FUTURE')
        return adjustment(experience,context,policy_version,at,
                          validation=self.validations.get(context),approved_ids=self.approved_ids)
