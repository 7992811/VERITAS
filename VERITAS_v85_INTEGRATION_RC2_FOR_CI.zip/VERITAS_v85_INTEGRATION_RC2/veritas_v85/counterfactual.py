"""Ordered-observation replay only. It never invents intrabar path or causal error labels."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Iterable
from .domain import D, Direction, Instrument, decimal, utc
from .accounting import round_trip


@dataclass(frozen=True)
class PathPoint:
    event_id: str
    occurred_at: datetime
    known_at: datetime
    price: Decimal

    def __post_init__(self) -> None:
        object.__setattr__(self, "occurred_at", utc(self.occurred_at))
        object.__setattr__(self, "known_at", utc(self.known_at))
        object.__setattr__(self, "price", decimal(self.price, positive=True))
        if not self.event_id or self.known_at < self.occurred_at:
            raise ValueError("Invalid path event")


def path_summary(points: Iterable[PathPoint], direction: Direction, entry,
                 opened_at: datetime, as_of: datetime) -> dict:
    entry = decimal(entry, positive=True)
    opened_at, as_of = utc(opened_at), utc(as_of)
    selected: dict[str, PathPoint] = {}
    for p in points:
        if not opened_at <= p.occurred_at <= as_of or p.known_at > as_of:
            continue
        old = selected.get(p.event_id)
        if old and old != p:
            raise ValueError("Conflicting immutable path event")
        selected[p.event_id] = p
    ordered = sorted(selected.values(), key=lambda x: (x.occurred_at, x.event_id))
    returns = [Direction(direction).sign*(p.price/entry-1) for p in ordered]
    return {"n": len(ordered), "mfe": max([D(0)]+returns), "mae": min([D(0)]+returns),
            "last_return": returns[-1] if returns else None,
            "method": "OBSERVED_POINTS_ONLY_NOT_INTRABAR_EXTREMES",
            "ordered": ordered}


def alternative_stop(points: Iterable[PathPoint], direction: Direction, entry, stop,
                     opened_at: datetime, horizon_end: datetime, as_of: datetime,
                     quantity, instrument: Instrument) -> dict:
    opened_at, horizon_end, as_of = utc(opened_at), utc(horizon_end), utc(as_of)
    if as_of < horizon_end:
        return {"status": "PENDING_HORIZON", "causal_error_proven": False}
    entry, stop = decimal(entry, positive=True), decimal(stop, positive=True)
    d = Direction(direction)
    if not (stop < entry if d == Direction.LONG else stop > entry):
        raise ValueError("Invalid alternative stop geometry")
    result = path_summary(points, d, entry, opened_at, horizon_end)
    ordered = result["ordered"]
    if not ordered or ordered[-1].occurred_at < horizon_end:
        return {"status": "INSUFFICIENT_HORIZON_COVERAGE", "causal_error_proven": False}
    hit = next((p for p in ordered if p.price <= stop), None) if d == Direction.LONG else next(
        (p for p in ordered if p.price >= stop), None)
    exit_event = hit or ordered[-1]
    pnl = round_trip(d, quantity, entry, exit_event.price, instrument)
    return {"status": "OBSERVED_PATH_REPLAY", "exit_price": exit_event.price,
            "reason": "OBSERVED_STOP_CROSS" if hit else "HORIZON",
            "net_pnl": pnl.net_pnl, "causal_error_proven": False,
            "limitation": "No intrabar, liquidity or executable-price inference; not an OOS promotion test"}
