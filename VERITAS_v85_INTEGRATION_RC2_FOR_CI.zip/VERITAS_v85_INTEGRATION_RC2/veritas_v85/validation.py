"""Fail before binding a listening socket if the assembled release is inconsistent."""
from __future__ import annotations
from pathlib import Path
import ast,hashlib,json


def verify_release(root:Path,*,allow_offline_test=False)->dict:
    root=Path(root).resolve();m=json.loads((root/'release_manifest.json').read_text(encoding='utf-8'))
    if m.get('schema')!=2: raise RuntimeError('SCHEMA_MANIFEST_MISMATCH')
    if m.get('basis')!='PINNED_V80_STATIC' and not allow_offline_test:
        raise RuntimeError('UNASSEMBLED_TEST_BASIS: run the full CI build, not the offline test tree')
    required={'veritas_intelligence.py','veritas_v70.py','veritas_portfolio.py','sitecustomize.py',
              'veritas_v85/application.py','veritas_v85/book.py','veritas_v85/postgres.py','migrations/001_v85.sql','web/app.html'}
    if not required.issubset(m.get('files',{})):raise RuntimeError('INCOMPLETE_RELEASE_MANIFEST')
    for relative,expected in m['files'].items():
        p=(root/relative).resolve()
        if root not in p.parents or (root/relative).is_symlink(): raise RuntimeError('Unsafe release path')
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:
            raise RuntimeError('RELEASE_HASH_MISMATCH: '+relative)
    src=(root/'veritas_intelligence.py').read_text(encoding='utf-8');t=ast.parse(src)
    ver=[ast.literal_eval(n.value) for n in t.body if isinstance(n,ast.Assign)
         and any(isinstance(x,ast.Name) and x.id=='VERSION' for x in n.targets)]
    if ver!=[m['version']]: raise RuntimeError('RUNTIME_VERSION_MISMATCH')
    sc=ast.parse((root/'sitecustomize.py').read_text())
    if any(isinstance(n,(ast.Call,ast.Import,ast.ImportFrom)) for n in ast.walk(sc)):
        raise RuntimeError('STARTUP_PATCHER_NOT_REMOVED')
    # Direct writer calls in the old cycle would create competing execution owners.
    cyc=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='cycle']
    if len(cyc)!=1: raise RuntimeError('AMBIGUOUS_CYCLE')
    for n in ast.walk(cyc[0]):
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='step_all':
            raise RuntimeError('LEGACY_WRITER_STILL_ACTIVE')
    return {'status':'OK','version':m['version'],'basis':m['basis'],'files_verified':len(m['files'])}


def verify_runtime_version(model, expected:str):
    # Compare the actually imported module, not just the source's VERSION assignment.
    if getattr(model,'VERSION',None)!=expected:
        raise RuntimeError('IMPORTED_RUNTIME_VERSION_MISMATCH')
