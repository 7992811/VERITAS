"""Bounded PostgreSQL adapter. No destructive migrations or implicit production fallback.

Core SQL uses qmark placeholders; translation is lexical and leaves quoted text alone.
Each mutation takes one transaction-scoped advisory lock. All v85 writers share it.
The legacy writer has no fence: cutover MUST occur only after it has been stopped.
"""
from __future__ import annotations
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator
import re,uuid

LOCK_ID = 85000085
SCHEMA_VERSION = 2


def qmarks(sql: str) -> str:
    out=[]; i=0; state=None
    while i<len(sql):
        c=sql[i]
        if state in ("'", '"'):
            out.append(c)
            if c==state:
                if i+1<len(sql) and sql[i+1]==state: out.append(sql[i+1]); i+=1
                else: state=None
        elif state=='line':
            out.append(c)
            if c=='\n': state=None
        elif state=='block':
            out.append(c)
            if c=='*' and i+1<len(sql) and sql[i+1]=='/': out.append('/'); i+=1; state=None
        elif c in ("'", '"'): state=c; out.append(c)
        elif sql[i:i+2]=='--': out.append('--'); i+=1; state='line'
        elif sql[i:i+2]=='/*': out.append('/*'); i+=1; state='block'
        elif c=='?': out.append('%s')
        else: out.append(c)
        i+=1
    if state in ("'",'"','block'): raise ValueError('Unterminated SQL literal/comment')
    return ''.join(out)


class Connection:
    def __init__(self, conn): self.raw=conn
    def execute(self, sql: str, args=()):
        return self.raw.execute(qmarks(sql), args)


class PostgresLedger:
    dialect='postgres'
    def __init__(self, dsn: str, *, pool=None, max_size: int=4, migrate: bool=True):
        if not dsn and pool is None: raise ValueError('DATABASE_URL is required')
        if not 1<=max_size<=8: raise ValueError('Pool limit must be 1..8')
        self._owns_pool=pool is None
        if pool is None:
            from psycopg.rows import dict_row
            from psycopg_pool import ConnectionPool
            pool=ConnectionPool(dsn,min_size=0,max_size=max_size,timeout=5,max_waiting=8,
                                open=True,kwargs={'row_factory':dict_row,'autocommit':False,
                                'connect_timeout':5,'options':'-c statement_timeout=5000 -c lock_timeout=2000 -c idle_in_transaction_session_timeout=15000',
                                'application_name':'veritas-v85'})
        self.pool=pool;self.owner_id=uuid.uuid4().hex;self.require_writer_lease=False
        if migrate: self.migrate()

    def migrate(self):
        # Static, audited SQL only. No dynamic input is executed as schema.
        path=Path(__file__).resolve().parents[1]/'migrations/001_v85.sql'
        with self.pool.connection() as c:
            c.execute('SELECT pg_advisory_xact_lock(%s)',(LOCK_ID,))
            c.execute(path.read_text(encoding='utf-8'),prepare=False)
            rows=c.execute('SELECT version FROM v85_schema ORDER BY version').fetchall()
            versions={int(r['version']) for r in rows}
            if max(versions,default=0)!=SCHEMA_VERSION:
                raise RuntimeError('Unsupported v85 schema version')

    @contextmanager
    def transaction(self) -> Iterator[Connection]:
        with self.pool.connection() as c:
            # pool connection context commits or rolls back, then returns connection.
            c.execute('SELECT pg_advisory_xact_lock(%s)',(LOCK_ID,))
            yield Connection(c)

    @contextmanager
    def read(self) -> Iterator[Connection]:
        with self.pool.connection() as c:
            c.execute('SET TRANSACTION READ ONLY')
            yield Connection(c)

    def acquire_writer(self):
        with self.transaction() as c:
            # The same advisory transaction lock serializes takeovers and financial commits.
            r=c.raw.execute("""INSERT INTO v85_writer_lease VALUES(1,%s,clock_timestamp()+interval '45 seconds')
                 ON CONFLICT(singleton) DO UPDATE SET owner_id=EXCLUDED.owner_id,expires_at=EXCLUDED.expires_at
                 WHERE v85_writer_lease.owner_id=EXCLUDED.owner_id OR v85_writer_lease.expires_at<clock_timestamp()
                 RETURNING owner_id""",(self.owner_id,)).fetchone()
            return bool(r and r['owner_id']==self.owner_id)

    @contextmanager
    def financial_transaction(self):
        with self.transaction() as c:
            if self.require_writer_lease:
                r=c.raw.execute("""UPDATE v85_writer_lease SET expires_at=clock_timestamp()+interval '45 seconds'
                           WHERE singleton=1 AND owner_id=%s AND expires_at>=clock_timestamp() RETURNING owner_id""",(self.owner_id,)).fetchone()
                if not r:raise RuntimeError('WRITER_FENCED_OUT')
            yield c

    def release_writer(self):
        with self.transaction() as c:
            c.raw.execute('DELETE FROM v85_writer_lease WHERE owner_id=%s',(self.owner_id,))

    @contextmanager
    def raw_connection(self):
        """For retained analytics, not for bypassing paper-book ownership."""
        with self.pool.connection() as c: yield c

    def close(self):
        if self._owns_pool: self.pool.close()
