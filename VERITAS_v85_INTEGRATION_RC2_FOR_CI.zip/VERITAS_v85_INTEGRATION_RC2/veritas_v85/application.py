"""Integrated synthetic-paper application. Default mode is read-only cutover audit.

The full historical source is statically assembled by tools/build_release.py.
Neither HTTP requests nor the model cycle can invoke a legacy execution writer.
"""
from __future__ import annotations
from dataclasses import asdict,replace
from datetime import datetime,timezone,timedelta
from pathlib import Path
from threading import Event,RLock,Thread
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlparse,parse_qs
import copy,json,os,signal,sys,time
from .domain import D,Quote,Signal,utc,stable_id,canonical_json,decimal,position_from_dict,ThesisBreak,Confirmation
from .config import Settings,instruments
from .book import PaperBook,InputConflict
from .risk import RiskLimits
from .funding import accrued
from .routing import ASSETS,HORIZONS,route,quote_from_raw
from .providers import annotate_market,closed_structure_confirmations
from .integration import AnalyticalSnapshot,EventBatch
from .snapshots import SnapshotStore
from .experience_store import ExperienceService,ExperienceView
from .learning import Context
from .migration import prepare_legacy,apply_prepared,CUTOVER,PRICE_MODEL
from .scheduler import DeadlineScheduler
from .validation import verify_release


def now(): return datetime.now(timezone.utc)


def clean(x):
    """JSON persistence sanitizer, never used to turn invalid quotes into executable ones."""
    import math
    if isinstance(x,float) and not math.isfinite(x): return None
    if isinstance(x,dict): return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [clean(v) for v in x]
    if isinstance(x,datetime): return utc(x).isoformat()
    return x


class Application:
    def __init__(self,model,ledger,settings:Settings,*,fixture_bundles=None):
        self.model=model;self.ledger=ledger;self.settings=settings;self.specs=instruments()
        self.stop=Event();self.model_lock=RLock();self.state_lock=RLock();self.source_lock=RLock();self.execution_lock=RLock()
        self.quotes={};self.last_routes=None;self.latest_full_summary=[];self.contexts=set();self.last_analysis_at=None;self.last_guard_at=None
        self.last_error=None;self.ready=False;self.initialized=False;self.mode=settings.mode
        self.fixture_bundles=fixture_bundles;self.ui=SnapshotStore(ttl_seconds=max(180,3*settings.interval),max_bytes=262144)
        self.memory={};self.services={};self.books={};self.portfolios=[];self.legacy_audit=None
        self.io=AnalyticalSnapshot();self.batch=EventBatch();self.cache_calls=[];self.events_written=0
        self.risk_high_water={};self.threads=[];self.heartbeat={};self.critical_kill=False;self.critical_known_at=None;self.thesis_events={};self.writer_active=False
        if self.mode=='paper' and getattr(self.ledger,'dialect',None)=='postgres':self.ledger.require_writer_lease=True
        self._install()

    def _install(self):
        m=self.model;m._V85_APP=self
        if hasattr(m,'VP') and m.VP is not None: m.VP.bind(self)
        if getattr(self.ledger,'dialect',None)=='postgres': m.pg_connect=self.ledger.raw_connection
        m.pg_event=self.batch.append
        base_sources=list(getattr(m,'KNOWLEDGE_SOURCES',[]))+list(getattr(m,'MANAGER_PUBLIC_SOURCES',[]))+list(getattr(m,'MULTILINGUAL_LIBRARY_SOURCES',[]))
        base_rules=[]
        for name in ['KNOWLEDGE_RULES','NDX_KNOWLEDGE_RULES','CROSS_ASSET_KNOWLEDGE_RULES','MULTILINGUAL_LIBRARY_RULES','MANAGER_PUBLIC_RULES']:
            base_rules+=list(getattr(m,name,[]))
        try:
            es,er=m.load_external_knowledge();base_sources+=es;base_rules+=er
        except Exception: pass
        sources=list({x['source_id']:x for x in base_sources if x.get('source_id')}.values())
        rules=list({x['rule_id']:x for x in base_rules if x.get('rule_id')}.values())
        settings_defaults={'min_directional_score':getattr(m,'MIN_DIRECTIONAL_SCORE',.1),
             'kill_switch':getattr(m,'KILL_SWITCH',False),'knowledge_cio_enabled':False,'macro_cio_enabled':False,
             'meta_cio_enabled':False,'event_web_scan_enabled':False}
        definitions={
            'all_knowledge':((sources,rules),[((),{})]),
            'pg_agent_performance':([],[ ((),{}) ]),
            'pg_calibration_map':([],[ ((),{}) ]),
            'runtime_settings':(settings_defaults,[((),{})]),
            'structure_analog_board':({'status':'BUILDING','items':[]},[((1200,),{})]),
            '_decision_memory_rows':([],[ ((),{}) ,((False,),{}) ]),
            '_decision_memory_vectors':([],[ ((),{}),((False,),{}) ]),
            'v701_learning_bundle':({'status':'BUILDING','items':[]},[((),{})]),
            'asset_causal_shadow':({'score':0,'label':'BUILDING','factors':[]},[((a,),{}) for a in ASSETS]),
            'event_shadow_score':({'score':0,'events':[]},[((a,),{}) for a in ASSETS]),
            'knowledge_summary':({'sources':len(sources),'rules':len(rules),'matches':0,'mode':'SNAPSHOT'},[((),{})]),
        }
        for name,(default,calls) in definitions.items():
            self.io.install(m,name,default)
            self.cache_calls.extend((name,args,kw) for args,kw in calls)
        # Legacy completed-trade heuristics remain available in the archived source, but
        # may not open DB connections or add unvalidated execution authority in v85.
        for name,default in {
            'setup_profitability_profile':{'status':'BUILDING','n':0,'decision_influence':False},
            'trade_path_profile':{'status':'BUILDING','n':0,'decision_influence':False},
            '_v77_recent_closed_trade':None,
            'regime_route_for':{'status':'BUILDING','route':'V85_EXPERIENCE_OWNED','position_multiplier':1.0,'decision_influence':False},
        }.items(): self.io.install(m,name,default)
        original_pg_status=getattr(m,'pg_storage_status',None)
        self.io.install(m,'pg_storage_status',{'enabled':getattr(self.ledger,'dialect',None)=='postgres','ok':True,'source':'BOOTSTRAP_VERIFIED'})
        self.cache_calls.append(('pg_storage_status',(),{}))
        # Independent IO can be measured/refreshed, but never initiated by an HTTP snapshot read.
        if self.fixture_bundles is not None:
            if not self.settings.testing: raise RuntimeError('Fixture source prohibited outside tests')
            m.prefetch_market_bundles=lambda:(copy.deepcopy(self.fixture_bundles),{'workers':0,'wall_seconds':0,'sum_asset_seconds':0,'parallel_wait_saved_estimate_seconds':0})
            m.source_clock_gate=lambda:{'ok':True,'test_fixture':True}

    def bootstrap(self):
        m=self.model
        # Local SQLite is a disposable analytical observation cache only. Paper execution
        # storage is the explicit PostgreSQL ledger (or test fixture SQLite).
        m.init_db()
        if getattr(self.ledger,'dialect',None)=='postgres':
            with self.ledger.raw_connection() as c:
                exists=c.execute("SELECT to_regclass('public.ledger_events') AS relation").fetchone()['relation']
            if not exists: m.pg_init()
        m.seed_knowledge();m._BOOTSTRAP_READY=True
        if getattr(self.ledger,'dialect',None)=='postgres':
            with self.ledger.read() as c:cut=c.execute('SELECT payload FROM v85_cutovers WHERE cutover_id=?',(CUTOVER,)).fetchone()
            if cut:self.legacy_audit=json.loads(cut['payload'])
            else:
                try:self.legacy_audit=self._legacy_snapshot()
                except Exception as exc:
                    self.legacy_audit={'status':'MIGRATION_BLOCKED','error':str(exc)[:250]}
                    if self.mode=='paper':raise
            if self.mode=='paper' and not cut:
                if not self.settings.legacy_quiesced: raise RuntimeError('Legacy writer not quiesced')
                from .quote_guard import require_cutover_guard_coverage
                require_cutover_guard_coverage(self.legacy_audit)
                if not self.ledger.acquire_writer():raise RuntimeError('CUTOVER_WAITING_FOR_WRITER_LEASE')
                if self.legacy_audit['account_count']:
                    apply_prepared(self.ledger,self.legacy_audit,legacy_quiesced=True,dry_run=False)
                else: raise RuntimeError('No legacy accounts: explicit initial capital setup required')
        if self.mode=='fixture':
            book=PaperBook(self.ledger,self.specs)
            for name in ('Champion','Challenger','Impulse'): book.create_account(name,D('1000000'),'85.0.0-rc2/'+name)
        with self.ledger.read() as c: accounts=[dict(x) for x in c.execute('SELECT * FROM v85_accounts').fetchall()]
        for a in accounts:
            name=a['account_id'];s=SnapshotStore(ttl_seconds=1200,max_bytes=524288)
            self.memory[name]=s;self.services[name]=ExperienceService(self.ledger,s)
            # Control is fixed policy; Challenger uses only validated, bounded experience.
            view=ExperienceView(s) if name=='Challenger' else None
            rate=D('0')
            if not self.settings.testing:
                source=next((x for x in ((self.legacy_audit or {}).get('snapshot') or {}).get('accounts',[]) if x['account_id']==name),None)
                if source is None and self.mode=='paper':raise ValueError('Cutover funding assumption not available')
                if source is not None:rate=decimal(source['source'].get('last_ruonia'),nonnegative=True)/D('100')
            self.books[name]=PaperBook(self.ledger,self.specs,experience_view=view,annual_funding_rate=rate,
                                       short_funding_spread=D('0') if self.settings.testing else D('.02'))
            self.risk_high_water[name]=max(decimal(a['realized_equity'],positive=True),decimal(a['initial_equity'],positive=True))
            with self.ledger.read() as c:
                saved=c.execute('SELECT published_at,payload FROM v85_snapshots WHERE kind=?',('experience:'+name,)).fetchone()
            if saved:
                try:s.restore(saved['payload'].encode('utf-8'),utc(saved['published_at']))
                except Exception:s.failure('RESTORE_REJECTED')
        with self.ledger.read() as c:
            saved=c.execute('SELECT published_at,payload FROM v85_snapshots WHERE kind=?',('ui',)).fetchone()
        if saved:
            try:self.ui.restore(saved['payload'].encode('utf-8'),utc(saved['published_at']))
            except Exception:self.ui.failure('RESTORE_REJECTED')
        self.initialized=True;self.ready=True
        return {'status':'OK','mode':self.mode,'active_accounts':list(self.books),'legacy_tables_untouched':True}

    def _legacy_snapshot(self):
        with self.ledger.raw_connection() as c:
            exists=c.execute("SELECT to_regclass('public.paper_portfolios') AS relation").fetchone()['relation']
            if not exists:return prepare_legacy([],[],[],now())
            accounts=[dict(r) for r in c.execute('SELECT * FROM paper_portfolios ORDER BY name').fetchall()]
            positions=[dict(r) for r in c.execute('SELECT * FROM paper_positions ORDER BY portfolio_name,asset').fetchall()]
            trades=[dict(r) for r in c.execute("SELECT * FROM paper_trades WHERE status='OPEN' ORDER BY trade_id").fetchall()]
        return prepare_legacy(accounts,positions,trades,now())

    def _flush_evidence(self,summary,cycle_id):
        rows=self.batch.take();at=now().isoformat();payload=canonical_json(clean({'summary':summary,'events':rows}))
        with self.ledger.transaction() as c:
            c.execute('INSERT INTO v85_observations VALUES(?,?,?) ON CONFLICT(observation_id) DO NOTHING',(cycle_id,at,payload))
            # Preserve the legacy research event schema for read-only analysis/backtest APIs.
            if getattr(self.ledger,'dialect',None)=='postgres':
                args=[]
                for typ,key,value,a,h,ts in rows:
                    args.append((typ+':'+key,key,typ,ts or at,a,h,canonical_json(clean(value)),self.model.VERSION))
                if args:
                    with c.raw.cursor() as cur:
                        cur.executemany('''INSERT INTO ledger_events(event_key,entity_key,event_type,event_ts,asset,horizon,payload,model_version)
                             VALUES(%s,%s,%s,%s,%s,%s,%s::jsonb,%s) ON CONFLICT(event_key) DO NOTHING''',args)
        self.events_written+=len(rows)

    def commit_cycle(self,summary,bundles,cycle_id,clock_ok=True):
        at=now()
        for row in summary:
            row['clock_gate_pass']=clock_ok is True
            raw=(bundles.get(row['asset']) or {}).get('raw') or {}
            row['decision_id']=row.get('decision_id') or cycle_id+':'+row['asset']+':'+row['horizon']
            row['closed_confirmations']=closed_structure_confirmations(self.model,raw,row['horizon'],at)
        # Persist actual information events once, preserving their original known time.
        # Repeated polls of the same underlying closed bar never create another confirmation.
        with self.ledger.transaction() as c:
            for row in summary:
                for item in row['closed_confirmations']:
                    e=Confirmation(**item)
                    prior=c.execute('SELECT direction,payload FROM v85_confirmations WHERE asset=? AND information_id=? AND horizon=?',
                                    (row['asset'],e.information_id,e.horizon)).fetchone()
                    if prior and prior['direction']!=e.direction.value:
                        raise ValueError('IMMUTABLE_CONFIRMATION_CONFLICT')
                    if not prior:
                        c.execute('INSERT INTO v85_confirmations VALUES(?,?,?,?,?,?,?)',
                          (row['asset'],e.information_id,e.horizon,e.direction.value,e.completed_at.isoformat(),e.known_at.isoformat(),canonical_json(asdict(e))))
                old=c.execute('SELECT payload FROM v85_confirmations WHERE asset=? AND horizon=? AND known_at<=? AND completed_at>=? ORDER BY completed_at DESC LIMIT 4',
                              (row['asset'],row['horizon'],at.isoformat(),(at-timedelta(hours=8)).isoformat())).fetchall()
                row['closed_confirmations']=[json.loads(x['payload']) for x in old]
        routes=route(summary,at,lifetime_seconds=max(60,self.settings.interval*2))
        current={};errors=[]
        for r in summary:
            e=r.get('episode_thesis_break')
            if e:
                try:
                    item=ThesisBreak(**e)
                    if item.known_at<=at:
                        with self.state_lock:self.thesis_events[item.episode_id]=item
                except (ValueError,TypeError):errors.append({'asset':r.get('asset'),'reason':'INVALID_EPISODE_THESIS_EVENT'})
        for a,b in bundles.items():
            raw=b.get('raw') or {}
            if not raw:continue
            try:
                q=quote_from_raw(raw,self.specs[a]);current[a]=q if clock_ok else replace(q,source_verified=False)
            except (ValueError,KeyError,TypeError) as e:
                errors.append({'asset':a,'reason':type(e).__name__+': '+str(e)[:100]})
        self._flush_evidence(summary,cycle_id)
        with self.state_lock:
            self.quotes.update(current);self.last_routes=routes;self.latest_full_summary=copy.deepcopy(clean(summary))
            for s in routes.signals.values():self.contexts.add(Context(s.asset,s.horizon,s.setup_family,s.direction.value,s.regime))
        if self.mode=='audit':
            return {'status':'AUDIT_ONLY','orders_enabled':False,'routing':list(routes.trace),'quote_errors':errors,
                    'legacy_position_count':(self.legacy_audit or {}).get('position_count')}
        results=self._process(routes.signals,current,at)
        return {'status':'OK','orders_enabled':True,'single_owner':True,'routing':list(routes.trace),'quote_errors':errors,'portfolios':results}

    def _process(self,signals,quotes,at,*,guard=False):
        with self.execution_lock:
            if self.mode=='paper':
                self.writer_active=self.ledger.acquire_writer()
                if not self.writer_active:return [{'status':'STANDBY','reason':'OTHER_V85_WRITER_OWNS_LEASE','actions':[]}]
            return self._process_locked(signals,quotes,at,guard=guard)

    def _process_locked(self,signals,quotes,at,*,guard=False):
        # Include the complete quote snapshot in batch identity; a changed peer mark
        # cannot masquerade as an immutable replay of the same economic input.
        context=copy.copy(quotes)
        bid=stable_id('B85_',sorted((a,q.event_id,q.problem(at,self.specs[a])) for a,q in context.items()))
        context={a:replace(q,event_id=stable_id('QCTX_',bid,a,q.event_id)) for a,q in context.items()}
        output=[]
        kill=(self.critical_kill or bool(getattr(self.model,'KILL_SWITCH',False)) or os.getenv('VERITAS_V85_KILL_SWITCH','0')=='1')
        critical_fresh=self.settings.testing or (self.critical_known_at is not None and 0<=(at-self.critical_known_at).total_seconds()<=60)
        for account,book in sorted(self.books.items()):
            active={p.asset:p for p in book.positions(account)}
            risk=self.account_risk(account,book,context,at)
            hard_stop=kill or risk['hard_stop']
            assets=sorted(set(active)|set(signals),key=lambda a:(a not in active,a))
            actions=[]
            for a in assets:
                q=context.get(a);s=signals.get(a)
                if account=='Impulse' and s and s.setup_family not in ('IMPULSE_GENESIS','IMPULSE_PIVOT_BREAK','TACTICAL_REVERSAL','RANGE_RETEST_BREAKOUT'):
                    s=None
                if guard:s=None
                event=q.event_id if q else stable_id('NQ85_',a,'kill' if hard_stop else 'hold')
                # A risk-state change is a new economic event even when the source price is unchanged.
                revent=stable_id('RCTX_',event,risk['state'],critical_fresh,hard_stop)
                if q is not None:
                    q=replace(q,event_id=revent)
                event=revent
                # The immutable core rechecks price time, NAV and risk on every actual mutation.
                limits=RiskLimits(risk['gross_cap'],D('.5') if account=='Impulse' else D('1'),D('.10'),
                                  new_risk_allowed=not hard_stop and critical_fresh,soft_multiplier=risk['multiplier'])
                try:
                    thesis=self.thesis_events.get(active[a].episode_id) if a in active else None
                    result=book.process(account,a,event,at,q,s,limits,quotes=context,portfolio_hard_stop=hard_stop,thesis_break=thesis)
                    actions.append({'asset':a,**result})
                except InputConflict as e:
                    # Out-of-order or conflicting input is not converted to a new arbitrary event.
                    actions.append({'asset':a,'management_reason':'INPUT_CONFLICT','error':str(e)[:120]})
            output.append({'name':account,'actions':actions})
        return output

    def guard_once(self,quote_updates=None):
        if self.mode=='audit':return []
        at=now()
        with self.state_lock:
            if quote_updates:self.quotes.update(quote_updates)
            quotes=dict(self.quotes)
        with self.io.fast_lane():out=self._process({},quotes,at,guard=True)
        self.last_guard_at=at
        return out

    def publish_cycle(self,state):
        at=now();compact=[]
        for r in state.get('summary',[]):
            p=r.get('trade_plan') or {};compact.append({'asset':r.get('asset'),'horizon':r.get('horizon'),
               'direction':r.get('research_decision'),'price':r.get('price'),'strength':r.get('confidence'),
               'regime':r.get('regime'),'source_gate':r.get('source_gate_pass') is True,
               'stop':p.get('stop_price'),'reason':r.get('blocked_reason') or p.get('reason')})
        payload={'status':'OK','model_status':state.get('status'),'at':state.get('at'),'version':self.model.VERSION,
                 'mode':self.mode,'accounting':PRICE_MODEL,'synthetic_only':True,'cells':compact,
                 'computed_cells':state.get('decisions_written'),'visible_cells':len(compact),
                 'telemetry':state.get('telemetry'),'portfolios':self.portfolio_report(),
                 'last_error':self.last_error,'production_win_rate_claim':False}
        self.ui.publish(clean(payload),at)
        snap=self.ui.read(at)
        with self.ledger.transaction() as c:
            c.execute('INSERT INTO v85_snapshots VALUES(?,?,?) ON CONFLICT(kind) DO UPDATE SET published_at=excluded.published_at,payload=excluded.payload',
                      ('ui',at.isoformat(),snap.payload.decode('utf-8')))
        self.last_analysis_at=at

    def analyze_once(self):
        if not self.initialized:raise RuntimeError('Bootstrap first')
        with self.model_lock:
            self.batch.begin()
            try:
                with self.io.fast_lane(): self.model.cycle()
            except Exception as e:
                self.batch.take();self.last_error=type(e).__name__+': '+str(e)[:200];self.ui.failure(self.last_error)
                raise

    def refresh_learning(self):
        at=now();out=[]
        self.io.refresh(self.model,self.cache_calls)
        with self.state_lock: contexts=list(self.contexts)
        for account,service in self.services.items():
            with self.ledger.read() as c:a=c.execute('SELECT policy_version FROM v85_accounts WHERE account_id=?',(account,)).fetchone()
            result=service.refresh(at,contexts,a['policy_version']);out.append(result)
            snap=self.memory[account].read(at)
            if result['status']=='OK' and snap.payload:
                with self.ledger.transaction() as c:
                    c.execute('INSERT INTO v85_snapshots VALUES(?,?,?) ON CONFLICT(kind) DO UPDATE SET published_at=excluded.published_at,payload=excluded.payload',
                              ('experience:'+account,at.isoformat(),snap.payload.decode('utf-8')))
        return out

    def account_risk(self,account,book,quotes,at):
        financial=getattr(self.ledger,'financial_transaction',self.ledger.transaction)
        with financial() as c:
            nav,gross,valid,a=book._valuation(c,account,quotes,at)
            old=c.execute('SELECT high_water FROM v85_risk WHERE account_id=?',(account,)).fetchone()
            high=decimal(old['high_water']) if old else max(decimal(a['initial_equity']),decimal(a['realized_equity']))
            if valid:high=max(high,nav)
            dd=max(D('0'),D('1')-nav/high) if high>0 else D('1')
            if dd>=D('.22'):state,cap,mult,hard='HARD_STOP',D('.25'),D('0'),True
            elif dd>=D('.20'):state,cap,mult,hard='DEFENSE_20',D('.50'),D('.35'),False
            elif dd>=D('.18'):state,cap,mult,hard='DEFENSE_18',D('1'),D('.55'),False
            elif dd>=D('.14'):state,cap,mult,hard='CAUTION_14',D('1.5'),D('.75'),False
            elif dd>=D('.10'):state,cap,mult,hard='CAUTION_10',D('1.75'),D('.90'),False
            else:state,cap,mult,hard='NORMAL',D('2'),D('1'),False
            c.execute('INSERT INTO v85_risk VALUES(?,?,?,?) ON CONFLICT(account_id) DO UPDATE SET high_water=excluded.high_water,state=excluded.state,at=excluded.at',
                      (account,str(high),state,at.isoformat()))
        return {'state':state,'gross_cap':cap,'multiplier':mult,'hard_stop':hard,'nav':nav,'nav_verified':valid,'drawdown':dd}

    def portfolio_report(self):
        report=[];at=now()
        with self.state_lock:quotes=dict(self.quotes)
        with self.ledger.read() as c:
            accounts=[dict(x) for x in c.execute('SELECT * FROM v85_accounts ORDER BY account_id').fetchall()]
            for a in accounts:
                rows=[dict(x) for x in c.execute('SELECT * FROM v85_positions WHERE account_id=? ORDER BY asset',(a['account_id'],)).fetchall()]
                unreal=D('0');positions=[];valid=True;nominal=D('0');carry_cost=D('0')
                for x in rows:
                    pos=position_from_dict(json.loads(x['payload']));q=quotes.get(pos.asset)
                    checked=q is not None and q.problem(at,self.specs[pos.asset]) is None
                    price=q.price if checked else decimal(x['last_price']);fx=q.fx_to_nav if checked else decimal(x['last_fx'])
                    direction=D('1') if pos.direction.value=='LONG' else D('-1')
                    u=direction*pos.quantity*(price-pos.entry_price)*self.specs[pos.asset].multiplier*fx
                    ep=c.execute('SELECT payload FROM v85_episodes WHERE episode_id=?',(pos.episode_id,)).fetchone()
                    fc=accrued(pos,json.loads(ep['payload']),at) if ep else D('0');carry_cost+=fc
                    unreal+=u;nominal+=pos.quantity*price*fx;valid=valid and checked
                    positions.append({**json.loads(x['payload']),'mark':str(price),'unrealized_pnl':str(u),'mark_verified':checked})
                nav=decimal(a['realized_equity'])+unreal-carry_cost
                high=c.execute('SELECT high_water,state FROM v85_risk WHERE account_id=?',(a['account_id'],)).fetchone()
                hwm=decimal(high['high_water']) if high else decimal(a['initial_equity'])
                trades=[dict(x) for x in c.execute("SELECT net_pnl,payload FROM v85_episodes WHERE account_id=? AND status='CLOSED'",(a['account_id'],)).fetchall()]
                pnls=[];migrated=[]
                for t in trades:
                    pay=json.loads(t['payload']);x=decimal(t['net_pnl']) if t['net_pnl'] is not None else None
                    original=pay.get('entry') or pay.get('opening_context') or pay
                    (migrated if original.get('legacy_trade_id') else pnls).append(x)
                pnls=[x for x in pnls if x is not None]
                report.append({'name':a['account_id'],'realized_equity':a['realized_equity'],'initial_equity':a['initial_equity'],
                    'nav':str(nav),'nav_verified':valid,'unrealized_pnl':str(unreal),'accrued_funding':str(carry_cost),'gross':str(nominal/max(nav,D('1'))),
                    'drawdown':str(max(D('0'),D('1')-nav/max(hwm,D('1')))),'risk_state':high['state'] if high else 'NORMAL',
                    'positions':positions,'closed':len(pnls),'wins':sum(p>0 for p in pnls),
                    'win_rate':float(sum(p>0 for p in pnls)/len(pnls)) if pnls else None,'closed_net_pnl':str(sum(pnls,D('0'))),
                    'legacy_migrated_closed':len(migrated),'history_scope':'V85_NEW_EPISODES; LEGACY_MIGRATED_SEPARATE',
                    'funding_model':'FIXED_RATE_AT_ENTRY_FROM_CUTOVER_ASSUMPTION_NOT_LIVE_RUONIA'})
        return {'status':'OK','version':'v85','mode':self.mode,'portfolios':report,'legacy_preserved':True,
                'legacy_positions_pending_cutover':(self.legacy_audit or {}).get('position_count',0),'price_model':PRICE_MODEL}

    def refresh_critical_settings(self):
        # Small, uncached safety read separate from all historical learning queries.
        at=now()
        try:
            if getattr(self.ledger,'dialect',None)=='postgres':
                with self.ledger.raw_connection() as c:
                    rows=c.execute("SELECT value FROM system_settings WHERE key='kill_switch'").fetchall()
                val=rows[0]['value'] if rows else False
                if isinstance(val,dict):val=val.get('value',False)
                values={'kill_switch':val}
            else:
                f=self.io.original.get('runtime_settings')
                values=f() if f else {}
            self.critical_kill=str(values.get('kill_switch',False)).lower() in ('true','1','yes','on') or bool(getattr(self.model,'KILL_SWITCH',False))
            self.critical_known_at=at
        except Exception:
            # Stale safety settings disallow new positions, never prevent structural exits.
            self.last_error='SAFETY_SETTINGS_UNAVAILABLE'
        return self.critical_known_at

    def trade_report(self,limit=100):
        limit=max(1,min(500,int(limit)))
        with self.ledger.read() as c:
            rows=[dict(r) for r in c.execute('SELECT * FROM v85_episodes ORDER BY opened_at DESC LIMIT ?',(limit,)).fetchall()]
        return {'status':'OK','items':rows,'legacy_history_separate':True}

    def start_workers(self):
        def job(interval,func,name):
            scheduler=DeadlineScheduler(interval,time.monotonic())
            while not self.stop.is_set():
                tick=scheduler.try_start(time.monotonic())
                if tick.start:
                    try:func()
                    except Exception as e:self.last_error=name+': '+type(e).__name__;self.ui.failure(self.last_error)
                    finally:
                        self.heartbeat[name]=now();scheduler.finish()
                self.stop.wait(min(.5,max(.01,scheduler.next_deadline-time.monotonic())))
        # Protection reads the latest verified marks even if model or learning is busy.
        # Fresh-source collection uses a distinct guard data lane (see quote_guard.py).
        from .quote_guard import refresh_and_guard
        for interval,func,name in [(self.settings.interval,self.analyze_once,'analysis'),
                                   (self.settings.guard_interval,lambda:refresh_and_guard(self),'guard'),
                                   (self.settings.learning_interval,self.refresh_learning,'learning'),
                                   (15,self.refresh_critical_settings,'safety-settings')]:
            t=Thread(target=job,args=(interval,func,name),name='veritas-v85-'+name,daemon=True)
            self.threads.append(t);t.start()

    def close(self):
        self.stop.set()
        for t in self.threads:t.join(timeout=6)
        if self.mode=='paper' and getattr(self.ledger,'dialect',None)=='postgres':
            try:self.ledger.release_writer()
            except Exception:pass # Expiring fenced lease prevents stale ownership after disconnect.
        close=getattr(self.ledger,'close',None)
        if close:close()


def handler(app:Application):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            path=urlparse(self.path).path
            if path in ('/healthz','/readyz'):
                heartbeat_ok=not app.threads or all(t.is_alive() for t in app.threads)
                return self.reply({'status':'OK' if app.ready and heartbeat_ok else 'NOT_READY','mode':app.mode,'version':app.model.VERSION,
                    'paper_mode_enabled':app.mode=='paper','writer_active':app.writer_active,'quotes_and_risk_checked_per_order':True,'last_analysis':app.last_analysis_at.isoformat() if app.last_analysis_at else None},200 if app.ready and heartbeat_ok else 503)
            if path in ('/','/app'):
                data=(Path(__file__).resolve().parents[1]/'web/app.html').read_bytes();return self.bytes(data,'text/html; charset=utf-8',200)
            if path in ('/api/v1/overview','/api/v85/snapshot'):
                s=app.ui.read(now())
                if s.payload is None:return self.reply({'status':'BUILDING','version':app.model.VERSION,'mode':app.mode},200)
                # Small immutable snapshot only: browser reads never open a DB connection.
                return self.bytes(s.payload,'application/json; charset=utf-8',200,{'X-Data-Status':s.status,'X-Data-Age':str(s.age_seconds)})
            if path=='/api/v85/analysis':
                a=(parse_qs(urlparse(self.path).query).get('asset') or [''])[0]
                if a not in ASSETS:return self.reply({'error':'ASSET_REQUIRED'},400)
                with app.state_lock:rows=[r for r in app.latest_full_summary if r.get('asset')==a]
                return self.reply({'status':'OK','mode':app.mode,'asset':a,'signals':rows,'read_only':True},200)
            if path=='/api/v1/paper-portfolios':
                s=app.ui.read(now())
                if not s.payload:return self.reply({'status':'BUILDING','portfolios':[]},200)
                return self.reply(json.loads(s.payload)['portfolios'],200)
            if path=='/api/v1/portfolio-trades':
                try:return self.reply(app.trade_report(100),200)
                except Exception:return self.reply({'status':'UNAVAILABLE','error':'REPORT_READ_FAILED'},503)
            return self.reply({'error':'NOT_FOUND','available':['/app','/readyz','/api/v85/snapshot','/api/v1/portfolio-trades']},404)
        def do_POST(self):self.reply({'error':'READ_ONLY_HTTP; configuration changes require an explicit deployment'},405)
        def bytes(self,data,kind,status,headers=None):
            self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
            for k,v in (headers or {}).items():self.send_header(k,v)
            self.end_headers();self.wfile.write(data)
        def reply(self,data,status):self.bytes(canonical_json(clean(data)).encode('utf-8'),'application/json; charset=utf-8',status)
        def log_message(self,*args):pass
    return Handler


def run(model):
    settings=Settings.env();root=Path(__file__).resolve().parents[1]
    check=verify_release(root,allow_offline_test=settings.testing)
    from .validation import verify_runtime_version
    verify_runtime_version(model,check['version'])
    if settings.sqlite_path:
        from .storage import SQLiteLedger
        ledger=SQLiteLedger(settings.sqlite_path)
    else:
        from .postgres import PostgresLedger
        ledger=PostgresLedger(os.environ.get('DATABASE_URL',''))
    fixture_bundles=None
    if settings.mode=='fixture':
        from tools.fixtures import bundles
        fixture_bundles=bundles(model)
    app=Application(model,ledger,settings,fixture_bundles=fixture_bundles)
    # Do not expose an open port with a silently failed schema/import/cutover.
    app.bootstrap()
    verify_runtime_version(model,check['version'])
    server=ThreadingHTTPServer(('0.0.0.0',settings.port),handler(app));server.daemon_threads=True
    def shutdown(*args):
        app.stop.set();Thread(target=server.shutdown,daemon=True).start()
    signal.signal(signal.SIGTERM,shutdown);signal.signal(signal.SIGINT,shutdown)
    print(canonical_json({'event':'v85_ready','release':check,'mode':settings.mode,'legacy_tables_untouched':True}),flush=True)
    app.start_workers()
    try:server.serve_forever(poll_interval=.2)
    finally:server.server_close();app.close()
