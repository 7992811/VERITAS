"""Explicit one-way ownership handoff, with original tables kept unchanged.

NORMALIZED_REFERENCE_LEVEL accounting preserves the old synthetic RUB ledger exactly.
It is NOT spot quantity, FX cash, or an exchange futures contract specification.
"""
from __future__ import annotations
from dataclasses import asdict
from datetime import datetime, timedelta
import json
from .domain import D, decimal, utc, Position, Signal, canonical_json, stable_id, position_dict, HORIZON_SECONDS

CUTOVER='legacy-paper-to-v85-v1'
PRICE_MODEL='NORMALIZED_REFERENCE_LEVEL_RUB'


def obj(value):
    if isinstance(value,dict): return dict(value)
    return json.loads(value or '{}')


def prepare_legacy(accounts:list[dict],positions:list[dict],trades:list[dict],at:datetime)->dict:
    at=utc(at); names={}; records=[]; trade_map={x['trade_id']:x for x in trades}
    for a in accounts:
        name=str(a['name'])
        if name in names: raise ValueError('Duplicate legacy account')
        initial=decimal(a['initial_nav_rub'],positive=True)
        realized=initial+decimal(a['realized_pnl_rub'])-decimal(a['fees_rub'],nonnegative=True)-decimal(a['funding_rub'],nonnegative=True)
        if realized<=0: raise ValueError('Legacy nonpositive equity requires manual risk resolution')
        names[name]={'account_id':name,'initial_equity':str(initial),'realized_equity':str(realized),
                     'policy_version':'85.0.0-rc2/'+name,'source':a}
    seen=set()
    for z in positions:
        name=str(z['portfolio_name']); asset=str(z['asset']); key=(name,asset)
        if name not in names or key in seen: raise ValueError('Unmatched/duplicate legacy position')
        seen.add(key)
        tr=trade_map.get(z.get('active_trade_id'))
        if tr is None or tr.get('status')!='OPEN': raise ValueError('Missing OPEN trade for legacy position')
        pp=obj(z.get('payload')); tp=obj(tr.get('payload'))
        h=str(tp.get('execution_horizon') or tr.get('horizon') or pp.get('horizon') or '')
        if h not in HORIZON_SECONDS: raise ValueError('Legacy horizon unknown: migration blocked')
        stop=decimal(z.get('stop_price'),positive=True)
        opened=utc(z.get('opened_at') or tr.get('opened_at'))
        if opened>at: raise ValueError('Legacy opening time from future')
        episode=stable_id('EP85M_',name,str(tr['trade_id']))
        idea=stable_id('IDEA85M_',asset,str(tp.get('canonical_setup_id') or tp.get('setup_id') or tr['trade_id']))
        pos=Position(name,episode,idea,asset,z['direction'],h,decimal(z['units'],positive=True),
                     decimal(z['avg_entry_price'],positive=True),stop,opened,names[name]['policy_version'])
        entry_nav=tp.get('entry_nav_rub')
        if entry_nav is None: raise ValueError('Legacy entry NAV unknown: no invented learning denominator')
        entry_nav=decimal(entry_nav,positive=True)
        signal=Signal(asset,pos.direction,idea,stable_id('D85M_',tr['trade_id']),h,stop,D('0'),opened,opened+timedelta(seconds=1),
                      setup_family=str(tp.get('setup') or 'LEGACY_UNCLASSIFIED'),regime=str(tp.get('regime') or 'LEGACY_UNKNOWN'))
        cost=decimal(tr.get('fees_rub',0),nonnegative=True)+decimal(tr.get('funding_rub',0),nonnegative=True)
        carry=decimal(tr.get('gross_pnl_rub',0))
        source_account=names[name]['source']
        rate=decimal(source_account.get('last_ruonia'),nonnegative=True)/D('100')
        if rate>D('1'):raise ValueError('Legacy funding assumption outside supported range')
        fund_start=utc(source_account.get('last_mark_at') or opened)
        if fund_start<opened or fund_start>at:raise ValueError('Invalid legacy last mark for carry migration')
        payload={'position':position_dict(pos),'signal':asdict(signal),'entry_nav':str(entry_nav),
                 'entry_fee':str(cost),'entry_fx':'1','legacy_realized_gross':str(carry),
                 'legacy_trade_id':tr['trade_id'],'scope':'SYNTHETIC_PAPER','price_model':PRICE_MODEL,
                 'funding_start_at':fund_start.isoformat(),'funding_annual_rate':str(rate+(D('.02') if pos.direction.value=='SHORT' else D('0'))),
                 'funding_model':'LEGACY_FIXED_RATE_ASSUMPTION_AT_CUTOVER',
                 'learning_policy_version':'LEGACY_MIGRATED_UNVALIDATED','source_position':z,'source_trade':tr}
        records.append({'position':position_dict(pos),'payload':payload,'cost':str(cost),
                        'mark':str(decimal(z.get('last_price'),positive=True))})
    canonical=json.loads(canonical_json({'accounts':list(names.values()),'positions':records}))
    return {'status':'OK','cutover_id':CUTOVER,'as_of':at.isoformat(),'price_model':PRICE_MODEL,
            'source_hash':stable_id('SRC_',canonical),'snapshot':canonical,
            'account_count':len(names),'position_count':len(records),'legacy_tables_untouched':True}


def apply_prepared(ledger,prepared:dict,*,legacy_quiesced:bool=False,dry_run:bool=True)->dict:
    if prepared.get('status')!='OK': raise ValueError('Unverified migration input')
    if dry_run: return {**prepared,'action':'DRY_RUN','writes':0}
    if legacy_quiesced is not True: raise RuntimeError('LEGACY_WRITER_MUST_BE_STOPPED_BEFORE_CUTOVER')
    snap=prepared['snapshot']; at=prepared['as_of']
    if stable_id('SRC_',snap)!=prepared['source_hash']:raise ValueError('MIGRATION_SNAPSHOT_HASH_MISMATCH')
    with ledger.transaction() as c:
        old=c.execute('SELECT payload FROM v85_cutovers WHERE cutover_id=?',(CUTOVER,)).fetchone()
        if old:
            saved=obj(old['payload'])
            if saved['source_hash']!=prepared['source_hash']: raise RuntimeError('Legacy changed after cutover; refusing reset')
            return {'status':'OK','action':'ALREADY_IMPORTED','writes':0,'source_hash':saved['source_hash']}
        existing=c.execute('SELECT account_id FROM v85_accounts').fetchall()
        if existing: raise RuntimeError('Existing v85 accounts: migration may not reset them')
        for a in snap['accounts']:
            c.execute('INSERT INTO v85_accounts VALUES(?,?,?,?)',(a['account_id'],a['initial_equity'],a['realized_equity'],a['policy_version']))
        for a in snap['accounts']:
            initial=decimal(a['initial_equity'],positive=True)
            high=decimal(a['source'].get('high_water_nav_rub',a['initial_equity']),positive=True)
            c.execute('INSERT INTO v85_risk VALUES(?,?,?,?)',(a['account_id'],str(max(initial,high)),'IMPORTED',at))
        for x in snap['positions']:
            p=x['position']; ep=p['episode_id']; payload=x['payload']; event=stable_id('MIG_',payload['legacy_trade_id'])
            c.execute("INSERT INTO v85_episodes VALUES(?,?,?,?,?,?,NULL,?,NULL,'OPEN',?,NULL)",
                      (ep,p['account_id'],p['asset'],p['idea_id'],p['policy_version'],p['opened_at'],event,canonical_json(payload)))
            c.execute('INSERT INTO v85_positions VALUES(?,?,?,?,?,?,?)',
                      (p['account_id'],p['asset'],ep,canonical_json(p),x['cost'],x['mark'],'1'))
        c.execute('INSERT INTO v85_cutovers VALUES(?,?,?)',(CUTOVER,at,canonical_json(prepared)))
    return {'status':'OK','action':'IMPORTED','accounts':prepared['account_count'],'positions':prepared['position_count'],
            'synthetic_orders_created':0,'source_hash':prepared['source_hash']}
