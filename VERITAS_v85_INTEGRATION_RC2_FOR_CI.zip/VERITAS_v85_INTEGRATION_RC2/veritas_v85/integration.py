"""Explicit data-provider injection for the retained analytical model.

Only IO seams are replaced. Mathematical signal functions remain in the static
source. The fast calculation lane reads a precomputed snapshot instead of opening
Postgres for every horizon. A snapshot failure keeps last good values, with expiry.
"""
from __future__ import annotations
import copy,json,threading,time
from contextlib import contextmanager
from functools import wraps
from datetime import datetime,timezone
from .domain import canonical_json


class AnalyticalSnapshot:
    def __init__(self,ttl=1800):
        self.ttl=ttl; self.values={}; self.lock=threading.RLock();self.local=threading.local();self.original={}
        self.errors={}; self.read_misses=0;self.cursor=0

    def key(self,name,args,kwargs):
        try: return name,canonical_json([args,kwargs])
        except (ValueError,TypeError): return name,repr((args,kwargs))

    @contextmanager
    def fast_lane(self):
        old=getattr(self.local,'fast',False);self.local.fast=True
        try: yield
        finally: self.local.fast=old

    def install(self,model,name,default):
        if not hasattr(model,name): return
        original=getattr(model,name);self.original[name]=original
        @wraps(original)
        def cached(*args,**kwargs):
            k=self.key(name,args,kwargs)
            if getattr(self.local,'fast',False):
                with self.lock: item=self.values.get(k)
                if item and 0<=time.monotonic()-item[0]<=self.ttl: return copy.deepcopy(item[1])
                self.read_misses+=1
                return copy.deepcopy(default() if callable(default) else default)
            value=original(*args,**kwargs)
            if isinstance(value,dict) and str(value.get('status','')).upper() in ('ERROR','DEGRADED'):
                raise RuntimeError('Failed analytic snapshot '+name)
            with self.lock:self.values[k]=(time.monotonic(),copy.deepcopy(value));self.errors.pop(k,None)
            return value
        setattr(model,name,cached)

    def refresh(self,model,calls,*,max_calls=6,budget_seconds=8):
        if not calls:return
        started=time.monotonic();processed=0
        while processed<min(max_calls,len(calls)):
            name,args,kwargs=calls[self.cursor%len(calls)];self.cursor=(self.cursor+1)%len(calls);processed+=1
            if name not in self.original:continue
            k=self.key(name,args,kwargs)
            try:getattr(model,name)(*args,**kwargs)
            except Exception as e:
                with self.lock:self.errors[k]=type(e).__name__+': '+str(e)[:160]
            if time.monotonic()-started>=budget_seconds:break


class EventBatch:
    """Research evidence is committed before paper execution. No per-event connection churn."""
    def __init__(self): self.local=threading.local()
    def begin(self): self.local.events=[]
    def append(self,event_type,entity_key,payload,asset=None,horizon=None,event_ts=None):
        events=getattr(self.local,'events',None)
        if events is None: raise RuntimeError('Research event outside a batch')
        if len(events)>=1000: raise RuntimeError('Research batch exceeds bounded size')
        events.append((event_type,entity_key,payload,asset,horizon,event_ts));return False # queued is not a confirmed INSERT
    def take(self):
        rows=getattr(self.local,'events',[]) or [];self.local.events=[];return rows
