"""VERITAS v85 integrated candidate. Synthetic paper, not broker execution."""
VERSION = "85.0.0-rc2"
SCHEMA_VERSION = 2
