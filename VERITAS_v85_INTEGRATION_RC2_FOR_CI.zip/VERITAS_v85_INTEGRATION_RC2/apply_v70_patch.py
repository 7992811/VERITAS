"""Historical patching is retired. Use the complete v85 release."""
if __name__ == "__main__":
    raise SystemExit("v85: runtime patching disabled; run tools/build_release.py at build time")
