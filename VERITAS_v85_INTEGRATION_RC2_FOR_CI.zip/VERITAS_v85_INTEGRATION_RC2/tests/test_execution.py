import unittest
from dataclasses import replace
from datetime import timedelta
from decimal import Decimal as D
from veritas_v85.execution import *
from common import *

class ManagementTests(unittest.TestCase):
    def test_missing_signal_holds_forever_until_evidence(self):
        for i in range(1,20):
            at=T+timedelta(minutes=i)
            self.assertEqual(manage(position(),None,quote(at=at,event=str(i)),SPEC,at).action,Action.HOLD)
    def test_point_one_percent_not_exit(self):
        self.assertEqual(manage(position(),None,quote('100.1'),SPEC,T).action,Action.HOLD)
    def test_minus_point_one_percent_not_exit(self):
        self.assertEqual(manage(position(),None,quote('99.9'),SPEC,T).action,Action.HOLD)
    def test_stop(self):
        self.assertEqual(manage(position(),None,quote('94'),SPEC,T).action,Action.EXIT)
    def test_dust_stop(self):
        self.assertEqual(manage(position(quantity=D('.00001')),None,quote('94'),SPEC,T).action,Action.EXIT)
    def test_short_stop(self):
        self.assertEqual(manage(position(direction='SHORT',stop_price=D('105')),None,quote('106'),SPEC,T).action,Action.EXIT)
    def test_wrong_episode_thesis_break_ignored(self):
        b=ThesisBreak('OTHER',T,'b','structure')
        self.assertEqual(manage(position(),None,quote(),SPEC,T,thesis_break=b).action,Action.HOLD)
    def test_own_thesis_break(self):
        self.assertEqual(manage(position(),None,quote(),SPEC,T,thesis_break=ThesisBreak('EP1',T,'b','structure')).action,Action.EXIT)
    def test_future_break_ignored(self):
        b=ThesisBreak('EP1',T+timedelta(days=1),'b','structure')
        self.assertEqual(manage(position(),None,quote(),SPEC,T,thesis_break=b).action,Action.HOLD)
    def test_missing_quote_no_fabrication(self):
        self.assertEqual(manage(position(),None,None,SPEC,T).action,Action.HOLD_DATA_RISK)
    def test_kill_bad_quote_pending(self):
        a=manage(position(),None,None,SPEC,T,portfolio_hard_stop=True)
        self.assertEqual(a.action,Action.EXIT_PENDING_QUOTE)
    def test_pending_exit_cannot_be_cancelled_by_signal(self):
        self.assertEqual(manage(position(),signal(),quote(),SPEC,T,pending_exit_reason='THESIS_BROKEN').action,Action.EXIT)
    def test_unconfirmed_flip(self):
        self.assertEqual(manage(position(),signal('SHORT'),quote(),SPEC,T).action,Action.HOLD)
    def test_confirmed_flip(self):
        at=T+timedelta(hours=2)
        s=signal('SHORT',at=at,confirmations=confirmations(at))
        self.assertEqual(manage(position(),s,quote(at=at),SPEC,at).action,Action.CLOSE_THEN_REASSESS)
    def test_duplicate_confirmation(self):
        at=T+timedelta(hours=2);e=confirmations(at)[0]
        s=signal('SHORT',at=at,confirmations=(e,e,e))
        self.assertFalse(flip_confirmed(position(),s,at))
    def test_wrong_direction_confirmation(self):
        at=T+timedelta(hours=2)
        s=signal('SHORT',at=at,confirmations=confirmations(at,'LONG'))
        self.assertFalse(flip_confirmed(position(),s,at))
    def test_short_horizon_does_not_own_multiday(self):
        at=T+timedelta(hours=2)
        s=signal('SHORT',at=at,confirmations=confirmations(at))
        self.assertFalse(flip_confirmed(position(horizon='3d'),s,at))
    def test_open_bar_not_confirmation(self):
        at=T+timedelta(hours=2)
        s=signal('SHORT',at=at,confirmations=tuple(replace(e,closed=False) for e in confirmations(at)))
        self.assertFalse(flip_confirmed(position(),s,at))
    def test_confirmations_before_entry_not_new(self):
        s=signal('SHORT',confirmations=confirmations(T))
        self.assertFalse(flip_confirmed(position(),s,T))
    def test_future_confirmation(self):
        at=T+timedelta(hours=2)
        s=signal('SHORT',at=at,confirmations=confirmations(at+timedelta(hours=2)))
        self.assertFalse(flip_confirmed(position(),s,at))
    def test_identical_intent_identity(self):
        self.assertEqual(manage(position(),None,quote('94'),SPEC,T).intent_id,
                         manage(position(),None,quote('94'),SPEC,T).intent_id)
    def test_stop_before_flip(self):
        at=T+timedelta(hours=2);s=signal('SHORT',at=at,confirmations=confirmations(at))
        a=manage(position(),s,quote('94',at=at),SPEC,at)
        self.assertEqual(a.action,Action.EXIT);self.assertEqual(a.reason,'STRUCTURAL_STOP')
