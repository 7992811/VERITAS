from datetime import datetime,timezone,timedelta
from decimal import Decimal as D
from veritas_v85.domain import *
from veritas_v85.risk import RiskLimits

T=datetime(2026,9,23,10,tzinfo=timezone.utc)
SPEC=Instrument('BTC','RUB','RUB')
LIMITS=RiskLimits(D('2'),D('1'),D('.10'))

def quote(price='100', at=T, event='m1', **kw):
    values=dict(asset='BTC',price=D(price),event_id=event,primary_time=at,
                secondary_time=at,primary_source='provider-a',secondary_source='provider-b',
                source_verified=True,market_open=True,max_age_seconds=60,quote_currency='RUB')
    values.update(kw)
    return Quote(**values)

def signal(direction='LONG', at=T, **kw):
    values=dict(asset='BTC',direction=direction,idea_id='idea-'+direction,decision_id='decision-'+direction,
                horizon='1h',stop_price=D('95') if direction=='LONG' else D('105'),desired_fraction=D('.05'),
                known_at=at,expires_at=at+timedelta(hours=24))
    values.update(kw)
    return Signal(**values)

def position(**kw):
    values=dict(account_id='A',episode_id='EP1',idea_id='idea-LONG',asset='BTC',direction='LONG',horizon='1h',
                quantity=D('500'),entry_price=D('100'),stop_price=D('95'),opened_at=T,policy_version='v85-test')
    values.update(kw)
    return Position(**values)

def confirmations(at, direction='SHORT', horizon='1h'):
    return tuple(Confirmation('e'+str(i),'info'+str(i),direction,horizon,
                              at-timedelta(minutes=2-i),at-timedelta(minutes=2-i)) for i in (0,1))
