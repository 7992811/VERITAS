import unittest,tempfile,json,threading,urllib.request,urllib.error
from pathlib import Path
from dataclasses import replace
from datetime import timedelta
from decimal import Decimal as D
from hashlib import sha256
from http.server import ThreadingHTTPServer
from veritas_v85.storage import SQLiteLedger
from veritas_v85.book import PaperBook
from veritas_v85.experience_store import ExperienceService
from veritas_v85.snapshots import SnapshotStore
from veritas_v85.learning import *
from veritas_v85.release import verify_manifest,Readiness
from veritas_v85.http_snapshot import handler_factory
from veritas_v85 import VERSION,SCHEMA_VERSION
from common import *

class DurableLearningTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.path=Path(self.temp.name)/'ledger.sqlite'
        self.ledger=SQLiteLedger(self.path);self.snap=SnapshotStore()
        self.exp=ExperienceService(self.ledger,self.snap);self.book=PaperBook(self.ledger,{'BTC':SPEC})
        self.book.create_account('A',1000000,'v85-test')
    def tearDown(self):self.temp.cleanup()
    def completed(self):
        self.book.process('A','BTC','m1',T,quote(),signal(),LIMITS)
        t=T+timedelta(minutes=1)
        return self.book.process('A','BTC','m2',t,quote('94',t,'m2'),None,LIMITS)
    def test_close_writes_one_lesson(self):
        self.completed();self.assertEqual(len(self.exp.lessons(T+timedelta(hours=1))),1)
    def test_replay_not_more_lessons(self):
        self.completed();t=T+timedelta(minutes=1)
        self.book.process('A','BTC','m2',t,quote('94',t,'m2'),None,LIMITS)
        self.assertEqual(len(self.exp.lessons(T+timedelta(hours=1))),1)
    def test_lessons_survive_restart(self):
        self.completed();exp=ExperienceService(SQLiteLedger(self.path),SnapshotStore())
        self.assertEqual(len(exp.lessons(T+timedelta(hours=1))),1)
    def test_lessons_not_known_before_close(self):
        self.completed();self.assertEqual(self.exp.lessons(T),[])
    def test_durable_revisions(self):
        self.completed();l=self.exp.lessons(T+timedelta(hours=1))[0]
        update=replace(l,revision=2,known_at=T+timedelta(hours=2),net_return=D('.01'))
        self.assertTrue(self.exp.save(update));self.assertFalse(self.exp.save(update))
        old=summarize(self.exp.lessons(T+timedelta(hours=1)),l.context,l.policy_version,T+timedelta(hours=1))
        new=summarize(self.exp.lessons(T+timedelta(hours=3)),l.context,l.policy_version,T+timedelta(hours=3))
        self.assertLess(old.weighted_net_mean,0);self.assertGreater(new.weighted_net_mean,0)
    def test_snapshot_build_no_promotion(self):
        self.completed();l=self.exp.lessons(T+timedelta(hours=1))[0]
        result=self.exp.refresh(T+timedelta(hours=1),[l.context],l.policy_version)
        self.assertEqual(result['status'],'OK');self.assertFalse(json.loads(self.snap.read(T+timedelta(hours=1)).payload)['automatic_promotion'])
    def test_learner_failure_preserves_last_good(self):
        self.snap.publish({'status':'OK','items':[1]},T)
        self.exp.lessons=lambda at:(_ for _ in ()).throw(RuntimeError('DB_TIMEOUT'))
        self.assertEqual(self.exp.refresh(T,[], 'v85-test')['status'],'ERROR')
        self.assertEqual(json.loads(self.snap.read(T).payload)['items'],[1])
    def test_rollback_includes_lesson(self):
        self.book.process('A','BTC','m1',T,quote(),signal(),LIMITS)
        self.book.fault_hook=lambda phase:(_ for _ in ()).throw(RuntimeError('crash')) if phase=='after_lesson_write' else None
        t=T+timedelta(minutes=1)
        with self.assertRaises(RuntimeError):self.book.process('A','BTC','m2',t,quote('94',t,'m2'),None,LIMITS)
        self.assertFalse(self.exp.lessons(T+timedelta(hours=1)));self.assertEqual(len(self.book.orders('A')),1)

class ReleaseTests(unittest.TestCase):
    def test_valid_manifest(self):
        root=Path(__file__).resolve().parents[1]
        names=['veritas_v85/domain.py','veritas_v85/book.py','veritas_v85/learning.py','veritas_v85/release.py']
        manifest={'version':VERSION,'schema_version':SCHEMA_VERSION,'files':{p:sha256((root/p).read_bytes()).hexdigest() for p in names}}
        self.assertEqual(verify_manifest(root,manifest)['files_verified'],4)
    def test_wrong_version(self):
        with self.assertRaises(ValueError):verify_manifest('.',{'version':'v80'})
    def test_tamper(self):
        root=Path(__file__).resolve().parents[1]
        names=['veritas_v85/domain.py','veritas_v85/book.py','veritas_v85/learning.py','veritas_v85/release.py']
        m={'version':VERSION,'schema_version':SCHEMA_VERSION,'files':dict.fromkeys(names,'wrong')}
        with self.assertRaises(ValueError):verify_manifest(root,m)
    def test_partial_files_not_ready(self):
        with self.assertRaises(ValueError):verify_manifest('.',{'version':VERSION,'schema_version':SCHEMA_VERSION,'files':{}})
    def test_no_heartbeat_not_ready(self):self.assertFalse(Readiness(True,True).check(T)['ready'])
    def test_stale_heartbeat_not_ready(self):self.assertFalse(Readiness(True,True,T).check(T+timedelta(minutes=3))['ready'])
    def test_readiness_separate_from_market_open(self):self.assertTrue(Readiness(True,True,T).check(T)['ready'])
    def test_bad_manifest_flag_not_ready(self):self.assertFalse(Readiness(False,True,T).check(T)['ready'])

class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.s=SnapshotStore(ttl_seconds=60);self.r=Readiness(True,True,T)
        self.server=ThreadingHTTPServer(('127.0.0.1',0),handler_factory(self.s,self.r,lambda:T))
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.url='http://127.0.0.1:'+str(self.server.server_address[1])
    def tearDown(self):self.server.shutdown();self.server.server_close();self.thread.join()
    def test_cold_snapshot_503(self):
        with self.assertRaises(urllib.error.HTTPError) as cm:urllib.request.urlopen(self.url+'/snapshot')
        self.assertEqual(cm.exception.code,503)
    def test_hot_snapshot(self):
        self.s.publish({'status':'OK','items':[1]},T)
        with urllib.request.urlopen(self.url+'/snapshot') as r:
            self.assertEqual(r.status,200);self.assertEqual(r.headers['X-Snapshot-Status'],'OK')
            self.assertEqual(json.loads(r.read())['items'],[1])
    def test_health(self):
        with urllib.request.urlopen(self.url+'/healthz') as r:self.assertTrue(json.loads(r.read())['alive'])
    def test_readiness(self):
        with urllib.request.urlopen(self.url+'/readyz') as r:self.assertTrue(json.loads(r.read())['ready'])

class LearningToDecisionTests(unittest.TestCase):
    def setUp(self):
        from veritas_v85.experience_store import ExperienceView
        self.temp=tempfile.TemporaryDirectory();self.ledger=SQLiteLedger(Path(self.temp.name)/'l.sqlite')
        self.snap=SnapshotStore(ttl_seconds=900);self.service=ExperienceService(self.ledger,self.snap)
        self.ctx=Context('BTC','1h','UNCLASSIFIED','LONG','UNKNOWN')
        self.view=ExperienceView(self.snap)
        self.book=PaperBook(self.ledger,{'BTC':SPEC},experience_view=self.view)
        self.book.create_account('A',1000000,'v85-test')
    def tearDown(self):self.temp.cleanup()
    def populate(self,value):
        for i in range(12):
            self.service.save(Lesson('past'+str(i),'past-info'+str(i),'v85-test',self.ctx,T,T,T,1,D(value)))
        self.service.refresh(T,[self.ctx],'v85-test')
    def test_past_losses_reduce_actual_next_order(self):
        self.populate('-.01')
        r=self.book.process('A','BTC','m1',T,quote(),signal(desired_fraction=D('.20')),LIMITS)
        self.assertEqual(r['experience_effect']['size_multiplier'],'0.5')
        self.assertEqual(D(r['events'][0]['fraction']),D('.10'))
    def test_losses_do_not_erase_valid_probe(self):
        self.populate('-.01')
        r=self.book.process('A','BTC','m1',T,quote(),signal(),LIMITS)
        self.assertEqual(D(r['events'][0]['fraction']),D('.05'))
    def test_profit_alone_no_unvalidated_upsize(self):
        self.populate('.01')
        r=self.book.process('A','BTC','m1',T,quote(),signal(desired_fraction=D('.20')),LIMITS)
        self.assertEqual(r['experience_effect']['size_multiplier'],'1')
        self.assertEqual(D(r['events'][0]['fraction']),D('.20'))
    def test_expired_snapshot_cannot_change_actual_order(self):
        self.populate('-.01');at=T+timedelta(hours=1)
        r=self.book.process('A','BTC','m2',at,quote(at=at,event='m2'),signal(at=at,desired_fraction=D('.20')),LIMITS)
        self.assertEqual(r['experience_effect']['size_multiplier'],'1')
        self.assertEqual(D(r['events'][0]['fraction']),D('.20'))
    def test_fast_path_does_not_call_learner_database(self):
        self.populate('-.01')
        self.service.lessons=lambda _:(_ for _ in ()).throw(AssertionError('DB not allowed on fast path'))
        r=self.book.process('A','BTC','m1',T,quote(),signal(),LIMITS)
        self.assertEqual(r['events'][0]['action'],'OPEN')
