"""Executable integration tests against the complete supplied analytical source.
Market inputs are deterministic fixtures; no claim of historical performance.
"""
import copy,importlib.util,json,os,sys,tempfile,unittest,hashlib,threading,urllib.request
from pathlib import Path
from datetime import datetime,timezone,timedelta
from dataclasses import replace
from unittest.mock import patch
from common import D,T,SPEC,LIMITS,quote,signal
from veritas_v85.storage import SQLiteLedger
from veritas_v85.book import PaperBook
from veritas_v85.config import Settings,instruments
from veritas_v85.routing import route,quote_from_raw
from veritas_v85.domain import Confirmation,stable_id,canonical_json
from veritas_v85.application import Application,handler
from veritas_v85.migration import prepare_legacy,apply_prepared
from veritas_v85.postgres import qmarks
from veritas_v85.providers import closed_structure_confirmations,annotate_market
from veritas_v85.validation import verify_release
from veritas_v85.funding import accrued
from veritas_v85.learning import Context,Lesson
from veritas_v85.experience_store import insert_lesson
from http.server import ThreadingHTTPServer
from tools.fixtures import bundles
ROOT=Path(__file__).resolve().parents[1]


def model_fixture(directory):
    name='vi_test_'+stable_id('',str(directory))
    with patch.dict(os.environ,{'DATABASE_URL':'','VERITAS_KNOWLEDGE_AUTOMATION':'0'}):
        sp=importlib.util.spec_from_file_location(name,ROOT/'veritas_intelligence.py')
        m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m)
    m.DB_PATH=str(Path(directory)/'analysis.sqlite');m.emitted=[]
    m.emit=lambda event,**kw:m.emitted.append({'event':event,**kw})
    return m


def legacy_fixture():
    accounts=[{'name':'Champion','initial_nav_rub':1000000,'realized_pnl_rub':100,'fees_rub':50,'funding_rub':10,
               'high_water_nav_rub':1000200,'last_ruonia':0,'last_mark_at':T.isoformat()}]
    positions=[{'portfolio_name':'Champion','asset':'BTC','direction':'LONG','units':100,'avg_entry_price':100,
                'last_price':100,'stop_price':95,'opened_at':T.isoformat(),'active_trade_id':'OLD1','payload':{'horizon':'1h'}}]
    trades=[{'trade_id':'OLD1','status':'OPEN','horizon':'1h','opened_at':T.isoformat(),'fees_rub':20,'funding_rub':5,
             'gross_pnl_rub':50,'payload':{'entry_nav_rub':1000000,'canonical_setup_id':'UTS_OLD'}}]
    return accounts,positions,trades


def row(direction='LONG',h='1h',asset='BTC',confidence=.8):
    return {'asset':asset,'horizon':h,'research_decision':direction,'confidence':confidence,'price':100,
            'source_gate_pass':True,'market_open':True,'regime':'TREND','trade_plan':{
            'stop_price':95 if direction=='LONG' else 105,'initial_position_fraction':.1,'eligible':True,'setup':'TREND'}}


class RoutingIntegrationTests(unittest.TestCase):
    def test_same_cell_duplicates_do_not_vote(self):
        r=[row(),row('SHORT',h='4h',confidence=.9)]
        self.assertEqual(route(r,T),route([r[0]]*10+[r[1]],T))
    def test_conflicting_cell_is_excluded(self):
        r=route([row(),row('SHORT')],T);self.assertFalse(r.signals)
    def test_nan_price_blocks(self):
        r=row();r['price']=float('nan');self.assertFalse(route([r],T).signals)
    def test_bool_source_not_accepted(self):
        r=row();r['source_gate_pass']=1;self.assertFalse(route([r],T).signals)
    def test_hard_veto_blocks(self):
        r=row();r['trade_plan']['trade_integrity']={'hard_invalidation':True};self.assertFalse(route([r],T).signals)
    def test_missing_signal_is_not_generated(self):self.assertFalse(route([],T).signals)
    def test_current_price_is_not_idea_identity(self):
        x=row();y=row();y['price']=100.1
        self.assertEqual(route([x],T).signals['BTC'].idea_id,route([y],T).signals['BTC'].idea_id)
    def test_opposite_confirmation_cannot_flip(self):
        r=row();r['closed_confirmations']=[dict(event_id='e1',information_id='i1',direction='SHORT',horizon='1h',completed_at=T,known_at=T)]
        self.assertEqual(route([r],T).signals['BTC'].confirmations,())
    def test_shared_information_not_multiple_confirmations(self):
        a=row();b=row(h='4h')
        for r in (a,b):r['closed_confirmations']=[dict(event_id='e'+r['horizon'],information_id='shared',direction='LONG',horizon=r['horizon'],completed_at=T,known_at=T)]
        self.assertEqual(len(route([a,b],T).signals['BTC'].confirmations),1)
    def test_single_source_quote_is_not_verified(self):
        raw={'asset':'BTC','price':100,'secondary_price':None,'source_gate_pass':True,'market_open':True,
             'source_quality':[{'source':'A','provider':'A','role':'primary live','status':'OK','observed_at':T.isoformat()}]}
        q=quote_from_raw(annotate_market(raw,{}),SPEC);self.assertIsNotNone(q.problem(T,SPEC))
    def test_missing_nasdaq_timestamp_blocks_even_receipt_is_fresh(self):
        raw={'asset':'NDX','price':100,'secondary_price':100,'source_gate_pass':True,'market_open':True,
             'source_quality':[{'source':'A','provider':'A','role':'primary live','status':'OK','observed_at':T.isoformat()},
                               {'source':'B','provider':'B','role':'verification','status':'OK','observed_at':T.isoformat()}]}
        q=quote_from_raw(annotate_market(raw,{'nas':{}}),instruments()['NDX']);self.assertIsNotNone(q.problem(T,instruments()['NDX']))
    def test_qmark_literal_preserved(self):self.assertEqual(qmarks("SELECT '?' AS x WHERE a=? -- ?\n"),"SELECT '?' AS x WHERE a=%s -- ?\n")
    def test_qmark_comment_preserved(self):self.assertEqual(qmarks('SELECT /* ? */ ?'), 'SELECT /* ? */ %s')
    def test_qmark_bad_literal_rejected(self):
        with self.assertRaises(ValueError):qmarks("SELECT '")
    def test_fixture_mode_guard(self):
        with self.assertRaises(ValueError):Settings(mode='fixture')
    def test_nan_interval_rejected(self):
        with self.assertRaises(ValueError):Settings(interval=float('nan'))


class MigrationIntegrationTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.l=SQLiteLedger(Path(self.tmp.name)/'book.sqlite');self.data=legacy_fixture()
    def tearDown(self):self.tmp.cleanup()
    def prep(self,at=T):return prepare_legacy(*self.data,at)
    def test_dry_run_zero_accounts(self):
        self.assertEqual(apply_prepared(self.l,self.prep())['writes'],0)
        with self.l.read() as c:self.assertFalse(c.execute('SELECT * FROM v85_accounts').fetchall())
    def test_migration_requires_quiescence(self):
        with self.assertRaises(RuntimeError):apply_prepared(self.l,self.prep(),dry_run=False)
    def test_migration_preserves_without_orders(self):
        apply_prepared(self.l,self.prep(),legacy_quiesced=True,dry_run=False)
        b=PaperBook(self.l,{'BTC':SPEC});self.assertEqual(b.positions('Champion')[0].quantity,D('100'));self.assertFalse(b.orders('Champion'))
    def test_migration_hash_does_not_change_with_check_time(self):self.assertEqual(self.prep()['source_hash'],self.prep(T+timedelta(hours=1))['source_hash'])
    def test_migration_idempotent_next_time(self):
        apply_prepared(self.l,self.prep(),legacy_quiesced=True,dry_run=False)
        self.assertEqual(apply_prepared(self.l,self.prep(T+timedelta(hours=1)),legacy_quiesced=True,dry_run=False)['action'],'ALREADY_IMPORTED')
    def test_changed_source_refuses_reset(self):
        apply_prepared(self.l,self.prep(),legacy_quiesced=True,dry_run=False);self.data[1][0]['units']=200
        with self.assertRaises(RuntimeError):apply_prepared(self.l,self.prep(),legacy_quiesced=True,dry_run=False)
    def test_missing_entry_nav_blocks(self):
        self.data[2][0]['payload']={}
        with self.assertRaises(ValueError):self.prep()
    def test_missing_rate_does_not_assume_zero(self):
        self.data[0][0]['last_ruonia']=None
        with self.assertRaises(ValueError):self.prep()
    def test_duplicate_position_blocks(self):
        self.data[1].append(copy.deepcopy(self.data[1][0]))
        with self.assertRaises(ValueError):self.prep()
    def test_carry_is_not_credited_twice(self):
        apply_prepared(self.l,self.prep(),legacy_quiesced=True,dry_run=False)
        b=PaperBook(self.l,{'BTC':SPEC});at=T+timedelta(minutes=1)
        r=b.process('Champion','BTC','stop',at,quote('94',at,'stop'),None,LIMITS)
        self.assertEqual(D(r['events'][0]['net_episode']),D('-579.7')) # -600 -4.7 -25 +50
        with self.l.read() as c:a=c.execute('SELECT * FROM v85_accounts').fetchone();lesson=json.loads(c.execute('SELECT payload FROM v85_lessons').fetchone()['payload'])
        self.assertEqual(D(a['realized_equity']),D('999435.3')) # 1000040 -600 -4.7
        self.assertEqual(lesson['policy_version'],'LEGACY_MIGRATED_UNVALIDATED')
    def test_initial_high_water_preserved(self):
        apply_prepared(self.l,self.prep(),legacy_quiesced=True,dry_run=False)
        with self.l.read() as c:self.assertEqual(D(c.execute('SELECT high_water FROM v85_risk').fetchone()['high_water']),D('1000200'))
    def test_failed_import_is_atomic(self):
        prepared=self.prep();prepared['snapshot']['positions'][0]['position']['account_id']='MISSING'
        with self.assertRaises(Exception):apply_prepared(self.l,prepared,legacy_quiesced=True,dry_run=False)
        with self.l.read() as c:self.assertFalse(c.execute('SELECT * FROM v85_accounts').fetchall())


class FundingIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.l=SQLiteLedger(Path(self.tmp.name)/'book.sqlite')
        self.b=PaperBook(self.l,{'BTC':SPEC},annual_funding_rate=D('.10'),short_funding_spread=D('.02'))
        self.b.create_account('A',D('1000000'),'p1')
    def tearDown(self):self.tmp.cleanup()
    def test_carry_in_nav_and_close_once(self):
        self.b.process('A','BTC','o',T,quote(event='o'),signal(),LIMITS)
        at=T+timedelta(days=1);q=quote('100',at,'m')
        hold=self.b.process('A','BTC','m',at,q,None,LIMITS)
        cost=D('50000')*D('.10')*D('86400')/D('31557600')
        self.assertEqual(D(hold['nav']),D('999975')-cost)
        r=self.b.process('A','BTC','m',at,q,None,LIMITS,portfolio_hard_stop=True)
        self.assertEqual(D(r['events'][0]['net_episode']),D('-50')-cost)
        again=self.b.process('A','BTC','m',at,q,None,LIMITS,portfolio_hard_stop=True)
        self.assertTrue(again['replayed']);self.assertEqual(len(self.b.orders('A')),2)
    def test_short_spread_explicit(self):
        self.b.process('A','BTC','o',T,quote(event='o'),signal('SHORT'),LIMITS)
        with self.l.read() as c:pay=json.loads(c.execute('SELECT payload FROM v85_episodes').fetchone()['payload'])
        self.assertEqual(D(pay['funding_annual_rate']),D('.12'))


class ApplicationIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.m=model_fixture(self.tmp.name);self.at=datetime.now(timezone.utc)
        self.l=SQLiteLedger(Path(self.tmp.name)/'paper.sqlite');self.fixture=bundles(self.m,self.at)
        self.app=Application(self.m,self.l,Settings(mode='fixture',testing=True),fixture_bundles=self.fixture)
        self.app.bootstrap()
    def tearDown(self):self.app.close();self.tmp.cleanup()
    def process(self,price='100',delta=0,event='event',sig=None,guard=False):
        at=self.at+timedelta(seconds=delta)
        return self.app._process({'BTC':sig} if sig else {},{'BTC':quote(price,at,event)},at,guard=guard)
    def test_full_35_cell_cycle_no_legacy_writer(self):
        self.m.VP.step_all=lambda *a,**k:(_ for _ in ()).throw(AssertionError('legacy write called'))
        self.app.analyze_once();self.assertEqual(self.m.last_cycle['decisions_written'],35)
        self.assertEqual(self.m.last_cycle['status'],'ok');self.assertFalse(self.m.last_cycle['errors'])
        data=json.loads(self.app.ui.read(datetime.now(timezone.utc)).payload);self.assertEqual(data['visible_cells'],35)
    def test_source_failure_visible_not_fabricated(self):
        self.fixture['NDX']['error']='SOURCE_FAILURE';self.fixture['NDX']['raw']=None
        self.app.analyze_once();data=json.loads(self.app.ui.read(datetime.now(timezone.utc)).payload)
        self.assertEqual(data['visible_cells'],35);self.assertEqual(data['computed_cells'],30)
        self.assertTrue(all(r['price'] is None for r in data['cells'] if r['asset']=='NDX'))
    def test_plus_point_one_percent_does_not_close(self):
        self.process(event='a',sig=signal(at=self.at))
        for i in range(1,5):self.process('100.1',i,'m'+str(i))
        self.assertEqual(len(self.app.books['Champion'].positions('Champion')),1)
        self.assertEqual(len(self.app.books['Champion'].orders('Champion')),1)
    def test_guard_closes_without_new_signal(self):
        self.process(event='a',sig=signal(at=self.at));r=self.process('94',1,'stop',guard=True)
        self.assertFalse(self.app.books['Champion'].positions('Champion'))
        self.assertEqual(len(self.app.books['Champion'].orders('Champion')),2)
    def test_duplicate_whole_cycle_no_duplicate_order(self):
        s=signal(at=self.at);self.process(event='a',sig=s);self.process(event='a',sig=s)
        self.assertEqual(len(self.app.books['Champion'].orders('Champion')),1)
    def test_stale_quote_state_reevaluated(self):
        q=quote('100',self.at,'a');self.app._process({'BTC':signal(at=self.at)},{'BTC':q},self.at)
        self.app._process({}, {'BTC':q},self.at+timedelta(seconds=1),guard=True)
        result=self.app._process({}, {'BTC':q},self.at+timedelta(seconds=121),guard=True)
        champion=next(x for x in result if x['name']=='Champion');self.assertEqual(champion['actions'][0]['management_reason'],'PRIMARY_STALE')
    def test_unrealized_loss_in_report(self):
        self.process(event='a',sig=signal(at=self.at));q=quote('99',self.at,'n')
        self.app.quotes={'BTC':q}
        with patch('veritas_v85.application.now',return_value=self.at):report=self.app.portfolio_report()
        c=next(x for x in report['portfolios'] if x['name']=='Champion')
        self.assertEqual(D(c['unrealized_pnl']),D('-500'));self.assertLess(D(c['nav']),D(c['initial_equity']))
    def test_drawdown_hard_exit_even_with_missing_new_signal(self):
        self.process(event='a',sig=signal(at=self.at))
        with self.l.transaction() as c:c.execute('UPDATE v85_accounts SET realized_equity=? WHERE account_id=?',('700000','Champion'))
        self.process('100',1,'b',guard=True)
        self.assertFalse(self.app.books['Champion'].positions('Champion'))
    def test_risk_high_water_survives_restart(self):
        self.process(event='a',sig=signal(at=self.at));q=quote('110',self.at+timedelta(seconds=1),'up')
        risk=self.app.account_risk('Champion',self.app.books['Champion'],{'BTC':q},self.at+timedelta(seconds=1))
        with self.l.read() as c:h=D(c.execute('SELECT high_water FROM v85_risk WHERE account_id=?',('Champion',)).fetchone()['high_water'])
        self.assertGreater(h,D('1000000'))
    def test_audit_does_not_create_orders(self):
        self.app.mode='audit';self.app.analyze_once()
        self.assertFalse(self.app.books['Champion'].orders('Champion'))
    def test_missing_source_metadata_blocks_order(self):
        self.fixture['BTC']['raw'].pop('v85_quote');self.app.analyze_once()
        self.assertFalse([p for p in self.app.books['Champion'].positions('Champion') if p.asset=='BTC'])
    def test_snapshot_survives_restart_preserving_time(self):
        self.app.analyze_once();saved=self.app.ui.read(datetime.now(timezone.utc)).payload
        m=model_fixture(Path(self.tmp.name)/'second');Path(m.DB_PATH).parent.mkdir(exist_ok=True)
        second=Application(m,self.l,Settings(mode='fixture',testing=True),fixture_bundles=bundles(m));second.bootstrap()
        self.assertEqual(saved,second.ui.read(datetime.now(timezone.utc)).payload)
    def test_failed_research_transaction_opens_no_order(self):
        self.app._flush_evidence=lambda *a:(_ for _ in ()).throw(RuntimeError('DISK_FAILURE'))
        with self.assertRaises(RuntimeError):self.app.analyze_once()
        self.assertFalse(self.app.books['Champion'].orders('Champion'))
    def test_confirmations_same_bar_known_time_not_refreshed(self):
        self.app.analyze_once()
        with self.l.read() as c:before=[dict(x) for x in c.execute('SELECT * FROM v85_confirmations').fetchall()]
        self.assertTrue(before)
        self.app.analyze_once()
        with self.l.read() as c:after=[dict(x) for x in c.execute('SELECT * FROM v85_confirmations').fetchall()]
        self.assertEqual(before,after)
    def test_bad_critical_settings_not_silently_fresh(self):
        self.app.io.original['runtime_settings']=lambda:(_ for _ in ()).throw(RuntimeError('DB'))
        self.assertIsNone(self.app.refresh_critical_settings())
    def test_string_kill_switch_is_effective(self):
        self.app.io.original['runtime_settings']=lambda:{'kill_switch':'true'}
        self.app.refresh_critical_settings();self.assertTrue(self.app.critical_kill)
    def test_negative_experience_only_challenger_sizes(self):
        context=Context('BTC','1h','UNCLASSIFIED','LONG','UNKNOWN');pol='85.0.0-rc2/Challenger'
        with self.l.transaction() as c:
            for i in range(12):insert_lesson(c,Lesson('l'+str(i),'cluster'+str(i),pol,context,
                self.at-timedelta(hours=2),self.at-timedelta(hours=1),self.at-timedelta(minutes=30),1,D('-.001')))
        self.app.contexts={context};self.app.refresh_learning()
        s=signal(at=datetime.now(timezone.utc),desired_fraction=D('.20'))
        q=quote(at=s.known_at,event='learned')
        self.app._process({'BTC':s},{'BTC':q},s.known_at)
        c=self.app.books['Champion'].positions('Champion')[0];ch=self.app.books['Challenger'].positions('Challenger')[0]
        self.assertEqual(ch.quantity,c.quantity/D('2'))
    def test_snapshot_http_read_has_no_database_access(self):
        self.app.analyze_once();server=ThreadingHTTPServer(('127.0.0.1',0),handler(self.app));th=threading.Thread(target=server.serve_forever,daemon=True);th.start()
        original=self.l.read
        try:
            self.l.read=lambda:(_ for _ in ()).throw(AssertionError('DB on HTTP fast path'))
            with urllib.request.urlopen('http://127.0.0.1:'+str(server.server_address[1])+'/api/v85/snapshot') as r:
                self.assertEqual(r.status,200);self.assertEqual(len(json.load(r)['cells']),35)
        finally:self.l.read=original;server.shutdown();server.server_close();th.join()
