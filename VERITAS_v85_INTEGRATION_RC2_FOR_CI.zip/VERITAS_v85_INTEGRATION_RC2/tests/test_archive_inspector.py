import unittest,tempfile,zipfile,hashlib,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from inspect_source_archive import inspect

class ArchiveInspectorTests(unittest.TestCase):
    def build(self,entries):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        p=Path(tmp.name)/'r.zip'
        with zipfile.ZipFile(p,'w') as z:
            for name,value in entries:z.writestr(name,value)
        return p
    def test_exact_hash(self):
        data=b'hello';h=hashlib.sha1(b'blob 5\0'+data).hexdigest()
        r=inspect(self.build([('repo/a.py',data)]),{'a.py':h})
        self.assertEqual(r['status'],'MATCH');self.assertFalse(r['executed_code'])
    def test_modified_code_not_accepted(self):
        r=inspect(self.build([('repo/a.py','changed')]),{'a.py':'wrong'})
        self.assertEqual(r['status'],'REVIEW_REQUIRED');self.assertEqual(r['changed'],['a.py'])
    def test_traversal_rejected(self):
        with self.assertRaises(ValueError):inspect(self.build([('../a','bad')]),{})
    def test_absolute_rejected(self):
        with self.assertRaises(ValueError):inspect(self.build([('/etc/a','bad')]),{})
    def test_case_collision_rejected(self):
        with self.assertRaises(ValueError):inspect(self.build([('repo/A.py','one'),('repo/a.py','two')]),{})
    def test_size_limit(self):
        with self.assertRaises(ValueError):inspect(self.build([('repo/a','x'*1000)]),{},max_total_bytes=100)
    def test_missing_required_member(self):
        r=inspect(self.build([('repo/a','ok')]),{'required.py':'wrong'})
        self.assertEqual(r['missing'],['required.py'])
