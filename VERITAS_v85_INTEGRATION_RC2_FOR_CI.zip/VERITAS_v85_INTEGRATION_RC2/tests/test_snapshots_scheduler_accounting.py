import unittest
from datetime import timedelta
from dataclasses import replace
from decimal import Decimal as D
from concurrent.futures import ThreadPoolExecutor
from veritas_v85.snapshots import SnapshotStore
from veritas_v85.scheduler import DeadlineScheduler
from veritas_v85.accounting import round_trip
from veritas_v85.counterfactual import PathPoint,path_summary,alternative_stop
from common import *

class SnapshotTests(unittest.TestCase):
    def test_cold_no_database(self):self.assertEqual(SnapshotStore().read(T).status,'BACKGROUND_PENDING')
    def test_failed_refresh_retains_last_good(self):
        s=SnapshotStore();s.publish({'status':'OK','items':[1]},T);s.failure('DB_TIMEOUT')
        r=s.read(T);self.assertEqual(r.status,'DEGRADED');self.assertIn(b'1',r.payload)
    def test_stale_no_influence(self):
        s=SnapshotStore(10);s.publish({'status':'OK'},T)
        self.assertFalse(s.read(T+timedelta(seconds=11)).may_influence_decisions)
    def test_failed_refresh_cannot_refresh_time(self):
        s=SnapshotStore(10);s.publish({'status':'OK'},T);s.failure('DB')
        self.assertEqual(s.read(T+timedelta(seconds=11)).status,'STALE')
    def test_read_is_immutable(self):
        v={'status':'OK','items':[1]};s=SnapshotStore();s.publish(v,T);v['items'].append(2)
        self.assertNotIn(b'2',s.read(T).payload)
    def test_regression_time_rejected(self):
        s=SnapshotStore();s.publish({'status':'OK'},T)
        with self.assertRaises(ValueError):s.publish({'status':'OK'},T-timedelta(seconds=1))
    def test_size_bound(self):
        with self.assertRaises(ValueError):SnapshotStore(max_bytes=10).publish({'status':'OK','x':'x'*100},T)
    def test_invalid_snapshot_preserves_old(self):
        s=SnapshotStore();s.publish({'status':'OK','v':1},T)
        with self.assertRaises(ValueError):s.publish({'status':'ERROR'},T)
        self.assertEqual(s.read(T).generation,1)
    def test_restart_restore_age(self):
        s=SnapshotStore();s.publish({'status':'OK'},T);raw=s.read(T).payload
        new=SnapshotStore(ttl_seconds=60);new.restore(raw,T)
        self.assertEqual(new.read(T+timedelta(hours=2)).status,'STALE')
    def test_parallel_readers_no_partial_snapshot(self):
        s=SnapshotStore();s.publish({'status':'OK','items':list(range(100))},T)
        with ThreadPoolExecutor(max_workers=5) as p:out=list(p.map(lambda _:s.read(T).payload,range(200)))
        self.assertEqual(len(set(out)),1)

class SchedulerTests(unittest.TestCase):
    def test_no_overlap(self):
        s=DeadlineScheduler(30,0);self.assertTrue(s.try_start(0).start);self.assertFalse(s.try_start(60).start)
    def test_duration_not_plus_interval(self):
        s=DeadlineScheduler(30,0);s.try_start(0);s.finish()
        r=s.try_start(47);self.assertTrue(r.start);self.assertEqual(r.next_deadline,60)
    def test_skips_backlog(self):
        s=DeadlineScheduler(30,0);s.try_start(0);s.finish();r=s.try_start(480)
        self.assertEqual(r.skipped_deadlines,15);self.assertEqual(r.next_deadline,510)
    def test_not_due(self):
        s=DeadlineScheduler(30,0);s.try_start(0);s.finish();self.assertFalse(s.try_start(29).start)
    def test_bad_interval(self):
        with self.assertRaises(ValueError):DeadlineScheduler(0,0)
    def test_finish_requires_start(self):
        with self.assertRaises(RuntimeError):DeadlineScheduler(30,0).finish()

class AccountingTests(unittest.TestCase):
    def test_micro_move_eaten_by_costs(self):
        p=round_trip(Direction.LONG,500,100,'100.1',SPEC)
        self.assertEqual(p.gross_pnl,D(50));self.assertEqual(p.entry_fee,D(25));self.assertEqual(p.exit_fee,D('25.025'))
        self.assertEqual(p.net_pnl,D('-.025'))
    def test_short_symmetric_price_pnl(self):
        p=round_trip(Direction.SHORT,500,100,'99.9',SPEC)
        self.assertEqual(p.gross_pnl,D(50));self.assertEqual(p.net_pnl,D('.025'))
    def test_nav_vs_nominal(self):
        p=round_trip(Direction.LONG,500,100,102,SPEC)
        self.assertEqual(p.nav_return,p.nominal_return*D('.05'))
    def test_funding_explicit_not_ruonia_implied(self):
        p=round_trip(Direction.LONG,500,100,102,SPEC,funding='12')
        self.assertEqual(p.funding,12);self.assertEqual(p.net_pnl,D('937.5'))
    def test_fx_applied_explicitly(self):
        p=round_trip(Direction.LONG,1,100,101,replace(SPEC,quote_currency='USD'),entry_fx=80,exit_fx=81)
        self.assertEqual(p.gross_pnl,D('81'))
    def test_invalid_negative_cost(self):
        with self.assertRaises(ValueError):round_trip(Direction.LONG,1,100,101,SPEC,funding=-1)

class PathTests(unittest.TestCase):
    def test_future_points_not_visible(self):
        p=PathPoint('p',T,T+timedelta(days=1),D(120))
        self.assertEqual(path_summary([p],Direction.LONG,100,T,T)['n'],0)
    def test_duplicates_not_extra_path(self):
        p=PathPoint('p',T,T,D(110));self.assertEqual(path_summary([p]*10,Direction.LONG,100,T,T)['n'],1)
    def test_mfe_mae_linear_short(self):
        points=[PathPoint(str(i),T+timedelta(minutes=i),T+timedelta(minutes=i),D(v)) for i,v in enumerate([100,110,90])]
        r=path_summary(points,Direction.SHORT,100,T,T+timedelta(minutes=3))
        self.assertEqual(r['mfe'],D('.1'));self.assertEqual(r['mae'],D('-.1'))
    def test_unknown_horizon_not_assumed(self):
        r=alternative_stop([],Direction.LONG,100,95,T,T+timedelta(hours=1),T,500,SPEC)
        self.assertEqual(r['status'],'PENDING_HORIZON')
    def test_replay_does_not_claim_causal_error(self):
        end=T+timedelta(hours=1)
        points=[PathPoint('a',T,T,D(100)),PathPoint('b',T+timedelta(minutes=1),T+timedelta(minutes=1),D(90)),PathPoint('c',end,end,D(110))]
        r=alternative_stop(points,Direction.LONG,100,95,T,end,end,500,SPEC)
        self.assertEqual(r['exit_price'],D(90));self.assertFalse(r['causal_error_proven'])
