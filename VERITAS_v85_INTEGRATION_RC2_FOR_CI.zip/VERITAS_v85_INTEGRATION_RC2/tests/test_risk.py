import unittest,random
from dataclasses import replace
from datetime import timedelta
from decimal import Decimal as D
from veritas_v85.domain import decimal,Instrument
from veritas_v85.risk import *
from common import *

class RiskTests(unittest.TestCase):
    def test_probe(self):
        a=admit(signal(),quote(),SPEC,D('1000000'),LIMITS,T)
        self.assertTrue(a.allowed);self.assertEqual(a.fraction,D('.05'));self.assertEqual(a.quantity,D('500'))
    def test_soft_zero_desired_keeps_probe(self):
        a=admit(signal(desired_fraction=D(0)),quote(),SPEC,D('1000000'),LIMITS,T)
        self.assertEqual(a.fraction,D('.05'))
    def test_no_source(self):
        self.assertEqual(admit(signal(),quote(source_verified=False),SPEC,D('1000'),LIMITS,T).reason,'SOURCE_NOT_VERIFIED')
    def test_missing_secondary(self):
        self.assertFalse(admit(signal(),quote(secondary_time=None),SPEC,D('1000'),LIMITS,T).allowed)
    def test_same_source(self):
        self.assertFalse(admit(signal(),quote(secondary_source='provider-a'),SPEC,D('1000'),LIMITS,T).allowed)
    def test_secondary_stale(self):
        a=admit(signal(),quote(secondary_time=T-timedelta(seconds=61)),SPEC,D('1000'),LIMITS,T)
        self.assertEqual(a.reason,'SECONDARY_STALE')
    def test_primary_stale(self):
        self.assertEqual(admit(signal(),quote(primary_time=T-timedelta(seconds=61)),SPEC,D('1000'),LIMITS,T).reason,'PRIMARY_STALE')
    def test_future_secondary(self):
        self.assertEqual(admit(signal(),quote(secondary_time=T+timedelta(seconds=1)),SPEC,D('1000'),LIMITS,T).reason,'SECONDARY_FROM_FUTURE')
    def test_closed(self):
        self.assertEqual(admit(signal(),quote(market_open=False),SPEC,D('1000'),LIMITS,T).reason,'MARKET_CLOSED')
    def test_veto(self):
        self.assertEqual(admit(signal(hard_veto=True),quote(),SPEC,D('1000'),LIMITS,T).reason,'HARD_VETO')
    def test_kill(self):
        self.assertFalse(admit(signal(),quote(),SPEC,D('1000'),replace(LIMITS,new_risk_allowed=False),T).allowed)
    def test_nan(self):
        for value in ['NaN','Infinity','-Infinity',None,True]:
            with self.subTest(value=value):
                with self.assertRaises(ValueError): decimal(value)
    def test_zero_price(self):
        with self.assertRaises(ValueError): quote(price='0')
    def test_stop_invalid(self):
        self.assertEqual(admit(signal(stop_price=D('101')),quote(),SPEC,D('1000'),LIMITS,T).reason,'STOP_DIRECTION_MISMATCH')
    def test_short_stop_invalid(self):
        self.assertFalse(admit(signal('SHORT',stop_price=D('99')),quote(),SPEC,D('1000'),LIMITS,T).allowed)
    def test_cap_precedes_probe(self):
        self.assertEqual(admit(signal(),quote(),SPEC,D('1000'),replace(LIMITS,remaining_gross=D('.03')),T).reason,'RISK_BUDGET_BELOW_ONE_STEP')
    def test_stop_risk_cap(self):
        a=admit(signal('SHORT',stop_price=D('500')),quote(),SPEC,D('1000'),LIMITS,T)
        self.assertFalse(a.allowed)
    def test_asset_cap(self):
        a=admit(signal(desired_fraction=D('2')),quote(),SPEC,D('1000'),replace(LIMITS,asset_cap=D('.10')),T)
        self.assertLessEqual(a.fraction,D('.10'))
    def test_round_down(self):
        a=admit(signal(desired_fraction=D('.39')),quote(),SPEC,D('1000000'),replace(LIMITS,asset_cap=D('.38')),T)
        self.assertEqual(a.fraction,D('.35'))
    def test_lot(self):
        spec=replace(SPEC,quantity_step=D('10000'))
        self.assertEqual(admit(signal(),quote(),spec,D('1000'),LIMITS,T).reason,'BELOW_INSTRUMENT_LOT')
    def test_fx_missing(self):
        spec=replace(SPEC,quote_currency='USD')
        a=admit(signal(),quote(quote_currency='USD',fx_to_nav=D('80')),spec,D('1000000'),LIMITS,T)
        self.assertEqual(a.reason,'FX_UNVERIFIED')
    def test_fx_stale(self):
        spec=replace(SPEC,quote_currency='USD')
        a=admit(signal(),quote(quote_currency='USD',fx_to_nav=D('80'),fx_verified=True,fx_time=T-timedelta(hours=1)),spec,D('1000000'),LIMITS,T)
        self.assertEqual(a.reason,'FX_STALE_OR_FUTURE')
    def test_fx_valid(self):
        spec=replace(SPEC,quote_currency='USD')
        a=admit(signal(),quote(quote_currency='USD',fx_to_nav=D('80'),fx_verified=True,fx_time=T),spec,D('1000000'),LIMITS,T)
        self.assertTrue(a.allowed);self.assertEqual(a.quantity,D('6.25'))
    def test_no_real_execution(self):
        with self.assertRaises(ValueError): replace(SPEC,execution_kind='LIVE')
    def test_stale_signal(self):
        self.assertEqual(admit(signal(expires_at=T),quote(at=T+timedelta(seconds=1)),SPEC,D('1000'),LIMITS,T+timedelta(seconds=1)).reason,'SIGNAL_NOT_CAUSALLY_AVAILABLE')
    def test_randomized_caps(self):
        rng=random.Random(85)
        for _ in range(2000):
            distance=D(str(rng.uniform(.001,1)))
            s=signal('SHORT',stop_price=D(100)*(1+distance),desired_fraction=D(str(rng.uniform(0,3))))
            l=RiskLimits(D(str(rng.uniform(0,2))),D(str(rng.uniform(0,2))),D(str(rng.uniform(0,.10))))
            a=admit(s,quote(),SPEC,D('1000000'),l,T)
            if a.allowed:
                self.assertLessEqual(a.fraction,l.asset_cap)
                self.assertLessEqual(a.fraction,l.remaining_gross)
                self.assertLessEqual(a.stop_risk_fraction,l.stop_risk_nav)
                self.assertGreater(a.quantity,0)
