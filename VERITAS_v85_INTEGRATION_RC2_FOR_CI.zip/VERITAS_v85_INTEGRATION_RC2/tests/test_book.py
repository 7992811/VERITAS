import unittest,tempfile,threading
from pathlib import Path
from dataclasses import replace
from datetime import timedelta
from decimal import Decimal as D
from concurrent.futures import ThreadPoolExecutor
from veritas_v85.storage import SQLiteLedger
from veritas_v85.book import PaperBook,InputConflict
from common import *

class BookTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.path=Path(self.temp.name)/'test.sqlite'
        self.ledger=SQLiteLedger(self.path);self.book=PaperBook(self.ledger,{'BTC':SPEC})
        self.book.create_account('A',D('1000000'),'v85-test')
    def tearDown(self):self.temp.cleanup()
    def open(self,**kw):
        return self.book.process('A','BTC','m1',T,quote(),signal(**kw),LIMITS)
    def test_open_and_replay(self):
        first=self.open();second=self.open()
        self.assertEqual(len(first['events']),1);self.assertTrue(second['replayed'])
        self.assertEqual(len(self.book.orders('A')),1);self.assertEqual(len(self.book.positions('A')),1)
    def test_restart_replay(self):
        self.open();self.book=PaperBook(SQLiteLedger(self.path),{'BTC':SPEC})
        self.assertTrue(self.open()['replayed']);self.assertEqual(len(self.book.orders('A')),1)
    def test_same_event_changed_price_rejected(self):
        self.open()
        with self.assertRaises(InputConflict):self.book.process('A','BTC','m1',T,quote('101'),signal(),LIMITS)
        self.assertEqual(len(self.book.orders('A')),1)
    def test_missing_signal_no_micro_close(self):
        self.open()
        for i in range(2,12):
            at=T+timedelta(minutes=i)
            r=self.book.process('A','BTC','m'+str(i),at,quote('100.1',at,'m'+str(i)),None,LIMITS)
            self.assertEqual(r['events'],[])
        self.assertEqual(len(self.book.orders('A')),1)
    def test_stop_closes_at_observed_gap_price(self):
        self.open();at=T+timedelta(minutes=1)
        r=self.book.process('A','BTC','m2',at,quote('90',at,'m2'),None,LIMITS)
        self.assertEqual(r['events'][0]['reason'],'STRUCTURAL_STOP')
        self.assertEqual(r['events'][0]['price'],'90')
        self.assertFalse(self.book.positions('A'));self.assertEqual(len(self.book.orders('A')),2)
    def test_small_residual_stop(self):
        self.open()
        with self.ledger.transaction() as c:
            import json
            p=self.book._positions(c,'A')[0];p=replace(p,quantity=D('.001'))
            c.execute('UPDATE v85_positions SET payload=? WHERE account_id=?',(canonical_json(position_dict(p)),'A'))
        at=T+timedelta(minutes=1)
        r=self.book.process('A','BTC','m2',at,quote('94',at,'m2'),None,LIMITS)
        self.assertEqual(r['events'][0]['quantity'],'0.001');self.assertFalse(self.book.positions('A'))
    def test_unconfirmed_flip_hold(self):
        self.open();at=T+timedelta(minutes=1)
        self.book.process('A','BTC','m2',at,quote(at=at,event='m2'),signal('SHORT',at=at),LIMITS)
        self.assertEqual(self.book.positions('A')[0].direction,Direction.LONG)
        self.assertEqual(len(self.book.orders('A')),1)
    def test_confirmed_flip_atomic_and_idempotent(self):
        self.open();at=T+timedelta(hours=2)
        s=signal('SHORT',at=at,confirmations=confirmations(at))
        q=quote('100.1',at,'m2')
        r=self.book.process('A','BTC','m2',at,q,s,LIMITS)
        self.assertEqual([x['action'] for x in r['events']],['CLOSE','OPEN'])
        self.assertEqual(self.book.positions('A')[0].direction,Direction.SHORT)
        self.assertEqual(len(self.book.orders('A')),3)
        self.book.process('A','BTC','m2',at,q,s,LIMITS)
        self.assertEqual(len(self.book.orders('A')),3)
    def test_flip_rechecks_caps_after_close(self):
        self.open();at=T+timedelta(hours=2)
        s=signal('SHORT',at=at,confirmations=confirmations(at))
        r=self.book.process('A','BTC','m2',at,quote(at=at,event='m2'),s,replace(LIMITS,asset_cap=D('0')))
        self.assertEqual([x['action'] for x in r['events']],['CLOSE'])
        self.assertFalse(self.book.positions('A'))
    def test_stop_does_not_license_opposite_entry(self):
        self.open();at=T+timedelta(hours=2)
        s=signal('SHORT',at=at,confirmations=confirmations(at),stop_price=D('98'))
        r=self.book.process('A','BTC','m2',at,quote('94',at,'m2'),s,LIMITS)
        self.assertEqual([x['action'] for x in r['events']],['CLOSE'])
    def test_stop_does_not_repeat_same_idea(self):
        self.open();at=T+timedelta(minutes=1)
        self.book.process('A','BTC','m2',at,quote('94',at,'m2'),None,LIMITS)
        at+=timedelta(minutes=1)
        r=self.book.process('A','BTC','m3',at,quote('96',at,'m3'),signal(at=at),LIMITS)
        self.assertEqual(r['events'],[]);self.assertEqual(r['management_reason'],'REENTRY_REQUIRES_NEW_VALIDATED_INFORMATION')
    def test_reentry_requires_new_information(self):
        self.open();old=self.book.positions('A')[0];at=T+timedelta(minutes=1)
        self.book.process('A','BTC','m2',at,quote('94',at,'m2'),None,LIMITS)
        at+=timedelta(hours=1)
        e=Confirmation('c','new-after-stop','LONG','1h',at-timedelta(minutes=1),at)
        s=signal(at=at,reentry_of_episode=old.episode_id,reentry_information_id=e.information_id,confirmations=(e,))
        r=self.book.process('A','BTC','m3',at,quote('96',at,'m3'),s,LIMITS)
        self.assertEqual(r['events'][0]['action'],'OPEN');self.assertNotEqual(self.book.positions('A')[0].episode_id,old.episode_id)
    def test_failed_open_rolls_back_all(self):
        def fault(phase):
            if phase=='after_open_order':raise RuntimeError('injected crash')
        self.book.fault_hook=fault
        with self.assertRaises(RuntimeError):self.open()
        self.assertFalse(self.book.orders('A'));self.assertFalse(self.book.positions('A'))
        self.book.fault_hook=lambda _:None;self.open();self.assertEqual(len(self.book.orders('A')),1)
    def test_failed_flip_rolls_back_close(self):
        self.open();at=T+timedelta(hours=2)
        def fault(phase):
            if phase=='after_close_order':raise RuntimeError('injected crash')
        self.book.fault_hook=fault
        with self.assertRaises(RuntimeError):
            self.book.process('A','BTC','m2',at,quote(at=at,event='m2'),signal('SHORT',at=at,confirmations=confirmations(at)),LIMITS)
        self.assertEqual(self.book.positions('A')[0].direction,Direction.LONG);self.assertEqual(len(self.book.orders('A')),1)
    def test_failure_before_receipt_rolls_back(self):
        self.book.fault_hook=lambda _:(_ for _ in ()).throw(RuntimeError('receipt crash')) if _=='before_receipt' else None
        with self.assertRaises(RuntimeError):self.open()
        self.assertFalse(self.book.orders('A'))
    def test_concurrent_replay_one_order(self):
        with ThreadPoolExecutor(max_workers=8) as pool:
            results=list(pool.map(lambda _:self.open(),range(16)))
        self.assertEqual(sum(not r['replayed'] for r in results),1)
        self.assertEqual(len(self.book.orders('A')),1)
    def test_no_horizon_stop_migration_on_hold(self):
        self.open();old=self.book.positions('A')[0];at=T+timedelta(minutes=1)
        self.book.process('A','BTC','m2',at,quote(at=at,event='m2'),signal(at=at,horizon='7d',stop_price=D('50')),LIMITS)
        p=self.book.positions('A')[0]
        self.assertEqual(p.horizon,old.horizon);self.assertEqual(p.stop_price,old.stop_price);self.assertEqual(p.episode_id,old.episode_id)
    def test_pending_exit_survives_restart(self):
        self.open();at=T+timedelta(minutes=1)
        r=self.book.process('A','BTC','risk-event',at,None,None,LIMITS,portfolio_hard_stop=True)
        self.assertFalse(r['events']);self.assertTrue(self.book.positions('A'))
        self.book=PaperBook(SQLiteLedger(self.path),{'BTC':SPEC})
        at+=timedelta(minutes=1)
        r=self.book.process('A','BTC','m3',at,quote(at=at,event='m3'),signal(at=at),LIMITS)
        self.assertEqual(r['events'][0]['reason'],'PORTFOLIO_HARD_STOP');self.assertFalse(self.book.positions('A'))
    def test_account_not_reset(self):
        self.open()
        with self.assertRaises(InputConflict):self.book.create_account('A',D('2000000'),'v85-test')
    def test_no_new_risk_on_unverified_existing_nav(self):
        self.open();other=Instrument('ETH','RUB','RUB');self.book.instruments['ETH']=other
        at=T+timedelta(hours=1);q=replace(quote(at=at,event='e1'),asset='ETH')
        s=replace(signal(at=at),asset='ETH')
        r=self.book.process('A','ETH','e1',at,q,s,LIMITS)
        self.assertEqual(r['management_reason'],'NAV_UNVERIFIED');self.assertEqual(len(self.book.positions('A')),1)

class AdditionalFailureTests(unittest.TestCase):
    setUp = BookTests.setUp
    tearDown = BookTests.tearDown
    open = BookTests.open
    def test_optional_learning_failure_does_not_block_stop(self):
        self.open();at=T+timedelta(minutes=1)
        class Broken:
            def for_signal(self,*a):raise RuntimeError('learning service down')
        self.book.experience_view=Broken()
        r=self.book.process('A','BTC','m2',at,quote('94',at,'m2'),signal(at=at),LIMITS)
        self.assertEqual(r['events'][0]['reason'],'STRUCTURAL_STOP')
    def test_out_of_order_market_event_rejected(self):
        self.open();at=T+timedelta(minutes=2)
        self.book.process('A','BTC','m2',at,quote(at=at,event='m2'),None,LIMITS)
        at=T+timedelta(minutes=1)
        with self.assertRaises(InputConflict):
            self.book.process('A','BTC','past',at,quote('94',at,'past'),None,LIMITS)
        self.assertEqual(len(self.book.positions('A')),1)
    def test_required_exit_does_not_use_unknown_secondary(self):
        self.open();at=T+timedelta(minutes=1)
        r=self.book.process('A','BTC','m2',at,quote('94',at,'m2',secondary_time=None),None,LIMITS)
        self.assertEqual(r['events'],[]);self.assertEqual(r['management_reason'],'INDEPENDENT_VERIFICATION_MISSING')

