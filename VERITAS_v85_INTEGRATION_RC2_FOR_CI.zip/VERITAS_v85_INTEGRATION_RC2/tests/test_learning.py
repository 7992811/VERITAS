import unittest
from dataclasses import replace
from datetime import timedelta
from decimal import Decimal as D
from veritas_v85.learning import *
from common import T

CTX=Context('BTC','1h','BREAKOUT','LONG','TREND')
POL='v85-test'
def lesson(i=0,**kw):
    p=dict(episode_id='ep'+str(i),information_cluster='cluster'+str(i),policy_version=POL,context=CTX,
           closed_at=T,matured_at=T,known_at=T,revision=1,net_return=D('.01'))
    p.update(kw);return Lesson(**p)
def validation(**kw):
    p=dict(validation_id='approved',policy_version=POL,context=CTX,train_end=T-timedelta(days=20),
           evaluation_start=T-timedelta(days=19),evaluation_end=T-timedelta(days=1),known_at=T,
           approved_at=T,evaluation_net_mean=D('.01'),expectancy_noninferior=True,drawdown_noninferior=True,
           open_mark_to_market_included=True,independent_test_clusters=40,dataset_hash='dataset-locked')
    p.update(kw);return Validation(**p)

class LearningTests(unittest.TestCase):
    def test_six_not_twentyfour(self):
        x=[lesson(i) for i in range(6)]
        e=summarize(x*4,CTX,POL,T)
        self.assertEqual(e.independent_n,6);self.assertEqual(e.effective_n,6)
    def test_mirror_clusters_one_observation(self):
        e=summarize([lesson(0),lesson(1,information_cluster='cluster0')],CTX,POL,T)
        self.assertEqual(e.independent_n,1)
    def test_other_policy_excluded(self):
        self.assertEqual(summarize([lesson(policy_version='OTHER')],CTX,POL,T).independent_n,0)
    def test_pending_excluded(self):
        self.assertEqual(summarize([lesson(status='PENDING',net_return=None)],CTX,POL,T).independent_n,0)
    def test_future_known_excluded(self):
        self.assertEqual(summarize([lesson(known_at=T+timedelta(days=1))],CTX,POL,T).independent_n,0)
    def test_revision_changes_outcome_once(self):
        old=lesson();new=replace(old,revision=2,known_at=T+timedelta(days=1),net_return=D('-.02'))
        self.assertGreater(summarize([new,old],CTX,POL,T).weighted_net_mean,0)
        e=summarize([old,new],CTX,POL,T+timedelta(days=1))
        self.assertEqual(e.independent_n,1);self.assertLess(e.weighted_net_mean,0)
    def test_retraction_not_fallback(self):
        old=lesson();new=replace(old,revision=2,status='RETRACTED')
        self.assertEqual(summarize([old,new],CTX,POL,T).independent_n,0)
    def test_conflicting_revision(self):
        with self.assertRaises(ValueError):summarize([lesson(),lesson(net_return=D('-.01'))],CTX,POL,T)
    def test_old_experience_decays(self):
        x=lesson(closed_at=T-timedelta(days=90),matured_at=T-timedelta(days=90))
        self.assertAlmostEqual(summarize([x],CTX,POL,T).effective_n,.5)
    def test_hierarchy_transfer_not_exact(self):
        other=replace(CTX,asset='ETH')
        e=summarize([lesson(i,context=other) for i in range(50)],CTX,POL,T)
        self.assertEqual(e.exact_n,0);self.assertLessEqual(e.effective_n,12.5)
    def test_negative_economics_high_win_rate_never_reinforce(self):
        x=[lesson(i,net_return=D('.001') if i<40 else D('-.02')) for i in range(50)]
        e=summarize(x,CTX,POL,T);a=adjustment(e,CTX,POL,T,validation=validation(),approved_ids=frozenset({'approved'}))
        self.assertGreater(e.win_rate_estimate,.5);self.assertLess(e.weighted_net_mean,0)
        self.assertLessEqual(a.size_multiplier,1);self.assertEqual(a.direction_prior,0)
    def test_positive_no_validation_no_upsize(self):
        e=summarize([lesson(i) for i in range(50)],CTX,POL,T)
        self.assertEqual(adjustment(e,CTX,POL,T).size_multiplier,1)
    def test_validation_without_manual_approval_no_upsize(self):
        e=summarize([lesson(i) for i in range(50)],CTX,POL,T)
        self.assertEqual(adjustment(e,CTX,POL,T,validation=validation()).size_multiplier,1)
    def test_approved_bounded_adjustment(self):
        e=summarize([lesson(i) for i in range(50)],CTX,POL,T)
        a=adjustment(e,CTX,POL,T,validation=validation(),approved_ids=frozenset({'approved'}))
        self.assertEqual(a.size_multiplier,D('1.10'));self.assertLessEqual(abs(a.direction_prior),D('.025'))
        self.assertFalse(a.automatic_promotion)
    def test_stale_memory_no_influence(self):
        e=summarize([lesson(i) for i in range(50)],CTX,POL,T)
        a=adjustment(e,CTX,POL,T,validation=validation(),approved_ids=frozenset({'approved'}),snapshot_fresh=False)
        self.assertEqual(a.size_multiplier,1);self.assertEqual(a.direction_prior,0)
    def test_validation_windows_no_overlap(self):
        with self.assertRaises(ValueError): validation(evaluation_start=T-timedelta(days=21))
    def test_validation_future_not_approved(self):
        e=summarize([lesson(i) for i in range(50)],CTX,POL,T)
        v=validation(known_at=T+timedelta(days=1),approved_at=T+timedelta(days=1))
        self.assertEqual(adjustment(e,CTX,POL,T,validation=v,approved_ids=frozenset({'approved'})).size_multiplier,1)
    def test_validation_requires_open_losses(self):
        e=summarize([lesson(i) for i in range(50)],CTX,POL,T)
        v=validation(open_mark_to_market_included=False)
        self.assertEqual(adjustment(e,CTX,POL,T,validation=v,approved_ids=frozenset({'approved'})).size_multiplier,1)
    def test_no_fake_calibration(self):
        self.assertFalse(summarize([lesson()],CTX,POL,T).observations_are_calibrated)
    def test_invalid_weight(self):
        for w in [0,-1,2,float('nan')]:
            with self.subTest(w=w):
                with self.assertRaises(ValueError):lesson(observation_weight=w)
