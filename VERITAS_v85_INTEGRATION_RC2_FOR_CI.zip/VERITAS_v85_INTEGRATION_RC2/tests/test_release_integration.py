import unittest,tempfile,json,copy,hashlib,shutil,ast
from pathlib import Path
from datetime import timedelta
from dataclasses import asdict
from unittest.mock import patch
from common import *
from tools.build_release import table,apply_table,build
from veritas_v85.validation import verify_release
from veritas_v85.storage import SQLiteLedger
from veritas_v85.experience_store import ExperienceService
from veritas_v85.snapshots import SnapshotStore
from veritas_v85.learning import Context,Lesson
from veritas_v85.book import PaperBook
from veritas_v85.routing import route
from test_integrated_application import row,model_fixture,bundles,Application,Settings
ROOT=Path(__file__).resolve().parents[1]

class BuildBoundaryTests(unittest.TestCase):
    def test_literal_patch_table(self):self.assertEqual(table("PATCHES=(('a','b','label'),)",'PATCHES'),[('a','b','label')])
    def test_executable_table_rejected(self):
        with self.assertRaises(ValueError):table("PATCHES=(__import__('os').system('false'),)",'PATCHES')
    def test_missing_patch_rejected(self):
        with self.assertRaises(RuntimeError):apply_table('wrong',[('original','new','name')],[])
    def test_wrong_historical_hash_does_not_touch_built_source(self):
        old=hashlib.sha256((ROOT/'veritas_intelligence.py').read_bytes()).hexdigest()
        with tempfile.NamedTemporaryFile() as f:
            f.write(b'not the pinned dependency');f.flush()
            with self.assertRaises(RuntimeError):build(pinned_path=f.name)
        self.assertEqual(old,hashlib.sha256((ROOT/'veritas_intelligence.py').read_bytes()).hexdigest())
    def test_valid_current_manifest(self):self.assertEqual(verify_release(ROOT,allow_offline_test=True)['status'],'OK')
    def test_offline_basis_cannot_start_production(self):
        if json.loads((ROOT/'release_manifest.json').read_text())['basis']=='OFFLINE_BASE_TEST_ONLY':
            with self.assertRaises(RuntimeError):verify_release(ROOT)
        else:self.assertEqual(verify_release(ROOT)['basis'],'PINNED_V80_STATIC')
    def test_startup_module_has_no_executable_calls(self):
        t=ast.parse((ROOT/'sitecustomize.py').read_text())
        self.assertFalse(any(isinstance(n,(ast.Call,ast.Import,ast.ImportFrom)) for n in ast.walk(t)))
    def test_news_bot_and_prompts_unchanged(self):
        lock=json.loads((ROOT/'source_lock.json').read_text())
        for name in ('bot.py','prompts.py','requirements.txt'):
            self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),lock['files'][name]['sha256'])
    def test_knowledge_files_unchanged(self):
        lock=json.loads((ROOT/'source_lock.json').read_text())
        for p in ROOT.glob('veritas_knowledge_seed*.json'):
            self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),lock['files'][p.name]['sha256'])
    def test_wrong_clock_blocks_new_signal(self):
        r=row();r['clock_gate_pass']=False;self.assertFalse(route([r],T).signals)

class IncrementalPathTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.l=SQLiteLedger(Path(self.tmp.name)/'t.sqlite');self.e=ExperienceService(self.l,SnapshotStore())
        self.ctx=Context('BTC','1h','x','LONG','trend')
    def tearDown(self):self.tmp.cleanup()
    def make(self,id,known=T,ret='-.01',rev=1):return Lesson(id,'cluster'+id,'p',self.ctx,T,T,known,rev,D(ret))
    def test_late_known_revision_not_lost_behind_timestamp_cursor(self):
        self.e.save(self.make('z',T+timedelta(hours=2)));self.e.lessons(T+timedelta(hours=3))
        self.e.save(self.make('a',T+timedelta(hours=1)))
        self.assertEqual(len(self.e.lessons(T+timedelta(hours=3))),2)
    def test_future_cached_rows_not_visible(self):
        self.e.save(self.make('a',T+timedelta(days=1)));self.assertEqual(self.e.lessons(T),[])
        self.assertEqual(len(self.e.lessons(T+timedelta(days=1))),1)
        self.assertEqual(self.e.lessons(T),[])
    def test_retraction_on_next_page_changes_summary(self):
        self.e.save(self.make('a'));self.e.refresh(T,[self.ctx],'p')
        x=self.make('a',T+timedelta(minutes=1),rev=2)
        from dataclasses import replace
        self.e.save(replace(x,status='RETRACTED'))
        self.e.refresh(T+timedelta(minutes=2),[self.ctx],'p')
        data=json.loads(self.e.snapshots.read(T+timedelta(minutes=2)).payload)
        self.assertEqual(data['items'][0]['experience']['independent_n'],0)
    def test_observed_path_metrics_persist(self):
        b=PaperBook(self.l,{'BTC':SPEC});b.create_account('A',D('1000000'),'p');b.process('A','BTC','m1',T,quote(),signal(),LIMITS)
        b.process('A','BTC','up',T+timedelta(seconds=1),quote('110',T+timedelta(seconds=1),'up'),None,LIMITS)
        b.process('A','BTC','down',T+timedelta(seconds=2),quote('94',T+timedelta(seconds=2),'down'),None,LIMITS)
        with self.l.read() as c:x=json.loads(c.execute('SELECT payload FROM v85_episodes').fetchone()['payload'])['outcome']
        self.assertEqual(D(x['observed_mfe_fraction']),D('.10'));self.assertEqual(D(x['observed_mae_fraction']),D('-.06'))
        self.assertEqual(x['held_seconds'],2);self.assertEqual(x['causal_error'],'NOT_INFERRED_FROM_PNL_ALONE')
    def test_retry_does_not_add_path_point(self):
        b=PaperBook(self.l,{'BTC':SPEC});b.create_account('A',D('1000000'),'p')
        b.process('A','BTC','m1',T,quote(),signal(),LIMITS);b.process('A','BTC','m1',T,quote(),signal(),LIMITS)
        with self.l.read() as c:self.assertEqual(len(c.execute('SELECT * FROM v85_path').fetchall()),1)

class RetainedAnalyticalMathTests(unittest.TestCase):
    def test_v70_data_failure_remains_absolute(self):
        import veritas_v70 as v
        x=v.pretrade_gate({'research_decision':'LONG','source_gate':False,'time_gate':True,'market_open':True})
        self.assertFalse(x['allow']);self.assertEqual(x['gate_class'],'DATA_VETO')
    def test_v70_entry_is_not_long_horizon_thesis(self):
        import veritas_v70 as v
        x=v.pretrade_gate({'research_decision':'LONG','horizon':'1d','source_gate':True,'time_gate':True,'market_open':True,
            'confidence':.72,'calibrated_probability':.70,'effective_evidence':3,'trend_impulse':{'direction':'LONG','entry_quality':'INVALIDATED'},
            'horizon_structure':{'status':'OK','native_horizon':True,'direction':'LONG','score':.70},
            'agents':[('A','LONG',.8),('B','LONG',.7),('C','SHORT',.2)]})
        self.assertNotEqual(x['thesis_status'],'BROKEN')
    def test_legacy_mathematical_source_remains_static(self):
        with tempfile.TemporaryDirectory() as d:
            m=model_fixture(d);before=(ROOT/'veritas_intelligence.py').read_bytes()
            fs=bundles(m);app=Application(m,SQLiteLedger(Path(d)/'b.sqlite'),Settings(mode='fixture',testing=True),fixture_bundles=fs)
            app.bootstrap();app.analyze_once();app.analyze_once();app.close()
            self.assertEqual(before,(ROOT/'veritas_intelligence.py').read_bytes())


class ActualRuntimeVersionTests(unittest.TestCase):
    def test_fresh_import_matches_manifest(self):
        import subprocess,sys,os
        env=os.environ.copy();env['DATABASE_URL']=''
        code="import veritas_intelligence as m; import json; print(json.dumps({'version':m.VERSION}))"
        p=subprocess.run([sys.executable,'-c',code],cwd=ROOT,env=env,capture_output=True,text=True,timeout=10)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertEqual(json.loads(p.stdout.strip().splitlines()[-1])['version'],json.loads((ROOT/'release_manifest.json').read_text())['version'])
    def test_companion_cannot_change_host_version(self):
        source=(ROOT/'veritas_v70.py').read_text()
        tree=ast.parse(source)
        self.assertFalse(any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='setattr' for n in ast.walk(tree)))
    def test_wrong_imported_runtime_blocks_launch(self):
        from veritas_v85.validation import verify_runtime_version
        from types import SimpleNamespace
        with self.assertRaisesRegex(RuntimeError,'IMPORTED_RUNTIME_VERSION_MISMATCH'):
            verify_runtime_version(SimpleNamespace(VERSION='old'),'new')


class CutoverSourceCoverageTests(unittest.TestCase):
    def test_unsupported_legacy_asset_blocks_before_import(self):
        from veritas_v85.quote_guard import require_cutover_guard_coverage
        with self.assertRaisesRegex(RuntimeError,'CUTOVER_BLOCKED'):
            require_cutover_guard_coverage({'snapshot':{'positions':[{'position':{'asset':'CNYRUBF'}}]}})
    def test_supported_coverage_does_not_assert_live_freshness(self):
        from veritas_v85.quote_guard import require_cutover_guard_coverage
        x=require_cutover_guard_coverage({'snapshot':{'positions':[{'position':{'asset':'BTC'}}]}})
        self.assertEqual(x['status'],'SUPPORTED_ADAPTERS');self.assertTrue(x['live_quote_validity_checked_per_order'])
