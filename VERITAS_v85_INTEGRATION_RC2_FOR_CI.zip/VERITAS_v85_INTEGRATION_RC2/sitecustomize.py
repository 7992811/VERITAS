"""Compatibility tombstone: v85 never downloads or rewrites code during Python startup."""
