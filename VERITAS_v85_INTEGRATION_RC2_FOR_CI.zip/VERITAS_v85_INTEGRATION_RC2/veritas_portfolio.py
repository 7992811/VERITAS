"""Compatibility read facade. Legacy step_all cannot place orders in v85."""
VERSION='veritas-portfolio-v85.0-rc2-single-owner'
_runtime=None

def bind(runtime):
    global _runtime
    _runtime=runtime

def step_all(*args,**kwargs):
    raise RuntimeError('LEGACY_WRITER_DISABLED: use the v85 single-owner coordinator')

def report(pg_connect=None):
    return _runtime.portfolio_report() if _runtime else {'status':'NOT_READY','version':VERSION,'portfolios':[]}

def trade_report(pg_connect=None,limit=100):
    return _runtime.trade_report(limit) if _runtime else {'status':'NOT_READY','items':[]}
